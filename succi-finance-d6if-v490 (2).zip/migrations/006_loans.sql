CREATE TABLE loans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_id uuid NOT NULL REFERENCES branches(id) ON DELETE RESTRICT,
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE RESTRICT,
  principal numeric(14,2) NOT NULL CHECK (principal > 0),
  interest_rate numeric(6,3) NOT NULL DEFAULT 30.000,
  interest_amount numeric(14,2) NOT NULL DEFAULT 0,
  total_payable numeric(14,2) NOT NULL DEFAULT 0,
  repayment_frequency text NOT NULL CHECK (repayment_frequency IN ('daily','weekly','monthly')),
  term_count integer NOT NULL CHECK (term_count > 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','disbursed','active','completed','defaulted')),
  disbursed_at timestamptz,
  disbursed_by uuid REFERENCES staff(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
)
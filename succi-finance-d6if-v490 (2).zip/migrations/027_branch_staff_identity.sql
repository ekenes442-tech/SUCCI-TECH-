ALTER TABLE branches ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE staff ADD COLUMN IF NOT EXISTS staff_code text;
CREATE UNIQUE INDEX IF NOT EXISTS branches_org_email_unique ON branches(organization_id,lower(email)) WHERE email IS NOT NULL AND email<>'';
CREATE UNIQUE INDEX IF NOT EXISTS staff_org_code_unique ON staff(organization_id,staff_code) WHERE staff_code IS NOT NULL AND staff_code<>'';
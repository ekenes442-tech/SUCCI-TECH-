CREATE TABLE clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_id uuid NOT NULL REFERENCES branches(id) ON DELETE RESTRICT,
  credit_officer_id uuid REFERENCES staff(id) ON DELETE SET NULL,
  client_type text NOT NULL CHECK (client_type IN ('individual','group')),
  full_name text NOT NULL,
  phone text NOT NULL,
  address text,
  collection_day text NOT NULL CHECK (collection_day IN ('monday','tuesday','wednesday','thursday','friday')),
  workflow_status text NOT NULL DEFAULT 'awaiting_savings' CHECK (workflow_status IN ('awaiting_savings','awaiting_disbursement','active','completed','rejected','suspended')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id, phone)
)
INSERT INTO role_navigation_rules (role, nav_key)
SELECT 'credit_officer','collection_history'
WHERE NOT EXISTS (SELECT 1 FROM role_navigation_rules WHERE role='credit_officer' AND nav_key='collection_history');
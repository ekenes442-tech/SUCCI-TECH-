CREATE INDEX IF NOT EXISTS idx_loan_applications_approval_scope ON loan_applications(organization_id, branch_id, status, created_at);
CREATE INDEX IF NOT EXISTS idx_loans_disbursement_scope ON loans(organization_id, branch_id, status, created_at);
CREATE INDEX IF NOT EXISTS idx_loans_audit_scope ON loans(organization_id, branch_id, status, client_id);
CREATE INDEX IF NOT EXISTS idx_collection_records_loan_scope ON collection_records(organization_id, branch_id, loan_id, collection_date);
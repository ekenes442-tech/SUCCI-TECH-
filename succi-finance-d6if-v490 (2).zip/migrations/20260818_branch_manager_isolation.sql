CREATE INDEX IF NOT EXISTS idx_clients_org_branch_created ON clients(organization_id,branch_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_loans_org_branch_status ON loans(organization_id,branch_id,status,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_disbursements_org_branch_time ON disbursements(organization_id,branch_id,disbursed_at DESC);
CREATE INDEX IF NOT EXISTS idx_collection_records_org_branch_date ON collection_records(organization_id,branch_id,collection_date DESC,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_records_org_branch_time ON audit_records(organization_id,branch_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_staff_org_branch_role_status ON staff(organization_id,branch_id,role,status,deleted_at);
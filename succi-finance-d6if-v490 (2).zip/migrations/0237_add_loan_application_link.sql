ALTER TABLE loans ADD COLUMN IF NOT EXISTS loan_application_id uuid;
CREATE INDEX IF NOT EXISTS idx_loans_loan_application_id ON loans(loan_application_id);
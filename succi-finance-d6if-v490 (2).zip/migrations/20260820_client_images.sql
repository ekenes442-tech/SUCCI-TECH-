ALTER TABLE clients ADD COLUMN IF NOT EXISTS passport_photo_url text;
CREATE TABLE IF NOT EXISTS client_collateral_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_id uuid NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  loan_application_id uuid REFERENCES loan_applications(id) ON DELETE SET NULL,
  image_url text NOT NULL,
  description text,
  created_by_staff_id uuid REFERENCES staff(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_client_collateral_scope ON client_collateral_images(organization_id,branch_id,client_id);
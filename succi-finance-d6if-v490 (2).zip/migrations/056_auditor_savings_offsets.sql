CREATE TABLE IF NOT EXISTS auditor_savings_offsets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,
  branch_id uuid NOT NULL,
  source_client_id uuid NOT NULL,
  target_client_id uuid NOT NULL,
  target_loan_id uuid NOT NULL,
  amount numeric(14,2) NOT NULL CHECK (amount > 0),
  reason text NOT NULL,
  auditor_staff_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_auditor_savings_offsets_source ON auditor_savings_offsets(organization_id,source_client_id);
CREATE INDEX IF NOT EXISTS idx_auditor_savings_offsets_target ON auditor_savings_offsets(organization_id,target_client_id,target_loan_id);
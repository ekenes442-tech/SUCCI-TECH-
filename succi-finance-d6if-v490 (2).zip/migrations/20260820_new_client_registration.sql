ALTER TABLE clients
  ADD COLUMN date_of_birth date,
  ADD COLUMN gender text,
  ADD COLUMN marital_status text,
  ADD COLUMN alternative_phone text,
  ADD COLUMN email text,
  ADD COLUMN occupation text,
  ADD COLUMN employer_business_name text,
  ADD COLUMN business_address text,
  ADD COLUMN state text,
  ADD COLUMN lga text,
  ADD COLUMN id_type text,
  ADD COLUMN id_number text,
  ADD COLUMN next_of_kin_name text,
  ADD COLUMN next_of_kin_relationship text,
  ADD COLUMN next_of_kin_phone text,
  ADD COLUMN next_of_kin_address text,
  ADD COLUMN loan_purpose text,
  ADD COLUMN repayment_frequency text,
  ADD COLUMN repayment_term integer,
  ADD COLUMN bank_name text,
  ADD COLUMN account_name text,
  ADD COLUMN account_number text,
  ADD COLUMN savings_required numeric DEFAULT 0,
  ADD COLUMN declaration_accepted boolean DEFAULT false;

CREATE TABLE client_guarantors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL,
  branch_id uuid NOT NULL,
  client_id uuid NOT NULL,
  guarantor_number integer NOT NULL,
  full_name text NOT NULL,
  phone text NOT NULL,
  relationship text,
  occupation text,
  address text,
  id_type text,
  id_number text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (client_id, guarantor_number)
);

CREATE INDEX idx_client_guarantors_org_phone ON client_guarantors (organization_id, phone);
CREATE INDEX idx_client_guarantors_client ON client_guarantors (client_id, organization_id);
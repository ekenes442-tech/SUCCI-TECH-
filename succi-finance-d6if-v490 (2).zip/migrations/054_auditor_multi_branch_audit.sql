CREATE TABLE IF NOT EXISTS auditor_branch_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  auditor_staff_id uuid NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  branch_id uuid NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
  assigned_by_staff_id uuid REFERENCES staff(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(auditor_staff_id,branch_id)
);
CREATE INDEX IF NOT EXISTS idx_auditor_branch_assignments_auditor ON auditor_branch_assignments(organization_id,auditor_staff_id);
CREATE INDEX IF NOT EXISTS idx_auditor_branch_assignments_branch ON auditor_branch_assignments(organization_id,branch_id);
INSERT INTO auditor_branch_assignments(organization_id,auditor_staff_id,branch_id)
SELECT organization_id,id,branch_id FROM staff
WHERE role='auditor' AND branch_id IS NOT NULL
ON CONFLICT(auditor_staff_id,branch_id) DO NOTHING;
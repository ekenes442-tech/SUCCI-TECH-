-- Final SUCCI TECH role permission matrix. Role is the source of truth.
DELETE FROM role_permissions WHERE role IN ('general_overseer','general_supervisor','operational_manager','branch_manager','supervisor','auditor','credit_officer');
DELETE FROM role_navigation_rules WHERE role IN ('general_overseer','general_supervisor','operational_manager','branch_manager','supervisor','auditor','credit_officer');

INSERT INTO role_permissions(role,permission_key) VALUES ('general_overseer','dashboard.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('general_overseer','organization.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('general_overseer','organization.manage');
INSERT INTO role_permissions(role,permission_key) VALUES ('general_overseer','branches.manage');
INSERT INTO role_permissions(role,permission_key) VALUES ('general_overseer','staff.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('general_overseer','staff.manage');
INSERT INTO role_permissions(role,permission_key) VALUES ('general_overseer','clients.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('general_overseer','disbursement_history.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('general_overseer','reports.view');

INSERT INTO role_permissions(role,permission_key) VALUES ('general_supervisor','dashboard.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('general_supervisor','clients.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('general_supervisor','approval_history.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('general_supervisor','disbursements.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('general_supervisor','reports.view');

INSERT INTO role_permissions(role,permission_key) VALUES ('operational_manager','dashboard.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('operational_manager','branch_clients.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('operational_manager','clients.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('operational_manager','disbursements.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('operational_manager','reports.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('operational_manager','operations.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('operational_manager','operations.manage');

INSERT INTO role_permissions(role,permission_key) VALUES ('branch_manager','dashboard.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('branch_manager','clients.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('branch_manager','pending_disbursements.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('branch_manager','disbursements.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('branch_manager','loans.disburse');
INSERT INTO role_permissions(role,permission_key) VALUES ('branch_manager','collection_history.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('branch_manager','branch_reports.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('branch_manager','staff.manage');
INSERT INTO role_permissions(role,permission_key) VALUES ('branch_manager','branch.manage');

INSERT INTO role_permissions(role,permission_key) VALUES ('supervisor','dashboard.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('supervisor','clients.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('supervisor','default_nonpayment_reports.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('supervisor','disbursements.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('supervisor','loans.view');

INSERT INTO role_permissions(role,permission_key) VALUES ('auditor','dashboard.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('auditor','clients.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('auditor','collection_history.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('auditor','collection.audit');
INSERT INTO role_permissions(role,permission_key) VALUES ('auditor','audit.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('auditor','audit.edit');
INSERT INTO role_permissions(role,permission_key) VALUES ('auditor','branch_reports.view');

INSERT INTO role_permissions(role,permission_key) VALUES ('credit_officer','dashboard.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('credit_officer','client.register');
INSERT INTO role_permissions(role,permission_key) VALUES ('credit_officer','clients.create');
INSERT INTO role_permissions(role,permission_key) VALUES ('credit_officer','clients.manage');
INSERT INTO role_permissions(role,permission_key) VALUES ('credit_officer','clients.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('credit_officer','loans.create');
INSERT INTO role_permissions(role,permission_key) VALUES ('credit_officer','awaiting_approval.view');
INSERT INTO role_permissions(role,permission_key) VALUES ('credit_officer','collections.enter');
INSERT INTO role_permissions(role,permission_key) VALUES ('credit_officer','collections.view');

INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_overseer','dashboard');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_overseer','organization');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_overseer','branches');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_overseer','staff');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_overseer','clients');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_overseer','disbursement-history');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_overseer','reports');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_overseer','settings');

INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_supervisor','dashboard');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_supervisor','branches');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_supervisor','staff');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_supervisor','clients');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_supervisor','approval_history');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_supervisor','disbursement-history');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('general_supervisor','reports');

INSERT INTO role_navigation_rules(role,nav_key) VALUES ('operational_manager','dashboard');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('operational_manager','branch_clients');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('operational_manager','clients');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('operational_manager','disbursement-history');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('operational_manager','reports');

INSERT INTO role_navigation_rules(role,nav_key) VALUES ('branch_manager','dashboard');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('branch_manager','clients');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('branch_manager','pending_disbursements');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('branch_manager','disbursement-history');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('branch_manager','collection_history');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('branch_manager','branch_reports');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('branch_manager','staff');

INSERT INTO role_navigation_rules(role,nav_key) VALUES ('supervisor','dashboard');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('supervisor','clients');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('supervisor','default_nonpayment_reports');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('supervisor','reports');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('supervisor','disbursement-history');

INSERT INTO role_navigation_rules(role,nav_key) VALUES ('auditor','dashboard');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('auditor','clients');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('auditor','collection_history');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('auditor','audits');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('auditor','branch_reports');

INSERT INTO role_navigation_rules(role,nav_key) VALUES ('credit_officer','dashboard');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('credit_officer','clients');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('credit_officer','loans');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('credit_officer','awaiting_approval');
INSERT INTO role_navigation_rules(role,nav_key) VALUES ('credit_officer','collections');
ALTER TABLE staff ADD COLUMN IF NOT EXISTS deleted_at timestamptz NULL;
ALTER TABLE staff ADD COLUMN IF NOT EXISTS deleted_by_auth_user_id text NULL;
ALTER TABLE staff ADD COLUMN IF NOT EXISTS status_reason text NULL;
UPDATE staff SET status='inactive' WHERE status='suspended';
ALTER TABLE staff DROP CONSTRAINT IF EXISTS staff_status_check;
ALTER TABLE staff ADD CONSTRAINT staff_status_check CHECK (status IN ('active','inactive'));
CREATE INDEX IF NOT EXISTS idx_staff_org_branch_status ON staff(organization_id,branch_id,status);
CREATE INDEX IF NOT EXISTS idx_staff_deleted_at ON staff(deleted_at);
CREATE TABLE IF NOT EXISTS staff_management_audit (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 staff_id uuid NULL,
 organization_id uuid NOT NULL,
 branch_id uuid NULL,
 action text NOT NULL CHECK (action IN ('activate','deactivate','delete')),
 actor_staff_id uuid NULL,
 actor_auth_user_id text NULL,
 actor_role text NULL,
 reason text NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_staff_management_audit_org_time ON staff_management_audit(organization_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_staff_management_audit_staff ON staff_management_audit(staff_id,created_at DESC);
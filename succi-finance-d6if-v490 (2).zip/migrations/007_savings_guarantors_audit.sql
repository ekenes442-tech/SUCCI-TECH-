CREATE TABLE savings_guarantors_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  client_id uuid REFERENCES clients(id) ON DELETE CASCADE,
  loan_id uuid REFERENCES loans(id) ON DELETE CASCADE,
  record_type text NOT NULL CHECK (record_type IN ('savings','guarantor','audit')),
  amount numeric(14,2),
  guarantor_name text,
  guarantor_phone text,
  guarantor_count integer,
  audit_status text CHECK (audit_status IN ('pending','approved','rejected','edited')),
  reason text,
  created_by text,
  created_at timestamptz NOT NULL DEFAULT now()
)
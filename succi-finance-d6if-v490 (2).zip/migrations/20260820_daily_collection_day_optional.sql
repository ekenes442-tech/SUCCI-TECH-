ALTER TABLE clients DROP CONSTRAINT IF EXISTS clients_collection_day_check;

ALTER TABLE clients ADD CONSTRAINT clients_collection_day_check CHECK (collection_day IS NULL OR collection_day = ANY (ARRAY['monday'::text, 'tuesday'::text, 'wednesday'::text, 'thursday'::text, 'friday'::text]));
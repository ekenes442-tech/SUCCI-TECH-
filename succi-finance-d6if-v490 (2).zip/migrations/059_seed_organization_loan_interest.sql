INSERT INTO organization_loan_settings (organization_id, interest_rate, savings_rate)
SELECT o.id, 3, 10
FROM organizations o
WHERE NOT EXISTS (SELECT 1 FROM organization_loan_settings s WHERE s.organization_id=o.id::text);
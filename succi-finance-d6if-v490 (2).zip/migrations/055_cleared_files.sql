CREATE TABLE IF NOT EXISTS cleared_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_id uuid NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  auditor_staff_id uuid REFERENCES staff(id),
  status text NOT NULL DEFAULT 'cleared',
  service_collection_status text NOT NULL DEFAULT 'not_requested',
  service_total numeric(14,2) NOT NULL DEFAULT 0,
  service_collect_amount numeric(14,2) NOT NULL DEFAULT 0,
  service_collection_scope text,
  submitted_by_staff_id uuid REFERENCES staff(id),
  submitted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(organization_id,client_id)
);
CREATE INDEX IF NOT EXISTS idx_cleared_files_org_status ON cleared_files(organization_id,status);
CREATE INDEX IF NOT EXISTS idx_cleared_files_branch ON cleared_files(organization_id,branch_id);
CREATE TABLE IF NOT EXISTS organization_settings (organization_id uuid PRIMARY KEY, timezone text NOT NULL DEFAULT 'Africa/Lagos', currency text NOT NULL DEFAULT 'NGN', date_format text NOT NULL DEFAULT 'DD/MM/YYYY', created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now());
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'active';
ALTER TABLE branches ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'active';
ALTER TABLE staff ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'active';
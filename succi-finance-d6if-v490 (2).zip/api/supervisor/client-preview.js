import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public';
export const methods=['GET'];
export default async function(req,res){
  const auth=await requireStaff(req,res); if(!auth)return;
  const s=auth.staff;
  if(String(s.role||'').toLowerCase().replace(/[-_]+/g,' ')!=='supervisor') return res.status(403).json({error:'Supervisor access required.'});
  const id=req.query?.application_id||req.query?.id;
  if(!id)return res.status(400).json({error:'Application ID is required.'});
  const {rows}=await db.query(`SELECT la.id application_id,la.organization_id,la.branch_id,la.amount,la.interest_rate,la.status application_status,la.created_at,la.credit_officer_staff_id,
    c.id client_id,c.full_name,c.phone,c.address,c.client_type,c.gender,c.marital_status,c.date_of_birth,c.occupation,c.employer_business_name,c.business_address,c.state,c.lga,c.loan_purpose,c.repayment_frequency,c.repayment_term,c.next_of_kin_name,c.next_of_kin_relationship,c.next_of_kin_phone,c.workflow_status,
    COALESCE((SELECT SUM(ls.amount) FROM loan_savings ls WHERE ls.organization_id=la.organization_id AND ls.loan_application_id=la.id),0)::numeric savings_paid,
    ROUND(la.amount*0.10,2)::numeric required_savings,
    COALESCE((SELECT json_agg(json_build_object('id',g.id,'guarantor_number',g.guarantor_number,'full_name',g.full_name,'phone',g.phone,'relationship',g.relationship,'occupation',g.occupation,'address',g.address,'id_type',g.id_type,'id_number',g.id_number,'passport_photo_url',g.passport_photo_url) ORDER BY g.guarantor_number) FROM client_guarantors g WHERE g.organization_id=la.organization_id AND g.client_id=c.id),'[]'::json) guarantors,
    (SELECT full_name FROM staff st WHERE st.id=la.credit_officer_staff_id AND st.organization_id=la.organization_id LIMIT 1) credit_officer_name
    FROM loan_applications la JOIN clients c ON c.id=la.client_id
    WHERE la.id=$1 AND la.organization_id=$2 AND la.branch_id=$3
      AND la.status = 'awaiting_approval'
      AND c.organization_id=$2 AND c.branch_id=$3
    LIMIT 1`,[id,s.organization_id,s.branch_id]);
  if(!rows[0])return res.status(404).json({error:'Loan application not found in your assigned branch or is no longer awaiting preview.'});
  const imageRows=await db.query('SELECT passport_photo_url FROM clients WHERE id=$1 AND organization_id=$2 AND branch_id=$3 LIMIT 1',[rows[0].client_id,s.organization_id,s.branch_id]);
  const collateral=await db.query('SELECT id,image_url,description,created_at FROM client_collateral_images WHERE client_id=$1 AND organization_id=$2 AND branch_id=$3 ORDER BY created_at DESC',[rows[0].client_id,s.organization_id,s.branch_id]);
  rows[0].passport_photo_url=imageRows.rows[0]?.passport_photo_url||null;
  rows[0].collateral_images=collateral.rows;
  res.json({application:rows[0]});
}
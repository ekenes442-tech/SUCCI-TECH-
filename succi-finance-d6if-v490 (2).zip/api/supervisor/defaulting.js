import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public';
export const methods=['GET'];
export default async function(req,res){
  const auth=await requireStaff(req,res); if(!auth)return;
  const s=auth.staff;
  if(String(s.role||'').toLowerCase().replace(/[-_]+/g,' ')!=='supervisor') return res.status(403).json({error:'Supervisor access required.'});
  if(!s.organization_id||!s.branch_id) return res.status(403).json({error:'Supervisor has no authorized branch.'});
  const coId=String(req.query?.credit_officer_id||'').trim();
  let coFilter='';
  if(coId){
    const {rows:coRows}=await db.query(`SELECT id FROM staff WHERE id=$1 AND organization_id=$2 AND branch_id=$3 AND deleted_at IS NULL AND lower(replace(replace(role,'-','_'),' ','_')) IN ('credit_officer','co') AND lower(coalesce(status,'active')) NOT IN ('suspended','deactivated','inactive','deleted') LIMIT 1`,[coId,s.organization_id,s.branch_id]);
    if(!coRows.length)return res.status(400).json({error:'Selected Credit Officer is not authorized for this branch.'});
    coFilter=' AND c.credit_officer_id=$3';
  }
  const params=coId?[s.organization_id,s.branch_id,coId]:[s.organization_id,s.branch_id];
  const {rows}=await db.query(`SELECT DISTINCT ON (c.id)
    c.id client_id,c.full_name,c.phone,c.workflow_status,
    l.id loan_id,l.principal loan_amount,l.status loan_status,
    GREATEST(COALESCE(l.total_payable,l.principal+COALESCE(l.interest_amount,0),0)-COALESCE((SELECT SUM(cr.amount_paid) FROM collection_records cr WHERE cr.organization_id=c.organization_id AND cr.branch_id=c.branch_id AND cr.client_id=c.id AND cr.loan_id=l.id),0),0)::numeric overdue_amount,
    CASE WHEN l.disbursed_at IS NOT NULL THEN l.disbursed_at + (COALESCE(l.term_count,30) * CASE lower(COALESCE(l.repayment_frequency,'daily')) WHEN 'weekly' THEN interval '7 days' WHEN 'monthly' THEN interval '30 days' ELSE interval '1 day' END) END earliest_overdue_date,
    s2.full_name credit_officer_name
    FROM clients c
    JOIN loans l ON l.client_id=c.id AND l.organization_id=c.organization_id AND l.branch_id=c.branch_id
    LEFT JOIN staff s2 ON s2.id=c.credit_officer_id AND s2.organization_id=c.organization_id
    WHERE c.organization_id=$1 AND c.branch_id=$2
      AND l.status IN ('active','disbursed')
      AND l.disbursed_at IS NOT NULL
      AND l.disbursed_at + (COALESCE(l.term_count,30) * CASE lower(COALESCE(l.repayment_frequency,'daily')) WHEN 'weekly' THEN interval '7 days' WHEN 'monthly' THEN interval '30 days' ELSE interval '1 day' END) < CURRENT_DATE
      AND COALESCE((SELECT SUM(cr.amount_paid) FROM collection_records cr WHERE cr.organization_id=c.organization_id AND cr.branch_id=c.branch_id AND cr.client_id=c.id AND cr.loan_id=l.id),0) < COALESCE(l.total_payable,l.principal+COALESCE(l.interest_amount,0),0)
      ${coFilter}
    ORDER BY c.id,l.created_at DESC`,params);
  res.json({clients:rows,count:rows.length,scope:{organization_id:s.organization_id,branch_id:s.branch_id},filter:{credit_officer_id:coId||null}});
}
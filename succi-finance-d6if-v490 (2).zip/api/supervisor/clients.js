import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public';
export const methods=['GET'];
export default async function(req,res){
  const auth=await requireStaff(req,res); if(!auth)return;
  const s=auth.staff;
  const callerRole=String(s.role||'').toLowerCase().replace(/[-_]+/g,' ');
  const isBranchManager=callerRole==='branch manager'||String(s.role||'').toLowerCase().trim()==='bm'||String(s.role||'').toLowerCase().includes('branch manager');if(!(['supervisor'].includes(callerRole)||isBranchManager))return res.status(403).json({error:'Supervisor or Branch Manager access required.'});
  const coId=String(req.query?.credit_officer_id||'').trim();
  let coFilter='';
  if(coId){
    const {rows:coRows}=await db.query(`SELECT id FROM staff WHERE id=$1 AND organization_id=$2 AND branch_id=$3 AND deleted_at IS NULL AND lower(replace(replace(role,'-','_'),' ','_')) IN ('credit_officer','co') AND lower(coalesce(status,'active')) NOT IN ('suspended','deactivated','inactive','deleted') LIMIT 1`,[coId,s.organization_id,s.branch_id]);
    if(!coRows.length)return res.status(400).json({error:'Selected Credit Officer is not authorized for this branch.'});
    coFilter=` AND COALESCE(la.credit_officer_staff_id,c.credit_officer_id)=$3`;
  }
  const params=coId?[s.organization_id,s.branch_id,coId]:[s.organization_id,s.branch_id];
  const {rows}=await db.query(`SELECT c.id,c.full_name,c.phone,c.workflow_status,c.created_at,
    la.id application_id,la.status application_status,la.amount,
    l.id loan_id,l.status loan_status,l.disbursed_at,
    (SELECT full_name FROM staff st WHERE st.id=COALESCE(la.credit_officer_staff_id,c.credit_officer_id) AND st.organization_id=$1 LIMIT 1) credit_officer_name
    FROM clients c
    LEFT JOIN LATERAL (SELECT * FROM loan_applications x WHERE x.client_id=c.id AND x.organization_id=$1 ORDER BY x.created_at DESC LIMIT 1) la ON true
    LEFT JOIN LATERAL (SELECT * FROM loans x WHERE x.client_id=c.id AND x.organization_id=$1 ORDER BY x.created_at DESC LIMIT 1) l ON true
    WHERE c.organization_id=$1 AND c.branch_id=$2
      AND (l.status IN ('active','completed','defaulted') OR la.status IN ('awaiting_approval','approved'))
    ${coFilter} ORDER BY CASE WHEN l.status='active' THEN 0 WHEN la.status IN ('awaiting_approval','approved') THEN 1 ELSE 2 END,c.created_at DESC`,params);
  res.json({clients:rows,count:rows.length});
}
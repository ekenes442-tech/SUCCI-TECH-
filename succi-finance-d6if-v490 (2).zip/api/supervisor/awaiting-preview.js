import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public';
export const methods=['GET'];
export default async function(req,res){
  const auth=await requireStaff(req,res); if(!auth)return;
  const s=auth.staff, role=String(s.role||'').toLowerCase().replace(/[-_]+/g,' ').replace(/\s+/g,' ').trim();
  if(role!=='supervisor') return res.status(403).json({error:'Supervisor access required.'});
  if(!s.organization_id||!s.branch_id)return res.status(403).json({error:'Supervisor branch is not configured.'});
  const coId=String(req.query?.credit_officer_id||'').trim();
  let coClause=''; const params=[s.organization_id,s.branch_id];
  if(coId){
    const {rows:co}=await db.query(`SELECT id FROM staff WHERE id=$1 AND organization_id=$2 AND branch_id=$3 AND deleted_at IS NULL AND lower(replace(replace(role,'-','_'),' ','_')) IN ('credit_officer','co') AND lower(coalesce(status,'active')) NOT IN ('suspended','deactivated','inactive','deleted') LIMIT 1`,[coId,s.organization_id,s.branch_id]);
    if(!co.length)return res.status(400).json({error:'Selected Credit Officer is not authorized for this branch.'});
    params.push(coId); coClause=` AND COALESCE(la.credit_officer_staff_id,c.credit_officer_id)=$3`;
  }
  const {rows}=await db.query(`SELECT la.id application_id,la.amount,la.status application_status,la.created_at,
    c.id client_id,c.full_name,c.phone,c.workflow_status,
    COALESCE((SELECT SUM(ls.amount) FROM loan_savings ls WHERE ls.organization_id=la.organization_id AND ls.loan_application_id=la.id),0)::numeric savings_paid,
    ROUND(la.amount*0.10,2)::numeric required_savings,
    COALESCE(la.credit_officer_staff_id,c.credit_officer_id) submitted_by,
    (SELECT full_name FROM staff st WHERE st.id=COALESCE(la.credit_officer_staff_id,c.credit_officer_id) AND st.organization_id=la.organization_id LIMIT 1) credit_officer_name
    FROM loan_applications la JOIN clients c ON c.id=la.client_id
    WHERE la.organization_id=$1 AND la.branch_id=$2
      AND la.status='awaiting_approval'${coClause}
      AND COALESCE((SELECT SUM(ls.amount) FROM loan_savings ls WHERE ls.organization_id=la.organization_id AND ls.branch_id=la.branch_id AND ls.loan_application_id=la.id),0) >= ROUND(la.amount*0.10,2)
      AND c.workflow_status='awaiting_approval'
      AND NOT EXISTS (SELECT 1 FROM loans lx WHERE lx.organization_id=la.organization_id AND lx.branch_id=la.branch_id AND lx.client_id=la.client_id AND lx.status IN ('active','disbursed','completed'))
    ORDER BY la.created_at DESC`,params);
  res.json({clients:rows,count:rows.length,credit_officer_id:coId||null});
}
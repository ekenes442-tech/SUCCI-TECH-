import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';

export const access = 'public';
export const methods = ['POST'];

export default async function(req, res) {
  const auth = await requireStaff(req, res);
  if (!auth) return;

  const s = auth.staff;
  const role = String(s.role || '').toLowerCase().replace(/[-_]+/g, ' ');
  if (role !== 'supervisor') return res.status(403).json({ error: 'Supervisor access required.' });
  if (!s.organization_id || !s.branch_id) return res.status(403).json({ error: 'Supervisor organization or branch is missing.' });

  const body = req.body || {};
  const applicationId = String(body.loan_application_id || '').trim();
  const decision = String(body.decision || 'approve').trim().toLowerCase();
  const reason = String(body.reason || '').trim() || null;
  const creditOfficerId = String(body.credit_officer_id || '').trim();

  if (!applicationId) return res.status(400).json({ error: 'Loan application ID is required.' });
  if (!['approve', 'reject'].includes(decision)) return res.status(400).json({ error: 'Decision must be approve or reject.' });
  if (decision === 'reject' && !reason) return res.status(400).json({ error: 'A rejection reason is required.' });

  // One authoritative application lookup. Everything below uses this same
  // organization + branch scope, so the handoff cannot cross branches.
  const applicationResult = await db.query(`
    SELECT la.id, la.organization_id, la.branch_id, la.client_id,
           la.amount, la.interest_rate, la.status,
           la.credit_officer_staff_id,
           c.full_name, c.workflow_status,
           c.repayment_frequency, c.repayment_term
    FROM loan_applications la
    JOIN clients c ON c.id = la.client_id
    WHERE la.id = $1
      AND la.organization_id = $2
      AND la.branch_id = $3
      AND c.organization_id = $2
      AND c.branch_id = $3
    LIMIT 1
  `, [applicationId, s.organization_id, s.branch_id]);

  if (!applicationResult.rows.length) {
    return res.status(404).json({ error: 'Loan application not found in your assigned branch.' });
  }

  const app = applicationResult.rows[0];
  if (app.status !== 'awaiting_approval') {
    return res.status(409).json({ error: 'This application is no longer awaiting Supervisor approval.' });
  }

  if (creditOfficerId && String(app.credit_officer_staff_id || '') !== creditOfficerId) {
    return res.status(409).json({ error: 'This application does not belong to the selected Credit Officer.' });
  }

  if (decision === 'reject') {
    await db.transaction([
      {
        sql: `UPDATE loan_applications
              SET status='rejected'
              WHERE id=$1 AND organization_id=$2 AND branch_id=$3 AND status='awaiting_approval'`,
        params: [applicationId, s.organization_id, s.branch_id]
      },
      {
        sql: `UPDATE clients
              SET workflow_status='rejected'
              WHERE id=$1 AND organization_id=$2 AND branch_id=$3`,
        params: [app.client_id, s.organization_id, s.branch_id]
      },
      {
        sql: `INSERT INTO approvals
              (organization_id,branch_id,loan_application_id,approver_staff_id,decision,reason)
              VALUES($1,$2,$3,$4,'rejected',$5)`,
        params: [s.organization_id, s.branch_id, applicationId, s.id, reason]
      }
    ]);

    return res.json({
      ok: true,
      decision: 'rejected',
      loan_application_id: applicationId,
      status: 'rejected',
      message: 'Application rejected and returned to the Credit Officer.'
    });
  }

  // The database only permits these loan states:
  // pending, approved, rejected, disbursed, active, completed, defaulted.
  // Therefore Supervisor approval creates an APPROVED loan. The Branch
  // Manager then disburses that approved loan and changes it to ACTIVE.
  const principal = Number(app.amount || 0);
  if (!(principal > 0)) return res.status(409).json({ error: 'Loan amount is invalid.' });

  // Interest is a MONTHLY return on the original principal. Example: ₦100,000 × 3% × 6 months = ₦18,000.
  const interestRate = Number(app.interest_rate ?? 3);

  const rawFrequency = String(app.repayment_frequency || 'daily').trim().toLowerCase().replace(/[\s-]+/g, '_');
  const frequencyMap = { daily: 'daily', weekly: 'weekly', monthly: 'monthly' };
  const repaymentFrequency = frequencyMap[rawFrequency];
  if (!repaymentFrequency) {
    return res.status(409).json({ error: 'The client repayment frequency is invalid. Please correct it before submitting to BM.' });
  }

  const termCount = Math.max(1, Number(app.repayment_term || 30));
  const durationMonths = repaymentFrequency === 'monthly' ? termCount : repaymentFrequency === 'weekly' ? termCount / 4 : termCount / 30;
  const interestAmount = Math.round(principal * (interestRate / 100) * durationMonths * 100) / 100;
  const totalPayable = Math.round((principal + interestAmount) * 100) / 100;

  // Guard against an accidental second loan if the action is retried.
  const existing = await db.query(`
    SELECT id, status
    FROM loans
    WHERE loan_application_id=$1
      AND organization_id=$2
      AND branch_id=$3
    LIMIT 1
  `, [applicationId, s.organization_id, s.branch_id]);

  if (existing.rows.length && !['rejected','pending'].includes(String(existing.rows[0].status||'').toLowerCase())) {
    return res.status(409).json({ error: 'This application has already been submitted to the Branch Manager.' });
  }

  const reusableLoanId = existing.rows.length ? existing.rows[0].id : null;
  const tx = await db.transaction([
    {
      sql: `UPDATE loan_applications
            SET status='approved'
            WHERE id=$1 AND organization_id=$2 AND branch_id=$3 AND status='awaiting_approval'`,
      params: [applicationId, s.organization_id, s.branch_id]
    },
    ...(reusableLoanId ? [{
      sql: `UPDATE loans
            SET principal=$1,interest_rate=$2,interest_amount=$3,total_payable=$4,repayment_frequency=$5,term_count=$6,status='approved',disbursed_at=NULL,disbursed_by=NULL
            WHERE id=$7 AND organization_id=$8 AND branch_id=$9`,
      params: [principal,interestRate,interestAmount,totalPayable,repaymentFrequency,termCount,reusableLoanId,s.organization_id,s.branch_id]
    }] : [{
      sql: `INSERT INTO loans
            (organization_id,branch_id,client_id,principal,interest_rate,interest_amount,total_payable,repayment_frequency,term_count,status,loan_application_id)
            VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,'approved',$10)
            RETURNING id`,
      params: [s.organization_id,s.branch_id,app.client_id,principal,interestRate,interestAmount,totalPayable,repaymentFrequency,termCount,applicationId]
    }]),
    {
      sql: `UPDATE clients
            SET workflow_status='awaiting_disbursement'
            WHERE id=$1 AND organization_id=$2 AND branch_id=$3`,
      params: [app.client_id, s.organization_id, s.branch_id]
    },
    {
      sql: `INSERT INTO approvals
            (organization_id,branch_id,loan_application_id,approver_staff_id,decision,reason)
            VALUES($1,$2,$3,$4,'approved',$5)`,
      params: [s.organization_id, s.branch_id, applicationId, s.id, reason]
    }
  ]);

  const loanId = reusableLoanId || tx.results?.[1]?.rows?.[0]?.id || null;
  if (!loanId) return res.status(500).json({ error: 'Supervisor approval was not completed. No loan record was created.' });

  return res.json({
    ok: true,
    decision: 'approved',
    loan_application_id: applicationId,
    loan_id: loanId,
    loan_status: 'approved',
    workflow_status: 'awaiting_disbursement',
    message: 'Approved successfully and submitted to the Branch Manager for disbursement.'
  });
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public';
export const methods=['GET'];

export default async function(req,res){
  const auth=await requireStaff(req,res); if(!auth)return;
  const s=auth.staff;
  const role=String(s.role||'').toLowerCase().replace(/[-_]+/g,' ').replace(/\s+/g,' ').trim();
  if(role!=='supervisor') return res.status(403).json({error:'Supervisor access required.'});
  if(!s.organization_id||!s.branch_id) return res.status(400).json({error:'Supervisor branch is not configured.'});

  const org=s.organization_id, branch=s.branch_id;
  const [branchInfo,clients,active,outstanding,defaulting,collections,awaiting,pending,cos]=await Promise.all([
    db.query(`SELECT b.id,b.name FROM branches b WHERE b.id=$1 AND b.organization_id=$2 LIMIT 1`,[branch,org]),
    db.query(`SELECT count(*)::int count FROM clients c WHERE c.organization_id=$1 AND c.branch_id=$2`,[org,branch]),
    db.query(`SELECT count(*)::int count FROM loans l WHERE l.organization_id=$1 AND l.branch_id=$2 AND l.status IN ('active','disbursed')`,[org,branch]),
    db.query(`SELECT COALESCE(SUM(GREATEST(COALESCE(l.total_payable,l.principal+COALESCE(l.interest_amount,0),0)-COALESCE(p.total_paid,0),0)),0)::numeric outstanding FROM loans l LEFT JOIN LATERAL (SELECT COALESCE(SUM(cr.amount_paid),0)::numeric total_paid FROM collection_records cr WHERE cr.organization_id=l.organization_id AND cr.branch_id=l.branch_id AND cr.loan_id=l.id) p ON true WHERE l.organization_id=$1 AND l.branch_id=$2 AND l.status IN ('active','disbursed')`,[org,branch]),
    db.query(`SELECT count(DISTINCT l.client_id)::int count FROM loans l WHERE l.organization_id=$1 AND l.branch_id=$2 AND l.status IN ('active','disbursed') AND l.disbursed_at IS NOT NULL AND l.disbursed_at + (COALESCE(l.term_count,30) * CASE lower(COALESCE(l.repayment_frequency,'daily')) WHEN 'weekly' THEN interval '7 days' WHEN 'monthly' THEN interval '30 days' ELSE interval '1 day' END) < CURRENT_DATE AND COALESCE((SELECT SUM(cr.amount_paid) FROM collection_records cr WHERE cr.organization_id=l.organization_id AND cr.branch_id=l.branch_id AND cr.loan_id=l.id),0) < COALESCE(l.total_payable,l.principal+COALESCE(l.interest_amount,0),0)`,[org,branch]),
    db.query(`SELECT COALESCE(SUM(COALESCE(cr.amount_paid,0)),0)::numeric amount FROM collection_records cr WHERE cr.organization_id=$1 AND cr.branch_id=$2 AND cr.collection_date=CURRENT_DATE`,[org,branch]),
    db.query(`SELECT count(*)::int count FROM loan_applications la WHERE la.organization_id=$1 AND la.branch_id=$2 AND la.status='awaiting_approval' AND NOT EXISTS (SELECT 1 FROM loans lx WHERE lx.organization_id=la.organization_id AND lx.branch_id=la.branch_id AND lx.client_id=la.client_id AND lx.status IN ('active','disbursed','completed'))`,[org,branch]),
    db.query(`SELECT count(*)::int count FROM loans l JOIN loan_applications la ON la.id=l.loan_application_id AND la.organization_id=l.organization_id AND la.branch_id=l.branch_id JOIN clients c ON c.id=l.client_id AND c.organization_id=l.organization_id AND c.branch_id=l.branch_id WHERE l.organization_id=$1 AND l.branch_id=$2 AND l.status='approved' AND la.status='approved' AND c.workflow_status='awaiting_disbursement'`,[org,branch]),
    db.query(`SELECT count(*)::int count FROM staff st WHERE st.organization_id=$1 AND st.branch_id=$2 AND st.deleted_at IS NULL AND lower(replace(replace(st.role,'-','_'),' ','_')) IN ('credit_officer','co') AND lower(coalesce(st.status,'active')) NOT IN ('suspended','deactivated','inactive','deleted')`,[org,branch])
  ]);

  res.json({
    role:s.role,
    organization_id:org,
    branch_id:branch,
    branch_name:branchInfo.rows[0]?.name||'Assigned Branch',
    clients:clients.rows[0].count,
    active_loans:active.rows[0].count,
    outstanding_loans:outstanding.rows[0].outstanding,
    defaulting_clients:defaulting.rows[0].count,
    todays_collections:collections.rows[0].amount,
    awaiting_preview:awaiting.rows[0].count,
    pending_disbursement:pending.rows[0].count,
    active_credit_officers:cos.rows[0].count
  });
}
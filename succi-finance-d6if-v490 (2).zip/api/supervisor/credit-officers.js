import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public';
export const methods=['GET'];
export default async function(req,res){
  const auth=await requireStaff(req,res); if(!auth)return;
  const s=auth.staff;
  const role=String(s.role||'').toLowerCase().replace(/[-_]+/g,' ').replace(/\s+/g,' ').trim();
  if(role!=='supervisor') return res.status(403).json({error:'Supervisor access required.'});
  if(!s.organization_id||!s.branch_id) return res.status(403).json({error:'Supervisor branch is not configured.'});
  const {rows}=await db.query(`SELECT id,full_name,phone,staff_code,status,branch_id
    FROM staff
    WHERE organization_id=$1 AND branch_id=$2 AND deleted_at IS NULL
      AND lower(replace(replace(role,'-','_'),' ','_')) IN ('credit_officer','co')
      AND lower(coalesce(status,'active')) NOT IN ('suspended','deactivated','inactive','deleted')
    ORDER BY full_name`,[s.organization_id,s.branch_id]);
  res.json({credit_officers:rows,count:rows.length});
}
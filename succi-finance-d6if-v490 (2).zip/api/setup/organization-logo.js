import { db, storage } from "hatchable";
import { requireStaff } from '../../lib/supabase-auth.js';

export const access = "public";
export const methods = ["POST"];

export default async function (req, res) {
  const auth = await requireStaff(req,res);
  if (!auth) return;
  const member = auth.user;
  const file = (req.files || []).find(f => f.field === "logo");
  if (!file) return res.status(400).json({ error: "Please select an organization logo." });
  if (!/^image\/(png|jpeg|jpg|webp|svg\+xml)$/.test(file.contentType || "")) return res.status(400).json({ error: "Logo must be PNG, JPG, WEBP, or SVG." });
  if ((file.buffer?.length || 0) > 2 * 1024 * 1024) return res.status(400).json({ error: "Logo must be 2 MB or smaller." });

  const { rows } = await db.query("SELECT organization_id FROM staff WHERE auth_user_id = $1 AND role = 'general_overseer' AND status = 'active' LIMIT 1", [member.id]);
  if (!rows[0]?.organization_id) return res.status(403).json({ error: "Organization administrator access is required." });

  const organizationId = rows[0].organization_id;
  const key = `organizations/${organizationId}/logo-${Date.now()}`;
  const url = await storage.put(key, file.buffer, file.contentType);
  await db.query("UPDATE organizations SET logo_url = $1 WHERE id = $2", [url, organizationId]);
  res.json({ ok: true, logo_url: url });
}
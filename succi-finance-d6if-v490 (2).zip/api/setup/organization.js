import { db } from 'hatchable';
import { getSupabaseUser } from '../../lib/supabase-auth.js';
export const access='public';
export const methods=['POST'];

export default async function(req,res){
  const auth=String(req.headers?.authorization||'');
  const token=auth.startsWith('Bearer ')?auth.slice(7).trim():'';
  const user=await getSupabaseUser(token);
  if(!user?.id||!user?.email)return res.status(401).json({error:'Please create or sign in to your SUCCI TECH account first.',code:'AUTH_REQUIRED'});
  const body=req.body||{};
  const name=String(body.organization_name||'').trim();
  const organizationEmail=String(body.organization_email||user.email||'').trim().toLowerCase();
  const fullName=String(body.full_name||'').trim();
  const branchName=String(body.branch_name||'').trim();
  const branchEmail=String(body.branch_email||organizationEmail).trim().toLowerCase();
  const dateFounded=body.date_founded?String(body.date_founded).trim():null;
  const registrationNumber=String(body.registration_number||'').trim();
  const organizationType=String(body.organization_type||'').trim();
  const address=String(body.address||'').trim();
  const state=String(body.state||'').trim();
  const lga=String(body.local_government_area||'').trim();
  const country=String(body.country||'Nigeria').trim();
  const history=String(body.history||'').trim();
  const mission=String(body.mission||'').trim();
  const vision=String(body.vision||'').trim();
  const coreValues=String(body.core_values||'').trim();
  if(!name||!organizationEmail||!fullName||!branchName||!branchEmail)return res.status(400).json({error:'Complete the organization name, organization email, General Overseer name, main branch name and branch email.'});
  if(!/^\S+@\S+\.\S+$/.test(organizationEmail)||!/^\S+@\S+\.\S+$/.test(branchEmail))return res.status(400).json({error:'Enter valid organization and branch email addresses.'});
  const existing=await db.query('SELECT id,organization_id FROM staff WHERE auth_user_id=$1 OR supabase_user_id=$1 OR lower(email)=lower($2) LIMIT 1',[user.id,organizationEmail]);
  if(existing.rows.length)return res.status(409).json({error:'This account is already linked to an organization. Sign in to continue.'});
  const duplicateOrg=await db.query('SELECT id FROM organizations WHERE lower(email)=lower($1) LIMIT 1',[organizationEmail]);
  if(duplicateOrg.rows.length)return res.status(409).json({error:'That organization email is already registered. Use another organization email.'});
  const organizationId=crypto.randomUUID(),branchId=crypto.randomUUID(),internalCode=`ORG-${crypto.randomUUID().slice(0,8).toUpperCase()}`;
  try{
    await db.transaction([
      {sql:`INSERT INTO organizations (id,name,code,email,date_founded,registration_number,organization_type,address,official_address,state,local_government_area,lga,country,history,mission,vision,core_values,created_by_auth_user_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8,$9,$10,$10,$11,$12,$13,$14,$15,$16)`,params:[organizationId,name,internalCode,organizationEmail,dateFounded,registrationNumber||null,organizationType||null,address||null,state||null,lga||null,country,history||null,mission||null,vision||null,coreValues||null,user.id]},
      {sql:`INSERT INTO branches (id,organization_id,name,code,email,address,created_by_auth_user_id) VALUES ($1,$2,$3,'MAIN',$4,$5,$6)`,params:[branchId,organizationId,branchName,branchEmail,address||null,user.id]},
      {sql:`INSERT INTO staff (organization_id,branch_id,auth_user_id,supabase_user_id,full_name,email,phone,role,status,created_by_auth_user_id,created_by_role) VALUES ($1,$2,$3,$3,$4,$5,NULL,'general_overseer','active',$3,'self_registration')`,params:[organizationId,branchId,user.id,fullName,organizationEmail]}
    ]);
    return res.status(201).json({ok:true,organization_id:organizationId,branch_id:branchId,role:'general_overseer',title:'General Overseer / CEO',message:'Organization created successfully.'});
  }catch(error){
    const message=String(error?.message||'');
    if(/organizations_code_key|organizations.*code/i.test(message))return res.status(409).json({error:'Organization setup could not reserve a unique organization code. Please try again.'});
    if(/duplicate|unique/i.test(message))return res.status(409).json({error:'Some organization details are already in use. Please review the email and branch details.'});
    return res.status(500).json({error:'Organization setup could not be completed. No partial organization was created.'});
  }
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const a=await requireStaff(req,res); if(!a)return; const s=a.staff;
 if(String(s.role||'').toLowerCase()!=='auditor')return res.status(403).json({error:'Auditor access required.'});
 const branchId=String(req.query?.branch_id||'').trim();
 const {rows:scope}=await db.query(`SELECT branch_id FROM auditor_branch_assignments WHERE organization_id=$1 AND auditor_staff_id=$2 AND ($3='' OR branch_id=$3)`,[s.organization_id,s.id,branchId]);
 if(!scope.length)return res.status(403).json({error:'Branch is not assigned to this auditor.'});
 const ids=scope.map(x=>x.branch_id);
 const {rows}=await db.query(`SELECT c.id,c.full_name,c.phone,c.workflow_status,c.collection_day,c.branch_id,b.name branch_name,COALESCE(SUM(ls.amount),0)::numeric total_savings,COUNT(DISTINCT l.id)::int loan_count,COALESCE(SUM(cr.amount_paid),0)::numeric total_repaid FROM clients c JOIN branches b ON b.id=c.branch_id LEFT JOIN loan_savings ls ON ls.client_id=c.id AND ls.organization_id=c.organization_id LEFT JOIN loans l ON l.client_id=c.id AND l.organization_id=c.organization_id LEFT JOIN collection_records cr ON cr.client_id=c.id AND cr.organization_id=c.organization_id WHERE c.organization_id=$1 AND c.branch_id=ANY($2::uuid[]) GROUP BY c.id,b.id ORDER BY b.name,c.full_name`,[s.organization_id,ids]);
 res.json({clients:rows,branch_ids:ids});
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const a=await requireStaff(req,res); if(!a)return; const s=a.staff;
 const branchId=String(req.query?.branch_id||'').trim(); const month=String(req.query?.month||new Date().toISOString().slice(0,7)).trim();
 if(!branchId)return res.status(400).json({error:'Select an assigned branch.'});
 if(!/^\d{4}-\d{2}$/.test(month))return res.status(400).json({error:'Invalid report month.'});
 const assigned=await db.query('SELECT b.id,b.name FROM auditor_branch_assignments a JOIN branches b ON b.id=a.branch_id AND b.organization_id=a.organization_id WHERE a.organization_id=$1 AND a.auditor_staff_id=$2 AND b.id=$3 LIMIT 1',[s.organization_id,s.id,branchId]);
 if(!assigned.rows.length)return res.status(403).json({error:'This branch is not assigned to you.'});
 const start=month+'-01';
 const {rows}=await db.query(`SELECT d.id disbursement_id,d.amount,d.disbursed_at,d.status,c.id client_id,c.full_name client_name,c.phone client_phone,l.id loan_id,l.principal,l.interest_rate,COALESCE(co.full_name,'Unassigned') disbursed_by,COALESCE(co.phone,'') officer_phone FROM disbursements d JOIN loans l ON l.id=d.loan_id JOIN clients c ON c.id=l.client_id LEFT JOIN staff co ON co.id=d.disbursed_by_staff_id WHERE d.organization_id=$1 AND d.branch_id=$2 AND d.status='completed' AND d.disbursed_at >= $3::date AND d.disbursed_at < ($3::date + INTERVAL '1 month') ORDER BY d.disbursed_at DESC,c.full_name`,[s.organization_id,branchId,start]);
 res.json({branch:assigned.rows[0],month,month_label:new Date(start+'T00:00:00').toLocaleDateString('en-NG',{month:'long',year:'numeric'}),disbursements:rows,total_disbursed:rows.reduce((n,r)=>n+Number(r.amount||0),0),count:rows.length,note:'Read-only branch disbursement history. Auditor access is limited to assigned branches.'});
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const a=await requireStaff(req,res); if(!a)return; const s=a.staff;
 if(String(s.role||'').toLowerCase().replace(/[-_]+/g,' ')!=='auditor')return res.status(403).json({error:'Auditor access required.'});
 if(!s.branch_id)return res.status(403).json({error:'Auditor is not assigned to a branch.'});
 const loanId=String(req.query?.loan_id||'').trim(); if(!loanId)return res.status(400).json({error:'Loan ID is required.'});
 const {rows}=await db.query(`SELECT l.id loan_id,l.client_id,l.principal,l.interest_rate,l.interest_amount,l.total_payable,l.repayment_frequency,l.term_count,l.status,l.disbursed_at,c.full_name,c.phone,c.address,c.loan_purpose,c.workflow_status,COALESCE(SUM(cr.amount_paid),0)::numeric total_paid,COALESCE(SUM(cr.savings_amount),0)::numeric total_savings,COUNT(cr.id)::int collection_entries FROM loans l JOIN clients c ON c.id=l.client_id LEFT JOIN collection_records cr ON cr.loan_id=l.id AND cr.organization_id=l.organization_id AND cr.branch_id=l.branch_id WHERE l.id=$1 AND l.organization_id=$2 AND l.branch_id=$3 AND l.status='completed' AND c.workflow_status='audit_pending' GROUP BY l.id,c.id LIMIT 1`,[loanId,s.organization_id,s.branch_id]);
 if(!rows.length)return res.status(404).json({error:'Completed loan not found in your assigned branch.'});
 const loan=rows[0];
 const {rows:payments}=await db.query(`SELECT collection_date,amount_due,amount_paid,savings_amount,status,audited FROM collection_records WHERE loan_id=$1 AND organization_id=$2 AND branch_id=$3 ORDER BY collection_date ASC,created_at ASC`,[loanId,s.organization_id,s.branch_id]);
 const {rows:guarantors}=await db.query(`SELECT guarantor_number,full_name,phone,relationship,occupation,address,id_type,id_number FROM client_guarantors WHERE client_id=$1 AND organization_id=$2 AND branch_id=$3 ORDER BY guarantor_number`,[loan.client_id,s.organization_id,s.branch_id]);
 res.json({loan,payments,guarantors});
}
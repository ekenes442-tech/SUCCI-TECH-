import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['POST'];
export default async function(req,res){
 const a=await requireStaff(req,res); if(!a)return; const s=a.staff;
 const role=String(s.role||'').toLowerCase().replace(/[-_]+/g,' ').trim(); if(role!=='auditor')return res.status(403).json({error:'Auditor access required.'});
 const body=req.body||{},recordId=String(body.collection_record_id||'').trim(),reason=String(body.reason||'').trim();
 if(!recordId||!reason)return res.status(400).json({error:'Collection record and correction reason are required.'});
 const amountPaid=Number(body.amount_paid),savingsAmount=Number(body.savings_amount),amountDue=Number(body.amount_due);
 if(!Number.isFinite(amountPaid)||!Number.isFinite(savingsAmount)||!Number.isFinite(amountDue)||amountPaid<0||savingsAmount<0||amountDue<0)return res.status(400).json({error:'Enter valid non-negative repayment values.'});
 const {rows}=await db.query(`SELECT cr.*,c.full_name client_name FROM collection_records cr JOIN clients c ON c.id=cr.client_id JOIN auditor_branch_assignments ba ON ba.branch_id=cr.branch_id AND ba.organization_id=cr.organization_id WHERE cr.id=$1 AND cr.organization_id=$2 AND ba.auditor_staff_id=$3 LIMIT 1`,[recordId,s.organization_id,s.id]);
 if(!rows.length)return res.status(404).json({error:'Repayment record is not in an assigned branch.'});
 const old=rows[0];
 await db.transaction([
  {sql:`UPDATE collection_records SET amount_due=$1,amount_paid=$2,savings_amount=$3,audited=true WHERE id=$4 AND organization_id=$5 AND branch_id=$6`,params:[amountDue,amountPaid,savingsAmount,recordId,s.organization_id,old.branch_id]},
  {sql:`INSERT INTO audit_records(organization_id,branch_id,collection_record_id,auditor_staff_id,action,reason) VALUES($1,$2,$3,$4,'repayment_corrected',$5)`,params:[s.organization_id,old.branch_id,recordId,s.id,reason]},
  {sql:`INSERT INTO security_events(organization_id,actor_auth_user_id,actor_role,event_type,target_type,target_id,reason,metadata) VALUES($1,$2,$3,'auditor_repayment_correction','collection_record',$4,$5,$6)`,params:[s.organization_id,a.auth?.user?.id||null,s.role,recordId,reason,JSON.stringify({client_id:old.client_id,old_amount_due:old.amount_due,old_amount_paid:old.amount_paid,old_savings_amount:old.savings_amount,new_amount_due:amountDue,new_amount_paid:amountPaid,new_savings_amount:savingsAmount})]}
 ]);
 res.json({ok:true,message:'Repayment correction saved and audit logged.',collection_record_id:recordId});
}
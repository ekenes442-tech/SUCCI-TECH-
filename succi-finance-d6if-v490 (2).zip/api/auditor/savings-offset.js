import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['POST'];
export default async function(req,res){
 const a=await requireStaff(req,res); if(!a)return; const s=a.staff;
 const role=String(s.role||'').toLowerCase().replace(/[-_]+/g,' ').trim();
 if(role!=='auditor')return res.status(403).json({error:'Auditor access required.'});
 const branch=String(req.body?.branch_id||s.branch_id||'').trim(); const source=String(req.body?.source_client_id||'').trim(), target=String(req.body?.target_client_id||'').trim(), loan=String(req.body?.target_loan_id||'').trim(), reason=String(req.body?.reason||'').trim();
 const amount=Number(req.body?.amount||0);
 if(!source||!target||!loan||!(amount>0)||!reason)return res.status(400).json({error:'Source client, target client, target loan, amount, and reason are required.'});
 if(source===target)return res.status(400).json({error:'Source and target clients must be different.'});
 const assigned=await db.query(`SELECT 1 FROM auditor_branch_assignments WHERE organization_id=$1 AND auditor_staff_id=$2 AND branch_id=$3 LIMIT 1`,[s.organization_id,s.id,branch]);
 if(!assigned.rows.length)return res.status(403).json({error:'You are not assigned to this branch.'});
 const src=await db.query(`SELECT id,branch_id,full_name FROM clients WHERE id=$1 AND organization_id=$2 LIMIT 1`,[source,s.organization_id]);
 const dst=await db.query(`SELECT c.id,c.branch_id,c.full_name,l.id loan_id,l.status,l.total_payable,COALESCE((SELECT SUM(cr.amount_paid) FROM collection_records cr WHERE cr.organization_id=$2 AND cr.client_id=c.id AND cr.loan_id=l.id),0) paid,COALESCE((SELECT SUM(o.amount) FROM auditor_savings_offsets o WHERE o.organization_id=$2 AND o.target_loan_id=l.id),0) offset_amount FROM clients c JOIN loans l ON l.id=$3 AND l.client_id=c.id AND l.organization_id=$2 WHERE c.id=$1 AND c.organization_id=$2 LIMIT 1`,[target,s.organization_id,loan]);
 if(!src.rows.length||!dst.rows.length)return res.status(404).json({error:'Source client or target loan not found.'});
 const sourceSavings=await db.query(`SELECT COALESCE(SUM(cr.savings_amount),0)::numeric savings FROM collection_records cr WHERE cr.organization_id=$1 AND cr.client_id=$2 AND cr.branch_id=$3`,[s.organization_id,source,branch]);
 const used=await db.query(`SELECT COALESCE(SUM(amount),0)::numeric used FROM auditor_savings_offsets WHERE organization_id=$1 AND source_client_id=$2`,[s.organization_id,source]);
 const available=Number(sourceSavings.rows[0].savings||0)-Number(used.rows[0].used||0);
 const d=dst.rows[0]; const outstanding=Math.max(Number(d.total_payable||0)-Number(d.paid||0)-Number(d.offset_amount||0),0);
 if(Number(amount)>available)return res.status(400).json({error:'Amount exceeds Client A available savings.',available_savings:available});
 if(Number(amount)>outstanding)return res.status(400).json({error:'Amount exceeds Client B overdue loan outstanding balance.',outstanding_balance:outstanding});
 await db.transaction([
  {sql:`INSERT INTO auditor_savings_offsets(organization_id,branch_id,source_client_id,target_client_id,target_loan_id,amount,reason,auditor_staff_id) VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,params:[s.organization_id,branch,source,target,loan,amount,reason,s.id]},
  {sql:`INSERT INTO audit_records(organization_id,branch_id,collection_record_id,auditor_staff_id,action,reason) VALUES($1,$2,NULL,$3,'savings_offset_applied',$4)`,params:[s.organization_id,branch,s.id,`₦${amount.toFixed(2)} savings transferred from ${src.rows[0].full_name} to ${d.full_name} overdue loan. ${reason}`]}
 ]);
 res.json({ok:true,amount,source_client:src.rows[0].full_name,target_client:d.full_name,remaining_source_savings:available-amount,remaining_target_balance:outstanding-amount,message:'Savings offset recorded successfully.'});
}
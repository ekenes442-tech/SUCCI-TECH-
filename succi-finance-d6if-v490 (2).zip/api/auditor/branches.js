import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const a=await requireStaff(req,res); if(!a)return; const s=a.staff;
 const role=String(s.role||'').toLowerCase().replace(/[-_]+/g,' ').trim(); if(role!=='auditor')return res.status(403).json({error:'Auditor access required.'});
 const {rows}=await db.query(`SELECT b.id,b.name,b.email,b.address,ba.created_at assigned_at FROM auditor_branch_assignments ba JOIN branches b ON b.id=ba.branch_id WHERE ba.organization_id=$1 AND ba.auditor_staff_id=$2 ORDER BY b.name`,[s.organization_id,s.id]);
 res.json({branches:rows});
}
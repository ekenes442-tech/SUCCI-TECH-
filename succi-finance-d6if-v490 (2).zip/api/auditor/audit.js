import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['POST'];
export default async function(req,res){
 const a=await requireStaff(req,res); if(!a)return; const s=a.staff; const role=String(s.role||'').toLowerCase().replace(/[-_]+/g,' ');
 if(role!=='auditor')return res.status(403).json({error:'Auditor access required.'});
 const loanId=String(req.body?.loan_id||'').trim(); const decision=String(req.body?.decision||'approve').toLowerCase(); const reason=String(req.body?.reason||'').trim()||null;
 if(!loanId)return res.status(400).json({error:'Loan ID is required.'});
 if(!['approve','flag'].includes(decision))return res.status(400).json({error:'Decision must be approve or flag.'});
 const {rows}=await db.query(`SELECT l.id,l.client_id,l.total_payable,l.status,c.full_name,c.workflow_status FROM loans l JOIN clients c ON c.id=l.client_id WHERE l.id=$1 AND l.organization_id=$2 AND l.branch_id=$3 LIMIT 1`,[loanId,s.organization_id,s.branch_id]);
 if(!rows.length)return res.status(404).json({error:'Loan not found in your assigned branch.'});
 const l=rows[0]; if(l.status!=='completed'||l.workflow_status!=='audit_pending')return res.status(409).json({error:'This loan is not waiting for audit.'});
 await db.transaction([
  {sql:`INSERT INTO audit_records(organization_id,branch_id,collection_record_id,auditor_staff_id,action,reason) VALUES($1,$2,NULL,$3,$4,$5)`,params:[s.organization_id,s.branch_id,s.id,decision==='approve'?'loan_completion_approved':'loan_completion_flagged',reason]},
  {sql:`UPDATE clients SET workflow_status=$1 WHERE id=$2 AND organization_id=$3 AND branch_id=$4`,params:[decision==='approve'?'completed':'audit_flagged',l.client_id,s.organization_id,s.branch_id]}
 ]);
 res.json({ok:true,loan_id:loanId,decision,status:decision==='approve'?'completed':'audit_flagged',message:decision==='approve'?'Audit completed successfully.':'Loan completion flagged for review.'});
}
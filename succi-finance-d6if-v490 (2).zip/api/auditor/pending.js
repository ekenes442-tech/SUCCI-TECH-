import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const a=await requireStaff(req,res); if(!a)return; const s=a.staff; const role=String(s.role||'').toLowerCase().replace(/[-_]+/g,' ').trim();
 if(role!=='auditor')return res.status(403).json({error:'Auditor access required.'});
 const assigned=await db.query(`SELECT branch_id FROM auditor_branch_assignments WHERE organization_id=$1 AND auditor_staff_id=$2 ORDER BY branch_id`,[s.organization_id,s.id]);
 const branchIds=assigned.rows.map(x=>x.branch_id); if(!branchIds.length)return res.status(403).json({error:'No branches are assigned to this Auditor.'});
 const {rows}=await db.query(`SELECT l.id loan_id,l.client_id,l.branch_id,l.principal,l.interest_amount,l.total_payable,l.repayment_frequency,l.term_count,l.status,l.disbursed_at,c.full_name client_name,c.phone,c.workflow_status,COALESCE(SUM(cr.amount_paid),0)::numeric total_paid,COUNT(cr.id)::int collection_entries FROM loans l JOIN clients c ON c.id=l.client_id LEFT JOIN collection_records cr ON cr.loan_id=l.id AND cr.organization_id=l.organization_id AND cr.branch_id=l.branch_id WHERE l.organization_id=$1 AND l.branch_id=ANY($2::uuid[]) AND l.status='completed' AND c.workflow_status='audit_pending' GROUP BY l.id,c.id ORDER BY l.disbursed_at DESC`,[s.organization_id,branchIds]);
 res.json({loans:rows,count:rows.length,branch_ids:branchIds});
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const a=await requireStaff(req,res); if(!a)return; const s=a.staff;
 const role=String(s.role||'').toLowerCase().replace(/[-_]+/g,' ').trim(); if(role!=='auditor')return res.status(403).json({error:'Auditor access required.'});
 const date=String(req.query?.date||'').trim(); const coId=String(req.query?.co_id||'').trim();
 const base=[s.organization_id,s.id];
 const scope=`cr.organization_id=$1 AND EXISTS (SELECT 1 FROM auditor_branch_assignments aba WHERE aba.organization_id=cr.organization_id AND aba.branch_id=cr.branch_id AND aba.auditor_staff_id=$2)`;
 if(!date&&!coId){
  const dates=await db.query(`SELECT DISTINCT cr.collection_date FROM collection_records cr WHERE ${scope} ORDER BY cr.collection_date DESC LIMIT 180`,base);
  return res.json({dates:dates.rows.map(x=>String(x.collection_date).slice(0,10))});
 }
 if(date&&!coId){
  const cos=await db.query(`SELECT DISTINCT st.id,st.full_name FROM collection_records cr JOIN staff st ON st.id=cr.entered_by_staff_id WHERE ${scope} AND cr.collection_date=$3 AND lower(replace(replace(st.role,'-','_'),' ','_')) IN ('credit_officer','co') ORDER BY st.full_name`,[...base,date]);
  return res.json({credit_officers:cos.rows});
 }
 if(!date||!coId)return res.status(400).json({error:'Select a collection date and Credit Officer collection sheet.'});
 const rows=await db.query(`SELECT cr.id,cr.collection_date,cr.amount_due,cr.amount_paid,cr.savings_amount,cr.status,cr.audited,c.full_name client_name,b.name branch_name,st.full_name credit_officer_name FROM collection_records cr JOIN clients c ON c.id=cr.client_id JOIN branches b ON b.id=cr.branch_id JOIN staff st ON st.id=cr.entered_by_staff_id WHERE ${scope} AND cr.collection_date=$3 AND cr.entered_by_staff_id=$4 ORDER BY c.full_name`,[...base,date,coId]);
 res.json({records:rows.rows});
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const a=await requireStaff(req,res); if(!a)return; const s=a.staff;
 const role=String(s.role||'').toLowerCase().replace(/[-_]+/g,' '); if(role!=='auditor')return res.status(403).json({error:'Auditor access required.'});
 const {rows}=await db.query(`SELECT ar.id,ar.action,ar.reason,ar.created_at,b.name branch_name,c.full_name client_name FROM audit_records ar LEFT JOIN branches b ON b.id=ar.branch_id LEFT JOIN collection_records cr ON cr.id=ar.collection_record_id LEFT JOIN clients c ON c.id=cr.client_id WHERE ar.organization_id=$1 AND ar.auditor_staff_id=$2 ORDER BY ar.created_at DESC LIMIT 200`,[s.organization_id,s.id]);
 res.json({history:rows});
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const a=await requireStaff(req,res); if(!a)return; const s=a.staff;
 if(String(s.role||'').toLowerCase()!=='auditor')return res.status(403).json({error:'Auditor access required.'});
 const clientId=String(req.query?.client_id||'').trim(); if(!clientId)return res.status(400).json({error:'Client ID is required.'});
 const {rows:scope}=await db.query(`SELECT c.id,c.branch_id FROM clients c JOIN auditor_branch_assignments ba ON ba.branch_id=c.branch_id AND ba.organization_id=c.organization_id WHERE c.id=$1 AND c.organization_id=$2 AND ba.auditor_staff_id=$3 LIMIT 1`,[clientId,s.organization_id,s.id]);
 if(!scope.length)return res.status(404).json({error:'Client is not in an assigned branch.'});
 const {rows:client}=await db.query(`SELECT c.*,b.name branch_name,b.email branch_email FROM clients c JOIN branches b ON b.id=c.branch_id WHERE c.id=$1 AND c.organization_id=$2 LIMIT 1`,[clientId,s.organization_id]);
 const {rows:savings}=await db.query(`SELECT ls.id,ls.amount,ls.created_at,ls.loan_application_id,st.full_name created_by FROM loan_savings ls LEFT JOIN staff st ON st.id=ls.created_by_staff_id WHERE ls.client_id=$1 AND ls.organization_id=$2 ORDER BY ls.created_at ASC`,[clientId,s.organization_id]);
 const {rows:loans}=await db.query(`SELECT l.id,l.principal,l.interest,l.total_due,l.status,l.disbursed_at,l.disbursed_by_staff_id,st.full_name disbursed_by FROM loans l LEFT JOIN staff st ON st.id=l.disbursed_by_staff_id WHERE l.client_id=$1 AND l.organization_id=$2 ORDER BY l.created_at ASC`,[clientId,s.organization_id]);
 const {rows:disbursements}=await db.query(`SELECT d.id,d.loan_id,d.amount,d.status,d.disbursed_at,st.full_name disbursed_by FROM disbursements d LEFT JOIN staff st ON st.id=d.disbursed_by_staff_id WHERE d.client_id IS NULL AND d.organization_id=$1 AND d.branch_id=$2 AND d.loan_id IN (SELECT id FROM loans WHERE client_id=$3) ORDER BY d.disbursed_at ASC`,[s.organization_id,scope[0].branch_id,clientId]);
 const {rows:payments}=await db.query(`SELECT cr.id,cr.loan_id,cr.collection_date,cr.amount_due,cr.amount_paid,cr.savings_amount,cr.status,cr.audited,cr.entered_by_staff_id,st.full_name entered_by FROM collection_records cr LEFT JOIN staff st ON st.id=cr.entered_by_staff_id WHERE cr.client_id=$1 AND cr.organization_id=$2 AND cr.branch_id=$3 ORDER BY cr.collection_date ASC,cr.created_at ASC`,[clientId,s.organization_id,scope[0].branch_id]);
 const {rows:guarantors}=await db.query(`SELECT guarantor_number,full_name,phone,relationship,occupation,address,id_type,id_number,passport_photo_url FROM client_guarantors WHERE client_id=$1 AND organization_id=$2 AND branch_id=$3 ORDER BY guarantor_number`,[clientId,s.organization_id,scope[0].branch_id]);
 const {rows:collateral_images}=await db.query(`SELECT id,image_url,description,created_at FROM client_collateral_images WHERE client_id=$1 AND organization_id=$2 AND branch_id=$3 ORDER BY created_at DESC`,[clientId,s.organization_id,scope[0].branch_id]);
 res.json({client:client[0],savings,loans,disbursements,payments,guarantors,collateral_images});
}
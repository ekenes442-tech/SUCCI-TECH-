import { db } from "hatchable";
export const access = "public";
export default async function(req,res){
  const { rows } = await db.query("SELECT key,value FROM app_settings WHERE key LIKE 'launch_%'");
  const cfg={
    background_color:'#e5091b',title:'SUCCI TECH',subtitle:'Microfinance Management',show_title:true,show_subtitle:false,logo_url:null,
    duration_seconds:10,text_color:'#ffffff',font_family:'Inter',transition:'fade',loading_style:'none',
    logo_position:'center',title_position:'center',subtitle_position:'center',animation_effect:'fade',
    launch_page:'primary',secondary_launch_enabled:true
  };
  for(const r of rows){const k=r.key.replace(/^launch_/,'');try{cfg[k]=JSON.parse(r.value)}catch{cfg[k]=r.value}}
  res.setHeader('Cache-Control','no-store');res.json(cfg);
}
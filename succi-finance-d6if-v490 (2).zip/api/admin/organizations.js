import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public';
export const methods=['GET'];
async function requireSystemAdmin(req,res){
 const a=await requireStaff(req,res); if(!a)return null;
 const email=String(a.user?.email||a.staff?.email||'').trim().toLowerCase();
 const uid=String(a.user?.id||'').trim();
 const {rows}=await db.query("SELECT id FROM system_admin_identities WHERE status='active' AND (auth_user_id=$1 OR lower(email)=lower($2)) LIMIT 1",[uid,email]);
 if(!rows[0]){res.status(403).json({error:'System Admin access required.'});return null;}
 return a;
}
export default async function(req,res){await requireSystemAdmin(req,res);if(res.headersSent)return;const {rows}=await db.query(`SELECT o.id,o.name,o.status,o.created_at,COUNT(DISTINCT b.id)::int branch_count,COUNT(DISTINCT s.id)::int staff_count FROM organizations o LEFT JOIN branches b ON b.organization_id=o.id LEFT JOIN staff s ON s.organization_id=o.id GROUP BY o.id ORDER BY o.created_at DESC`);res.json({admin_email:req.member?.email||null,organizations:rows});}
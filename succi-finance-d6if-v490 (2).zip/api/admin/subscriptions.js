import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public';
async function requireSystemAdmin(req,res){
 const a=await requireStaff(req,res); if(!a)return null;
 const email=String(a.user?.email||a.staff?.email||'').trim().toLowerCase();
 const uid=String(a.user?.id||'').trim();
 const {rows}=await db.query("SELECT id FROM system_admin_identities WHERE status='active' AND (auth_user_id=$1 OR lower(email)=lower($2)) LIMIT 1",[uid,email]);
 if(!rows[0]){res.status(403).json({error:'System Admin access required.'});return null;}
 return a;
}
export const methods=['GET','POST','PUT'];
export default async function(req,res){
 await requireSystemAdmin(req,res);
 if(res.headersSent)return;
 const {rows:plans}=await db.query("SELECT id,name,billing_interval,amount,currency,trial_days,active FROM subscription_plans ORDER BY billing_interval");
 if(req.method==='GET') return res.json({plans});
 if(req.method==='PUT'){
  const b=req.body||{}; if(!b.id)return res.status(400).json({error:'Subscription plan ID is required.'});
  const amount=Number(b.amount); if(!Number.isFinite(amount)||amount<0)return res.status(400).json({error:'Enter a valid subscription amount.'});
  await db.query('UPDATE subscription_plans SET name=$1,amount=$2,currency=$3,active=$4 WHERE id=$5',[String(b.name||'').trim(),amount,String(b.currency||'NGN').trim().toUpperCase(),Boolean(b.active),b.id]);
  return res.json({ok:true,message:'Subscription plan updated.'});
 }
 const b=req.body||{}; if(!b.organization_id||!b.plan_id)return res.status(400).json({error:'Organization and subscription plan are required.'});
 const {rows:existing}=await db.query("SELECT id FROM organization_subscriptions WHERE organization_id=$1 AND status IN ('trialing','active','past_due') LIMIT 1",[b.organization_id]);
 if(existing.length)return res.status(409).json({error:'This organization already has a current subscription.'});
 const {rows:p}=await db.query('SELECT * FROM subscription_plans WHERE id=$1 AND active=true LIMIT 1',[b.plan_id]); if(!p[0])return res.status(404).json({error:'Subscription plan not found or inactive.'});
 const now=new Date(),trialEnd=new Date(now.getTime()+30*86400000),periodEnd=new Date(trialEnd); if(p[0].billing_interval==='yearly')periodEnd.setFullYear(periodEnd.getFullYear()+1); else periodEnd.setMonth(periodEnd.getMonth()+1);
 const {rows}=await db.query("INSERT INTO organization_subscriptions (organization_id,plan_id,status,trial_start_at,trial_end_at,current_period_start,current_period_end,created_by_admin) VALUES ($1,$2,'trialing',$3,$4,$3,$5,$6) RETURNING id,status,trial_end_at,current_period_end",[b.organization_id,b.plan_id,now,trialEnd,periodEnd,req.member?.id||'system-admin']);
 return res.status(201).json({ok:true,subscription:rows[0],message:'Organization subscription created with a 30-day free trial.'});
}
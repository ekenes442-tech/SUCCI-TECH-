import { db } from 'hatchable';
import { requireStaff } from '../lib/supabase-auth.js';
export const access='public';
async function requireSystemAdmin(req,res){
 const a=await requireStaff(req,res); if(!a)return null;
 const email=String(a.user?.email||a.staff?.email||'').trim().toLowerCase();
 const uid=String(a.user?.id||'').trim();
 const {rows}=await db.query("SELECT id FROM system_admin_identities WHERE status='active' AND (auth_user_id=$1 OR lower(email)=lower($2)) LIMIT 1",[uid,email]);
 if(!rows[0]){res.status(403).json({error:'System Admin access required.'});return null;}
 return a;
}
export const methods=['GET','POST','PUT'];
export default async function(req,res){
 const auth=await requireSystemAdmin(req,res);
 if(res.headersSent||!auth)return;
 if(req.method==='GET'){
  const cid=String(req.query?.conversation_id||'').trim();
  if(cid){const {rows}=await db.query('SELECT id,sender_id,sender_role,message,created_at,read_at FROM admin_messages WHERE conversation_id=$1 ORDER BY created_at ASC',[cid]);await db.query("UPDATE admin_messages SET read_at=COALESCE(read_at,now()) WHERE conversation_id=$1 AND sender_role <> 'admin'",[cid]);return res.json({messages:rows});}
  const {rows}=await db.query('SELECT c.id,c.organization_id,c.subject,c.status,c.created_at,c.updated_at,COUNT(m.id)::int message_count,MAX(m.created_at) last_message_at FROM admin_conversations c LEFT JOIN admin_messages m ON m.conversation_id=c.id GROUP BY c.id ORDER BY c.updated_at DESC LIMIT 100');return res.json({conversations:rows});
 }
 if(req.method==='POST'){
  const b=req.body||{},cid=String(b.conversation_id||'').trim(),msg=String(b.message||'').trim();if(!cid||!msg)return res.status(400).json({error:'Conversation and message are required.'});const ok=await db.query('SELECT id FROM admin_conversations WHERE id=$1 LIMIT 1',[cid]);if(!ok.rows[0])return res.status(404).json({error:'Conversation not found.'});const {rows}=await db.query("INSERT INTO admin_messages(conversation_id,sender_id,sender_role,message) VALUES($1,$2,'admin',$3) RETURNING id,conversation_id,sender_role,message,created_at",[cid,auth.user.id,msg]);await db.query('UPDATE admin_conversations SET updated_at=now(),status=\'open\' WHERE id=$1',[cid]);return res.status(201).json(rows[0]);
 }
 const b=req.body||{};if(!b.conversation_id)return res.status(400).json({error:'Conversation is required.'});await db.query("UPDATE admin_conversations SET status='closed',updated_at=now() WHERE id=$1",[b.conversation_id]);res.json({ok:true,status:'closed'});
}
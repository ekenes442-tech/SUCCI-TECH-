import { db } from 'hatchable';
export const access='member';
export const methods=['GET','PUT'];

async function getStaff(member){
  const byAuth=await db.query(`SELECT id,organization_id,role,status FROM staff WHERE auth_user_id=$1 LIMIT 1`,[member.id]);
  if(byAuth.rows.length) return byAuth.rows[0];
  if(member.email){
    const byEmail=await db.query(`SELECT id,organization_id,role,status FROM staff WHERE lower(email)=lower($1) LIMIT 1`,[member.email]);
    if(byEmail.rows.length){
      await db.query(`UPDATE staff SET auth_user_id=$1 WHERE id=$2 AND auth_user_id IS NULL`,[member.id,byEmail.rows[0].id]);
      return byEmail.rows[0];
    }
  }
  return null;
}
function isGO(role){return String(role||'').trim().toLowerCase().replaceAll(' ','_')==='general_overseer'}
export default async function(req,res){
  const staff=await getStaff(req.member);
  if(!staff || staff.status!=='active') return res.status(403).json({error:'No active SUCCI TECH staff profile is linked to this account.'});
  if(!isGO(staff.role)) return res.status(403).json({error:'Only the General Overseer can access organization loan interest settings.'});
  if(req.method==='GET'){
    let q=await db.query(`SELECT interest_rate,savings_rate,updated_at,updated_by FROM organization_loan_settings WHERE organization_id=$1`,[staff.organization_id]);
    if(!q.rows.length){
      q=await db.query(`INSERT INTO organization_loan_settings(organization_id,interest_rate,savings_rate,updated_by) VALUES($1,3,10,$2) RETURNING interest_rate,savings_rate,updated_at,updated_by`,[staff.organization_id,staff.id]);
    }
    return res.json({organization_id:staff.organization_id,...q.rows[0]});
  }
  if(!isGO(staff.role)) return res.status(403).json({error:'Only the General Overseer can change the organization interest rate.'});
  const rate=Number(req.body?.interest_rate);
  if(!Number.isFinite(rate)||rate<0||rate>100) return res.status(400).json({error:'Interest rate must be between 0% and 100%.'});
  const q=await db.query(`INSERT INTO organization_loan_settings(organization_id,interest_rate,savings_rate,updated_by) VALUES($1,$2,10,$3) ON CONFLICT(organization_id) DO UPDATE SET interest_rate=EXCLUDED.interest_rate,updated_at=now(),updated_by=EXCLUDED.updated_by RETURNING interest_rate,savings_rate,updated_at,updated_by`,[staff.organization_id,rate,staff.id]);
  return res.json({ok:true,organization_id:staff.organization_id,...q.rows[0]});
}
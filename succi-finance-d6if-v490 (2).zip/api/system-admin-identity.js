import { db } from 'hatchable';
import { requireStaff } from '../lib/supabase-auth.js';
export const access='public';
export const methods=['GET'];
export default async function(req,res){const a=await requireStaff(req,res);if(!a)return;const email=String(a.user?.email||'').trim().toLowerCase();if(email!=='ekenes442@gmail.com')return res.status(403).json({error:'System Admin access required.'});await db.query("UPDATE system_admin_identities SET auth_user_id=$1,status='active',activated_at=COALESCE(activated_at,now()),updated_at=now() WHERE lower(email)=lower($2)",[a.user.id,email]);res.json({ok:true,role:'system_admin',email,display_name:'SUCCI TECH System Admin'});}
import { db } from 'hatchable';
import { requireBranchManager } from '../../lib/branch-access.js';
export const access='public';
export default async function(req,res){
 const scope=await requireBranchManager(req,res); if(!scope)return;
 const {staff,branch}=scope,org=staff.organization_id,branchId=branch.id;
 const coId=String(req.query?.co_id||'').trim();
 const coFilter=coId?' AND COALESCE(la.credit_officer_staff_id,c.credit_officer_id)=$3':'';
 const coParams=coId?[org,branchId,coId]:[org,branchId];
 const orgResult=await db.query("SELECT name FROM organizations WHERE id=$1 LIMIT 1",[org]);
 const organization_name=orgResult.rows[0]?.name||'SUCCI TECH Demo Organization';
 const [clients,loans,pending,defaults,collections,perf]=await Promise.all([
  db.query("SELECT count(*)::int total FROM clients c WHERE c.organization_id=$1 AND c.branch_id=$2",[org,branchId]),
  db.query("SELECT count(*)::int total,COALESCE(SUM(GREATEST(COALESCE(l.total_payable,l.principal+COALESCE(l.interest_amount,0),0)-COALESCE(p.total_paid,0),0)),0)::numeric outstanding FROM loans l LEFT JOIN LATERAL (SELECT COALESCE(SUM(cr.amount_paid),0)::numeric total_paid FROM collection_records cr WHERE cr.loan_id=l.id AND cr.organization_id=l.organization_id AND cr.branch_id=l.branch_id) p ON true WHERE l.organization_id=$1 AND l.branch_id=$2 AND l.status IN ('active','disbursed')",[org,branchId]),
  db.query("SELECT count(*)::int total FROM loans l JOIN loan_applications la ON la.id=l.loan_application_id AND la.organization_id=l.organization_id AND la.branch_id=l.branch_id JOIN clients c ON c.id=l.client_id AND c.organization_id=l.organization_id AND c.branch_id=l.branch_id WHERE l.organization_id=$1 AND l.branch_id=$2 AND l.status='approved' AND la.status='approved' AND c.workflow_status='awaiting_disbursement' AND EXISTS (SELECT 1 FROM approvals a WHERE a.organization_id=l.organization_id AND a.branch_id=l.branch_id AND a.loan_application_id=la.id AND a.decision='approved')",[org,branchId]),
  db.query("SELECT count(DISTINCT l.client_id)::int total FROM loans l WHERE l.organization_id=$1 AND l.branch_id=$2 AND l.status IN ('active','disbursed') AND l.disbursed_at IS NOT NULL AND l.disbursed_at + (COALESCE(l.term_count,30) * CASE lower(COALESCE(l.repayment_frequency,'daily')) WHEN 'weekly' THEN interval '7 days' WHEN 'monthly' THEN interval '30 days' ELSE interval '1 day' END) < CURRENT_DATE AND COALESCE((SELECT SUM(cr.amount_paid) FROM collection_records cr WHERE cr.organization_id=l.organization_id AND cr.branch_id=l.branch_id AND cr.loan_id=l.id),0) < COALESCE(l.total_payable,l.principal+COALESCE(l.interest_amount,0),0)",[org,branchId]),
  db.query("SELECT COALESCE(SUM(amount_due),0)::numeric expected,COALESCE(SUM(amount_paid),0)::numeric collected FROM collection_records WHERE organization_id=$1 AND branch_id=$2 AND collection_date=CURRENT_DATE",[org,branchId]),
  db.query("SELECT st.id,st.full_name credit_officer,count(DISTINCT l.client_id)::int clients,COALESCE(SUM(cr.amount_due),0)::numeric expected,COALESCE(SUM(cr.amount_paid),0)::numeric collected,COALESCE(SUM(GREATEST(cr.amount_due-cr.amount_paid,0)),0)::numeric overdue FROM staff st LEFT JOIN loan_applications la ON la.credit_officer_staff_id=st.id AND la.organization_id=$1 AND la.branch_id=$2 LEFT JOIN loans l ON l.loan_application_id=la.id AND l.organization_id=$1 AND l.branch_id=$2 AND l.status IN ('active','disbursed') LEFT JOIN collection_records cr ON cr.loan_id=l.id AND cr.organization_id=$1 AND cr.branch_id=$2 AND cr.collection_date=CURRENT_DATE WHERE st.organization_id=$1 AND st.branch_id=$2 AND lower(COALESCE(st.role,''))='credit_officer' AND st.status='active' AND st.deleted_at IS NULL GROUP BY st.id,st.full_name ORDER BY st.full_name",[org,branchId])
 ]);
 const expected=Number(collections.rows[0]?.expected||0),collected=Number(collections.rows[0]?.collected||0);
 const performance=perf.rows.map(x=>({...x,rate:Number(x.expected||0)?Number(x.collected||0)/Number(x.expected)*100:0}));
 res.json({display_name:staff.full_name,organization_name,branch_name:branch.name,active_clients:clients.rows[0].total,active_loans:loans.rows[0].total,pending_disbursements:pending.rows[0].total,defaulting_clients:defaults.rows[0].total,expected_today:expected,collected_today:collected,collection_rate:expected?collected/expected*100:0,outstanding_portfolio:loans.rows[0].outstanding,performance});
}
import { db } from 'hatchable';
import { requireBranchManager } from '../../lib/branch-access.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const scope=await requireBranchManager(req,res); if(!scope)return;
 const id=req.query?.id;if(!id)return res.status(400).json({error:'Loan id is required'});
 const {staff,branch}=scope;
 const {rows}=await db.query(`SELECT l.id loan_id,l.principal,l.interest_rate,l.interest_amount,l.total_payable,l.repayment_frequency,l.term_count,l.status,l.created_at,l.disbursed_at,c.id client_id,c.full_name client_name,c.phone,c.address,c.occupation,c.employer_business_name,c.business_address,c.state,c.lga,c.gender,c.date_of_birth,c.client_type,c.loan_purpose,c.repayment_frequency client_repayment_frequency,c.repayment_term client_repayment_term,c.savings_required,c.collection_day,c.passport_photo_url,c.next_of_kin_name,c.next_of_kin_relationship,c.next_of_kin_phone,c.next_of_kin_address,COALESCE(st.full_name,'Unassigned') credit_officer,COALESCE(sup.full_name,'Unassigned') supervisor,la.created_at application_submitted_at,la.status application_status,ap.created_at supervisor_approved_at FROM loans l JOIN clients c ON c.id=l.client_id LEFT JOIN loan_applications la ON la.id=l.loan_application_id LEFT JOIN staff st ON st.id=la.credit_officer_staff_id LEFT JOIN LATERAL (SELECT a.created_at,a.approver_staff_id FROM approvals a WHERE a.organization_id=l.organization_id AND a.branch_id=l.branch_id AND a.loan_application_id=la.id AND a.decision='approved' ORDER BY a.created_at DESC LIMIT 1) ap ON true LEFT JOIN staff sup ON sup.id=ap.approver_staff_id WHERE l.id=$1 AND l.organization_id=$2 AND l.branch_id=$3 AND l.status='approved' AND la.status='approved' AND c.workflow_status='awaiting_disbursement' AND ap.approver_staff_id IS NOT NULL LIMIT 1`,[id,staff.organization_id,branch.id]);
 if(!rows[0])return res.status(404).json({error:'Loan not found in this branch pending queue'});
 const g=await db.query(`SELECT guarantor_number,full_name,phone,relationship,occupation,address,id_type,id_number,passport_photo_url FROM client_guarantors WHERE organization_id=$1 AND branch_id=$2 AND client_id=(SELECT client_id FROM loans WHERE id=$3 AND organization_id=$1 AND branch_id=$2) ORDER BY guarantor_number`,[staff.organization_id,branch.id,id]);
 const r=rows[0];
 r.guarantors=g.rows;
 r.collateral_images=(await db.query('SELECT id,image_url,description,created_at FROM client_collateral_images WHERE client_id=(SELECT client_id FROM loans WHERE id=$1 AND organization_id=$2 AND branch_id=$3 LIMIT 1) AND organization_id=$2 AND branch_id=$3 ORDER BY created_at DESC',[id,staff.organization_id,branch.id])).rows;
 r.client_id=(await db.query('SELECT client_id FROM loans WHERE id=$1 AND organization_id=$2 AND branch_id=$3 LIMIT 1',[id,staff.organization_id,branch.id])).rows[0]?.client_id||null;
 res.json(r);
}
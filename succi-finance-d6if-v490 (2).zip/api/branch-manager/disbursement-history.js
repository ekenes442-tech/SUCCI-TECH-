import { db } from 'hatchable';
import { requireBranchManager } from '../../lib/branch-access.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const scope=await requireBranchManager(req,res); if(!scope)return;
 const {staff,branch}=scope; const date=String(req.query?.date||'').trim(),coId=String(req.query?.co_id||'').trim();
 if(!/^\d{4}-\d{2}-\d{2}$/.test(date))return res.json({disbursements:[],total_disbursed:0,branch});
 const p=[staff.organization_id,branch.id,date]; let extra='';
 if(coId){p.push(coId);extra=` AND d.disbursed_by_staff_id=$${p.length}`;}
 const {rows}=await db.query(`SELECT d.id disbursement_id,d.amount,d.disbursed_at,c.id client_id,c.full_name client_name,COALESCE(co.full_name,'Unassigned') co_name,l.id loan_id,l.principal,l.total_due FROM disbursements d JOIN loans l ON l.id=d.loan_id JOIN clients c ON c.id=l.client_id LEFT JOIN staff co ON co.id=d.disbursed_by_staff_id WHERE d.organization_id=$1 AND d.branch_id=$2 AND d.status='completed' AND (d.disbursed_at AT TIME ZONE 'Africa/Lagos')::date=$3${extra} ORDER BY c.full_name`,p);
 res.json({disbursements:rows,total_disbursed:rows.reduce((n,r)=>n+Number(r.amount||0),0),branch});
}
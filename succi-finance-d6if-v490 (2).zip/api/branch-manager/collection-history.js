import { db } from 'hatchable';
import { requireBranchManager } from '../../lib/branch-access.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const scope=await requireBranchManager(req,res); if(!scope)return;
 const {rows}=await db.query(`SELECT cr.id,cr.client_id,cr.loan_id,cr.collection_date,cr.amount_due,cr.amount_paid,cr.savings_amount,cr.status,cr.audited,c.full_name client_name,s.full_name entered_by_name,b.name branch_name FROM collection_records cr JOIN clients c ON c.id=cr.client_id JOIN branches b ON b.id=cr.branch_id LEFT JOIN staff s ON s.id=cr.entered_by_staff_id WHERE cr.organization_id=$1 AND cr.branch_id=$2 AND c.organization_id=$1 AND c.branch_id=$2 ORDER BY cr.collection_date DESC,cr.created_at DESC`,[scope.staff.organization_id,scope.staff.branch_id]);
 res.json({collections:rows,count:rows.length,branch:scope.branch});
}
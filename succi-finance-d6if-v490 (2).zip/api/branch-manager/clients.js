import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public';
export const methods=['GET'];
export default async function(req,res){
  const auth=await requireStaff(req,res); if(!auth)return;
  const staff=auth.staff;
  const role=String(staff.role||'').toLowerCase().replace(/[-_]+/g,' ').trim();
  if(!(role==='branch manager'||role==='bm'||role.includes('branch manager'))){res.status(403).json({error:'Branch Manager access required.',code:'ROLE_FORBIDDEN'});return;}
  if(!staff.organization_id||!staff.branch_id){res.status(403).json({error:'Your Branch Manager account has no assigned branch.',code:'BRANCH_ASSIGNMENT_REQUIRED'});return;}
  const {rows:branchRows}=await db.query('SELECT id,name,status FROM branches WHERE id=$1 AND organization_id=$2 LIMIT 1',[staff.branch_id,staff.organization_id]);
  if(!branchRows.length){res.status(403).json({error:'Assigned branch is invalid for this organization.',code:'BRANCH_SCOPE_INVALID'});return;}
  const branch=branchRows[0];
  const coId=String(req.query?.credit_officer_id||'').trim();
  const params=[staff.organization_id,branch.id];
  let coFilter='';
  if(coId){
    params.push(coId);
    coFilter=` AND COALESCE(la.credit_officer_staff_id,c.credit_officer_id)=$${params.length}`;
  }
  const {rows}=await db.query(`
    SELECT c.id,c.full_name,c.phone,c.workflow_status,c.created_at,
      la.id application_id,la.status application_status,la.amount,
      l.id loan_id,l.status loan_status,l.disbursed_at,
      (SELECT full_name FROM staff st WHERE st.id=COALESCE(la.credit_officer_staff_id,c.credit_officer_id) AND st.organization_id=$1 LIMIT 1) credit_officer_name,
      CASE WHEN l.id IS NOT NULL THEN 1 ELSE 0 END loan_count
    FROM clients c
    LEFT JOIN LATERAL (SELECT * FROM loan_applications x WHERE x.client_id=c.id AND x.organization_id=$1 ORDER BY x.created_at DESC LIMIT 1) la ON true
    LEFT JOIN LATERAL (SELECT * FROM loans x WHERE x.client_id=c.id AND x.organization_id=$1 ORDER BY x.created_at DESC LIMIT 1) l ON true
    WHERE c.organization_id=$1 AND c.branch_id=$2
      ${coFilter}
    ORDER BY c.full_name` ,params);
  res.json({clients:rows,count:rows.length,branch});
}
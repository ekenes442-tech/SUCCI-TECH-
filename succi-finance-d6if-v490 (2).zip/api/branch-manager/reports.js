import { db } from 'hatchable';
import { requireBranchManager } from '../../lib/branch-access.js';
export const access='public';
export const methods=['GET'];

export default async function(req,res){
  const scope=await requireBranchManager(req,res); if(!scope)return;
  const {staff,branch}=scope;
  const month=String(req.query?.month||new Date().toISOString().slice(0,7)).trim();
  if(!/^\d{4}-\d{2}$/.test(month))return res.status(400).json({error:'Month must be YYYY-MM.'});
  const start=month+'-01';
  const endExpr=`($3::date + INTERVAL '1 month')::date`;
  const org=staff.organization_id,bid=branch.id;
  const [branchInfo,collections,loans,expenses,dailyAccounts,clients,staffCount,overdue]=await Promise.all([
    db.query(`SELECT id,name,email FROM branches WHERE id=$1 AND organization_id=$2 LIMIT 1`,[bid,org]),
    db.query(`SELECT COALESCE(SUM(cr.amount_paid),0)::numeric total_collected,COALESCE(SUM(cr.savings_amount),0)::numeric total_savings,COALESCE(SUM(cr.amount_paid) FILTER(WHERE cr.loan_id IS NULL),0)::numeric daily_collection_amount,COALESCE(SUM(cr.amount_paid) FILTER(WHERE cr.loan_id IS NOT NULL),0)::numeric loan_repayment_amount FROM collection_records cr WHERE cr.organization_id=$1 AND cr.branch_id=$2 AND cr.collection_date >= $3::date AND cr.collection_date < ${endExpr}`,[org,bid,start]),
    db.query(`SELECT COUNT(*)::int loan_count,COALESCE(SUM(d.amount),0)::numeric principal_disbursed,COALESCE(SUM(l.interest_amount),0)::numeric loan_profit,COALESCE(SUM(l.total_payable),0)::numeric expected_total FROM disbursements d JOIN loans l ON l.id=d.loan_id WHERE d.organization_id=$1 AND d.branch_id=$2 AND d.status='completed' AND d.disbursed_at >= $3::date AND d.disbursed_at < ${endExpr}`,[org,bid,start]),
    db.query(`SELECT COALESCE(SUM(amount),0)::numeric total_expenses FROM branch_expenses WHERE organization_id=$1 AND branch_id=$2 AND expense_date >= $3::date AND expense_date < ${endExpr}`,[org,bid,start]),
    db.query(`SELECT COUNT(*)::int accounts,COALESCE(SUM(monthly_charge),0)::numeric monthly_charges FROM service_accounts WHERE organization_id=$1 AND branch_id=$2 AND service_type='daily_collection' AND status='active' AND created_at < ${endExpr}`,[org,bid,start]),
    db.query(`SELECT COUNT(*)::int total FROM clients WHERE organization_id=$1 AND branch_id=$2`,[org,bid]),
    db.query(`SELECT COUNT(*)::int total FROM staff WHERE organization_id=$1 AND branch_id=$2 AND deleted_at IS NULL AND status='active'`,[org,bid]),
    db.query(`SELECT COALESCE(SUM(GREATEST(cr.amount_due-cr.amount_paid,0)),0)::numeric overdue_amount,COUNT(DISTINCT cr.client_id)::int clients FROM collection_records cr WHERE cr.organization_id=$1 AND cr.branch_id=$2 AND cr.collection_date < CURRENT_DATE AND cr.amount_due > cr.amount_paid`,[org,bid])
  ]);
  const c=collections.rows[0]||{},l=loans.rows[0]||{},e=expenses.rows[0]||{},da=dailyAccounts.rows[0]||{};
  const dailyCollectionProfit=Number(da.monthly_charges||0);
  const loanProfit=Number(l.loan_profit||0);
  const totalIncome=dailyCollectionProfit+loanProfit;
  const totalExpenses=Number(e.total_expenses||0);
  const netProfit=totalIncome-totalExpenses;
  const monthLabel=new Date(start+'T00:00:00').toLocaleDateString('en-NG',{month:'long',year:'numeric'});
  res.json({
    report:'Branch Profit & Loss',month,month_label:monthLabel,
    branch:{id:branchInfo.rows[0]?.id||bid,name:branchInfo.rows[0]?.name||branch.name,email:branchInfo.rows[0]?.email||''},
    summary:{
      daily_collection_profit:dailyCollectionProfit,
      loan_profit:loanProfit,
      total_income:totalIncome,
      total_expenses:totalExpenses,
      net_profit:netProfit
    },
    collections:{total_collected:Number(c.total_collected||0),total_savings:Number(c.total_savings||0),daily_collection_amount:Number(c.daily_collection_amount||0),loan_repayment_amount:Number(c.loan_repayment_amount||0)},
    disbursements:{loan_count:Number(l.loan_count||0),principal_disbursed:Number(l.principal_disbursed||0),interest_profit:Number(l.loan_profit||0),expected_total:Number(l.expected_total||0)},
    daily_collection:{active_accounts:Number(da.accounts||0),monthly_charges:Number(da.monthly_charges||0)},
    expenses:{total:Number(e.total_expenses||0)},
    branch_stats:{clients:Number(clients.rows[0]?.total||0),active_staff:Number(staffCount.rows[0]?.total||0),overdue_amount:Number(overdue.rows[0]?.overdue_amount||0),overdue_clients:Number(overdue.rows[0]?.clients||0)},
    formula:'Daily Collection Profit + Loan Profit - Branch Expenses = Net Branch Profit',
    note:'Daily Collection Profit is calculated from configured monthly charges on active Daily Collection accounts. Loan Profit is the interest attached to loans disbursed during the selected month; loan principal is not counted as profit.'
  });
}
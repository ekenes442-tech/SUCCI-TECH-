import { db } from 'hatchable';
import { requireBranchManager } from '../../lib/branch-access.js';
export const access='public';
export const methods=['GET','POST'];
export default async function(req,res){
 const scope=await requireBranchManager(req,res); if(!scope)return;
 const {staff:actor,branch}=scope;
 const branchId=branch.id, orgId=actor.organization_id;
 if(req.method==='POST'){
  const b=req.body||{}; const date=String(b.expense_date||'').trim()||new Date().toISOString().slice(0,10); const category=String(b.category||'').trim(); const description=String(b.description||'').trim(); const amount=Number(b.amount);
  if(!category||!Number.isFinite(amount)||amount<=0)return res.status(400).json({error:'Category and a positive amount are required.'});
  const {rows}=await db.query(`INSERT INTO branch_expenses(organization_id,branch_id,expense_date,category,description,amount,created_by_staff_id) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id,expense_date,category,description,amount,created_at`,[orgId,branchId,date,category,description||null,amount,actor.id]);
  return res.status(201).json({expense:rows[0]});
 }
 const q=req.query||{}; const date=String(q.date||'').trim();
 let where='organization_id=$1 AND branch_id=$2', params=[orgId,branchId];
 if(date){where+=' AND expense_date=$3';params.push(date)}
 const {rows}=await db.query(`SELECT id,expense_date,category,description,amount,created_at FROM branch_expenses WHERE ${where} ORDER BY expense_date DESC,created_at DESC`,params);
 const total=rows.reduce((s,x)=>s+Number(x.amount||0),0);
 const today=new Date().toISOString().slice(0,10);
 const {rows:period}=await db.query(`SELECT COALESCE(SUM(CASE WHEN expense_date=$3 THEN amount ELSE 0 END),0)::numeric today, COALESCE(SUM(CASE WHEN expense_date>=($3::date-INTERVAL '6 days')::date AND expense_date<=$3 THEN amount ELSE 0 END),0)::numeric week, COALESCE(SUM(CASE WHEN date_trunc('month',expense_date)=date_trunc('month',$3::date) THEN amount ELSE 0 END),0)::numeric monthly FROM branch_expenses WHERE organization_id=$1 AND branch_id=$2`,[orgId,branchId,today]);
 res.json({expenses:rows,total,summary:{daily:Number(period[0]?.today||0),weekly:Number(period[0]?.week||0),monthly:Number(period[0]?.month||0)}});
}
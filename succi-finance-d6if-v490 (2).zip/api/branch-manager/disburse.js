import { db } from 'hatchable';
import { requireBranchManager } from '../../lib/branch-access.js';

export const access = 'public';
export const methods = ['POST'];

export default async function(req, res) {
  const scope = await requireBranchManager(req, res);
  if (!scope) return;

  const orgId = scope.staff.organization_id;
  const branchId = scope.staff.branch_id;
  const loanId = String(req.body?.loan_id || '').trim();
  const decision = String(req.body?.decision || 'disburse').trim().toLowerCase();
  const reason = String(req.body?.reason || '').trim() || null;

  if (!loanId) return res.status(400).json({ error: 'Loan ID is required.' });
  if (!['disburse', 'reject'].includes(decision)) return res.status(400).json({ error: 'Decision must be disburse or reject.' });
  if (decision === 'reject' && !reason) return res.status(400).json({ error: 'A rejection reason is required.' });

  const result = await db.query(`
    SELECT l.id,l.organization_id,l.branch_id,l.client_id,l.principal,l.status,l.loan_application_id,
           c.full_name,c.workflow_status
    FROM loans l
    JOIN clients c ON c.id=l.client_id
    WHERE l.id=$1
      AND l.organization_id=$2
      AND l.branch_id=$3
      AND c.organization_id=$2
      AND c.branch_id=$3
    LIMIT 1
  `, [loanId, orgId, branchId]);

  if (!result.rows.length) {
    return res.status(403).json({ error: 'This loan is outside your assigned branch or organization.', code: 'BRANCH_SCOPE_FORBIDDEN' });
  }

  const loan = result.rows[0];
  const workflow = await db.query(`SELECT la.status AS application_status,c.workflow_status,EXISTS (SELECT 1 FROM approvals a WHERE a.organization_id=l.organization_id AND a.branch_id=l.branch_id AND a.loan_application_id=l.loan_application_id AND a.decision='approved') AS supervisor_approved FROM loans l JOIN loan_applications la ON la.id=l.loan_application_id AND la.organization_id=l.organization_id AND la.branch_id=l.branch_id JOIN clients c ON c.id=l.client_id AND c.organization_id=l.organization_id AND c.branch_id=l.branch_id WHERE l.id=$1 AND l.organization_id=$2 AND l.branch_id=$3`,[loan.id,orgId,branchId]);
  const wf=workflow.rows[0];
  if (loan.status !== 'approved' || !wf || wf.application_status !== 'approved' || wf.workflow_status !== 'awaiting_disbursement' || !wf.supervisor_approved) {
    return res.status(409).json({ error: 'This loan is not awaiting Branch Manager disbursement.', code: 'INVALID_DISBURSEMENT_STATE' });
  }

  if (decision === 'reject') {
    await db.transaction([
      {
        sql: `UPDATE loans SET status='rejected'
              WHERE id=$1 AND organization_id=$2 AND branch_id=$3 AND status='approved'`,
        params: [loan.id, orgId, branchId]
      },
      {
        sql: `UPDATE clients SET workflow_status='awaiting_approval'
              WHERE id=$1 AND organization_id=$2 AND branch_id=$3`,
        params: [loan.client_id, orgId, branchId]
      },
      {
        sql: `UPDATE loan_applications SET status='rejected'
              WHERE id=$1 AND organization_id=$2 AND branch_id=$3`,
        params: [loan.loan_application_id, orgId, branchId]
      },
      {
        sql: `INSERT INTO approvals
              (organization_id,branch_id,loan_application_id,approver_staff_id,decision,reason)
              VALUES($1,$2,$3,$4,'rejected',$5)`,
        params: [orgId, branchId, loan.loan_application_id, scope.staff.id, reason]
      },
      {
        sql: `INSERT INTO security_events
              (organization_id,actor_auth_user_id,actor_role,event_type,target_type,target_id,reason,metadata)
              VALUES($1,$2,$3,'loan_disbursement_rejected','loan',$4,$5,$6)`,
        params: [orgId, scope.user.id, scope.staff.role, loan.id, reason, JSON.stringify({ branch_id: branchId, client_id: loan.client_id })]
      }
    ]);

    return res.json({ ok: true, loan_id: loan.id, decision: 'rejected', status: 'rejected', reason });
  }

  await db.transaction([
    {
      sql: `UPDATE loans
            SET status='active',disbursed_at=now(),disbursed_by=$1
            WHERE id=$2 AND organization_id=$3 AND branch_id=$4 AND status='approved'`,
      params: [scope.staff.id, loan.id, orgId, branchId]
    },
    {
      sql: `INSERT INTO disbursements
            (organization_id,branch_id,loan_id,amount,disbursed_by_staff_id,status,disbursed_at)
            SELECT $1,$2,$3,principal,$4,'completed',now()
            FROM loans
            WHERE id=$3 AND organization_id=$1 AND branch_id=$2`,
      params: [orgId, branchId, loan.id, scope.staff.id]
    },
    {
      sql: `INSERT INTO collection_records
            (organization_id,branch_id,client_id,loan_id,collection_date,amount_due,amount_paid,savings_amount,status,entered_by_staff_id)
            SELECT $1,$2,l.client_id,l.id,
                   (CURRENT_DATE + CASE lower(l.repayment_frequency) WHEN 'weekly' THEN ((g.n-1)*7) WHEN 'monthly' THEN ((g.n-1)*30) ELSE (g.n-1) END)::date,
                   CASE WHEN g.n=l.term_count THEN ROUND((l.total_payable - ROUND(l.total_payable/l.term_count,2)*(g.n-1))::numeric,2) ELSE ROUND((l.total_payable/l.term_count)::numeric,2) END,
                   0,0,'default',$4
            FROM loans l CROSS JOIN LATERAL generate_series(1,l.term_count) g(n)
            WHERE l.id=$3 AND l.organization_id=$1 AND l.branch_id=$2
              AND NOT EXISTS (SELECT 1 FROM collection_records cr WHERE cr.organization_id=$1 AND cr.branch_id=$2 AND cr.loan_id=l.id)`,
      params: [orgId, branchId, loan.id, scope.staff.id]
    },
    {
      sql: `UPDATE loan_applications SET status='disbursed'
            WHERE id=$1 AND organization_id=$2 AND branch_id=$3`,
      params: [loan.loan_application_id, orgId, branchId]
    },
    {
      sql: `UPDATE clients SET workflow_status='active'
            WHERE id=$1 AND organization_id=$2 AND branch_id=$3`,
      params: [loan.client_id, orgId, branchId]
    },
    {
      sql: `INSERT INTO security_events
            (organization_id,actor_auth_user_id,actor_role,event_type,target_type,target_id,reason,metadata)
            VALUES($1,$2,$3,'loan_disbursed','loan',$4,NULL,$5)`,
      params: [orgId, scope.user.id, scope.staff.role, loan.id, JSON.stringify({ branch_id: branchId, client_id: loan.client_id })]
    }
  ]);

  return res.json({ ok: true, loan_id: loan.id, branch_id: branchId, status: 'active', decision: 'disbursed', message: 'Loan successfully disbursed.' });
}
import { db } from 'hatchable';
import { requireBranchManager } from '../../lib/branch-access.js';
export const access='public';
export const methods=['GET'];
export default async function(req,res){
 const scope=await requireBranchManager(req,res); if(!scope)return;
 const {staff,branch}=scope; const orgId=staff.organization_id, branchId=branch.id; const coId=String(req.query?.co_id||'').trim(), search=String(req.query?.search||'').trim();
 const params=[orgId,branchId]; let extra=''; if(coId){params.push(coId);extra+=' AND COALESCE(la.credit_officer_staff_id,c.credit_officer_id)=$'+params.length;} if(search){params.push('%'+search+'%');extra+=` AND c.full_name ILIKE $${params.length}`;}
 const {rows}=await db.query(`SELECT l.id AS loan_id,c.full_name AS client_name,l.principal,l.interest_rate,l.interest_amount,l.total_payable,l.repayment_frequency,l.term_count,la.id AS application_id,COALESCE(st.full_name,'Unassigned') AS credit_officer,COALESCE(la.credit_officer_staff_id,c.credit_officer_id) AS credit_officer_id,ap.approver_name AS supervisor,ap.created_at AS submitted_at
   FROM loans l
   JOIN clients c ON c.id=l.client_id
   JOIN loan_applications la ON la.id=l.loan_application_id AND la.organization_id=l.organization_id AND la.branch_id=l.branch_id
   LEFT JOIN staff st ON st.id=COALESCE(la.credit_officer_staff_id,c.credit_officer_id) AND st.organization_id=l.organization_id
   JOIN LATERAL (SELECT a.created_at,s.full_name AS approver_name FROM approvals a LEFT JOIN staff s ON s.id=a.approver_staff_id AND s.organization_id=a.organization_id WHERE a.organization_id=l.organization_id AND a.branch_id=l.branch_id AND a.loan_application_id=la.id AND a.decision='approved' ORDER BY a.created_at DESC LIMIT 1) ap ON true
   WHERE l.organization_id=$1 AND l.branch_id=$2 AND l.status='approved' AND la.status='approved' AND c.workflow_status='awaiting_disbursement' ${extra}
   ORDER BY ap.created_at DESC`,params);
 const {rows:creditOfficers}=await db.query(`SELECT id,full_name,staff_code FROM staff WHERE organization_id=$1 AND branch_id=$2 AND deleted_at IS NULL AND lower(replace(replace(role,'-','_'),' ','_')) IN ('credit_officer','co') AND lower(coalesce(status,'active')) NOT IN ('suspended','deactivated','inactive','deleted') ORDER BY full_name`,[orgId,branchId]);
 res.json({loans:rows,count:rows.length,credit_officers:creditOfficers,branch:{id:branchId,name:branch.name}});
}
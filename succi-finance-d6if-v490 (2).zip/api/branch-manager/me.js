import { db } from 'hatchable';
import { requireBranchManager } from '../../lib/branch-access.js';

export const access = 'public';
export const methods = ['GET'];

export default async function(req, res) {
  const scope = await requireBranchManager(req, res);
  if (!scope) return;

  const { staff, branch } = scope;
  const { rows } = await db.query(
    `SELECT o.name AS organization_name
       FROM organizations o
      WHERE o.id = $1
      LIMIT 1`,
    [staff.organization_id]
  );

  return res.json({
    id: staff.id,
    name: staff.full_name,
    full_name: staff.full_name,
    email: staff.email,
    role: 'Branch Manager',
    organization_id: staff.organization_id,
    organization_name: rows[0]?.organization_name || 'SUCCI TECH',
    branch_id: branch.id,
    branch_name: branch.name
  });
}
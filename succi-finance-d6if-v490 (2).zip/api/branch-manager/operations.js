import { db } from 'hatchable';
import { requireBranchManager } from '../../lib/branch-access.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const scope=await requireBranchManager(req,res); if(!scope)return;
 const {staff,branch}=scope,orgId=staff.organization_id,branchId=branch.id;
 const [clients,loans,pending,collections,defaults,disb]=await Promise.all([
  db.query(`SELECT COUNT(*)::int count FROM clients WHERE organization_id=$1 AND branch_id=$2`,[orgId,branchId]),
  db.query(`SELECT COUNT(*)::int count,COALESCE(SUM(outstanding_balance),0)::numeric outstanding FROM loans WHERE organization_id=$1 AND branch_id=$2 AND status='active'`,[orgId,branchId]),
  db.query(`SELECT COUNT(*)::int count FROM loans WHERE organization_id=$1 AND branch_id=$2 AND status='approved'`,[orgId,branchId]),
  db.query(`SELECT COALESCE(SUM(amount_paid),0)::numeric total FROM collection_records WHERE organization_id=$1 AND branch_id=$2 AND collection_date=CURRENT_DATE`,[orgId,branchId]),
  db.query(`SELECT COUNT(*)::int count FROM loans WHERE organization_id=$1 AND branch_id=$2 AND status='active' AND COALESCE(overdue_amount,0)>0`,[orgId,branchId]),
  db.query(`SELECT COALESCE(SUM(principal),0)::numeric total FROM loans WHERE organization_id=$1 AND branch_id=$2 AND status IN ('active','approved')`,[orgId,branchId])
 ]);
 const staffRows=await db.query(`SELECT s.id,s.full_name,COUNT(DISTINCT la.id)::int loans,COUNT(DISTINCT CASE WHEN l.status='active' THEN l.id END)::int active_loans,COALESCE(SUM(CASE WHEN l.status='active' THEN l.outstanding_balance ELSE 0 END),0)::numeric outstanding FROM staff s LEFT JOIN loan_applications la ON la.credit_officer_staff_id=s.id AND la.organization_id=$1 AND la.branch_id=$2 LEFT JOIN loans l ON l.loan_application_id=la.id AND l.organization_id=$1 AND l.branch_id=$2 WHERE s.organization_id=$1 AND s.branch_id=$2 AND lower(COALESCE(s.role,'')) LIKE '%credit officer%' GROUP BY s.id,s.full_name ORDER BY s.full_name`,[orgId,branchId]);
 res.json({display_name:staff.full_name,branch_name:branch.name,summary:{clients:+clients.rows[0].count,activeLoans:+loans.rows[0].count,outstanding:+loans.rows[0].outstanding,pendingDisbursements:+pending.rows[0].count,collectionsToday:+collections.rows[0].total,defaulting:+defaults.rows[0].count,totalLoanExposure:+disb.rows[0].total},creditOfficers:staffRows.rows});
}
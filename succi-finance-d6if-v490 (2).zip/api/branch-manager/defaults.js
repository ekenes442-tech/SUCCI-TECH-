import { db } from 'hatchable';
import { requireBranchManager } from '../../lib/branch-access.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const scope=await requireBranchManager(req,res); if(!scope)return;
 const {staff,branch}=scope,org=staff.organization_id,bid=branch.id,coId=String(req.query?.co_id||'').trim(),search=String(req.query?.search||'').trim();
 const p=[org,bid]; let extra=''; if(coId){p.push(coId);extra+=' AND COALESCE(la.credit_officer_staff_id,c.credit_officer_id)=$'+p.length;} if(search){p.push('%'+search+'%');extra+=` AND c.full_name ILIKE $${p.length}`;}
 const {rows}=await db.query(`SELECT c.full_name client_name,COALESCE(st.full_name,'Unassigned') co_name,l.id loan_id,l.id loan_number,COALESCE(SUM(cr.amount_due),0)::numeric expected,COALESCE(SUM(cr.amount_paid),0)::numeric paid,COALESCE(SUM(GREATEST(cr.amount_due-cr.amount_paid,0)),0)::numeric arrears,COUNT(*) FILTER(WHERE cr.amount_due>cr.amount_paid)::int days_overdue FROM loans l JOIN clients c ON c.id=l.client_id LEFT JOIN loan_applications la ON la.id=l.loan_application_id AND la.organization_id=$1 AND la.branch_id=$2 LEFT JOIN staff st ON st.id=COALESCE(la.credit_officer_staff_id,c.credit_officer_id) AND st.organization_id=$1 LEFT JOIN collection_records cr ON cr.loan_id=l.id AND cr.organization_id=$1 AND cr.branch_id=$2 WHERE l.organization_id=$1 AND l.branch_id=$2 AND l.status IN ('active','disbursed') ${extra} GROUP BY c.full_name,st.full_name,l.id HAVING COALESCE(SUM(GREATEST(cr.amount_due-cr.amount_paid,0)),0)>0 ORDER BY arrears DESC`,p);
 res.json({clients:rows,count:rows.length});
}
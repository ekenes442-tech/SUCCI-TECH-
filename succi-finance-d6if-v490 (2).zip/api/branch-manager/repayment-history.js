import { db } from 'hatchable';
import { requireBranchManager } from '../../lib/branch-access.js';
export const access='public';
export const methods=['GET'];
export default async function(req,res){
  const scope=await requireBranchManager(req,res); if(!scope)return;
  const {staff,branch}=scope;
  const requestedCo=String(req.query?.credit_officer_id||'').trim();
  const date=String(req.query?.date||'').match(/^\d{4}-\d{2}-\d{2}$/)?String(req.query.date):new Date().toLocaleDateString('en-CA',{timeZone:'Africa/Lagos'});
  let effectiveCo=requestedCo||null;
  if(effectiveCo){
    const {rows}=await db.query(`SELECT id FROM staff WHERE id=$1 AND organization_id=$2 AND branch_id=$3 AND lower(replace(replace(role,'-','_'),' ','_')) IN ('credit_officer','co') AND lower(coalesce(status,'active')) NOT IN ('suspended','deactivated','inactive','deleted') LIMIT 1`,[effectiveCo,staff.organization_id,branch.id]);
    if(!rows.length)return res.status(400).json({error:'Selected Credit Officer is not authorized for this branch.'});
  }
  const {rows}=await db.query(`
    WITH selected AS (
      SELECT cr.id,cr.client_id,cr.loan_id,cr.collection_date,cr.amount_due,cr.amount_paid,cr.savings_amount,cr.status,cr.audited,
        c.full_name client_name,c.collection_day,c.group_name,
        COALESCE(st.full_name,'Unassigned') co_name
      FROM collection_records cr
      JOIN clients c ON c.id=cr.client_id
      LEFT JOIN staff st ON st.id=cr.entered_by_staff_id
      WHERE cr.organization_id=$1 AND cr.branch_id=$2
        AND ($3::uuid IS NULL OR cr.entered_by_staff_id=$3 OR c.credit_officer_id=$3)
        AND cr.collection_date=$4
    ), totals AS (
      SELECT cr.client_id,cr.loan_id,
        COALESCE(SUM(cr.amount_paid),0)::numeric total_paid,
        COALESCE(SUM(cr.savings_amount),0)::numeric total_savings
      FROM collection_records cr
      WHERE cr.organization_id=$1 AND cr.branch_id=$2 AND cr.collection_date<=$4
      GROUP BY cr.client_id,cr.loan_id
    )
    SELECT s.*,l.principal,l.interest_amount,l.total_payable,
      CASE WHEN s.loan_id IS NOT NULL THEN GREATEST(COALESCE(l.total_payable,l.principal+COALESCE(l.interest_amount,0),0)-COALESCE(t.total_paid,0),0) ELSE COALESCE(t.total_savings,0) END display_balance
    FROM selected s
    LEFT JOIN loans l ON l.id=s.loan_id AND l.organization_id=$1
    LEFT JOIN totals t ON t.client_id=s.client_id AND t.loan_id IS NOT DISTINCT FROM s.loan_id
    ORDER BY s.client_name`,[staff.organization_id,branch.id,effectiveCo,date]);
  res.json({date,collections:rows,count:rows.length,total_collected:rows.reduce((n,r)=>n+Number(r.amount_paid||0),0),total_savings:rows.reduce((n,r)=>n+Number(r.savings_amount||0),0),branch});
}
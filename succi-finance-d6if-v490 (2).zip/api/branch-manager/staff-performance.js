import { db } from 'hatchable';
import { requireBranchManager } from '../../lib/branch-access.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const scope=await requireBranchManager(req,res); if(!scope)return;
 const {staff,branch}=scope; const org=staff.organization_id, branchId=branch.id;
 const coId=String(req.query?.co_id||'').trim();
 const {rows}=await db.query(`SELECT st.id,st.full_name,st.staff_code,
   count(DISTINCT l.client_id)::int clients,count(DISTINCT l.id)::int active_loans,
   COALESCE(SUM(cr.amount_due),0)::numeric expected,COALESCE(SUM(cr.amount_paid),0)::numeric collected,
   COALESCE(SUM(GREATEST(cr.amount_due-cr.amount_paid,0)),0)::numeric overdue
   FROM staff st
   LEFT JOIN loan_applications la ON la.credit_officer_staff_id=st.id AND la.organization_id=$1 AND la.branch_id=$2
   LEFT JOIN loans l ON l.loan_application_id=la.id AND l.organization_id=$1 AND l.branch_id=$2 AND l.status IN ('active','disbursed')
   LEFT JOIN collection_records cr ON cr.loan_id=l.id AND cr.organization_id=$1 AND cr.branch_id=$2 AND cr.collection_date=CURRENT_DATE
   WHERE st.organization_id=$1 AND st.branch_id=$2 AND lower(replace(replace(st.role,'-','_'),' ','_')) IN ('credit_officer','co') AND st.status='active' AND st.deleted_at IS NULL
   ${coId?'AND st.id=$3':''} GROUP BY st.id,st.full_name,st.staff_code ORDER BY st.full_name`,coId?[org,branchId,coId]:[org,branchId]);
 const staffRows=rows.map(x=>({...x,rate:Number(x.expected||0)?Number(x.collected||0)/Number(x.expected||0)*100:0}));
 res.json({staff:staffRows,credit_officers:staffRows.map(x=>({id:x.id,full_name:x.full_name,staff_code:x.staff_code})),count:staffRows.length});
}
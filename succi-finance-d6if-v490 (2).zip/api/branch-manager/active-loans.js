import { db } from 'hatchable';
import { requireBranchManager } from '../../lib/branch-access.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const scope=await requireBranchManager(req,res); if(!scope)return;
 const {staff,branch}=scope,org=staff.organization_id,bid=branch.id,coId=String(req.query?.co_id||'').trim(),search=String(req.query?.search||'').trim();
 const p=[org,bid]; let extra=''; if(coId){p.push(coId);extra+=' AND COALESCE(la.credit_officer_staff_id,c.credit_officer_id)=$'+p.length;} if(search){p.push('%'+search+'%');extra+=` AND (c.full_name ILIKE $${p.length} OR l.id::text ILIKE $${p.length})`;}
 const {rows}=await db.query(`SELECT l.id,l.id loan_number,c.full_name client_name,l.principal amount,l.total_payable,COALESCE(l.total_payable,0)-COALESCE((SELECT SUM(cr.amount_paid) FROM collection_records cr WHERE cr.loan_id=l.id AND cr.organization_id=$1 AND cr.branch_id=$2),0) outstanding,l.status,COALESCE(st.full_name,'Unassigned') co_name FROM loans l JOIN clients c ON c.id=l.client_id LEFT JOIN loan_applications la ON la.id=l.loan_application_id AND la.organization_id=$1 AND la.branch_id=$2 LEFT JOIN staff st ON st.id=COALESCE(la.credit_officer_staff_id,c.credit_officer_id) AND st.organization_id=$1 WHERE l.organization_id=$1 AND l.branch_id=$2 AND l.status IN ('active','disbursed') ${extra} ORDER BY c.full_name`,p);
 res.json({loans:rows,count:rows.length});
}
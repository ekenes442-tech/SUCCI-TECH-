import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public';
export const methods=['GET'];
export default async function(req,res){
  const auth=await requireStaff(req,res);
  if(!auth)return;
  const s=auth.staff;
  const role=String(s.role||'').trim().toLowerCase().replace(/[-_]+/g,' ');
  if(!['credit officer','co'].includes(role)) return res.status(403).json({error:'Credit Officer access required.'});
  const {rows}=await db.query(`SELECT la.id application_id,la.amount,la.status application_status,la.created_at,c.id client_id,c.full_name,c.phone,c.workflow_status,
    COALESCE((SELECT SUM(ls.amount) FROM loan_savings ls WHERE ls.organization_id=la.organization_id AND ls.loan_application_id=la.id),0)::numeric savings_paid,
    ROUND(la.amount*0.10,2)::numeric required_savings,
    CASE WHEN la.amount>0 THEN LEAST(100,ROUND(COALESCE((SELECT SUM(ls.amount) FROM loan_savings ls WHERE ls.organization_id=la.organization_id AND ls.loan_application_id=la.id),0)/(la.amount*0.10)*100,2)) ELSE 0 END savings_completion
    FROM loan_applications la JOIN clients c ON c.id=la.client_id
    WHERE la.organization_id=$1 AND la.branch_id=$2
      AND (la.credit_officer_staff_id=$3 OR c.credit_officer_id=$3)
      AND lower(c.client_type) IN ('individual','group','loan')
      AND la.status NOT IN ('rejected','cancelled','disbursed','completed')
      AND NOT EXISTS (SELECT 1 FROM loans lx WHERE lx.organization_id=la.organization_id AND lx.client_id=la.client_id AND lx.disbursed_at IS NOT NULL)
    ORDER BY la.created_at DESC`,[s.organization_id,s.branch_id,s.id]);
  res.json({clients:rows,count:rows.length});
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET','PATCH'];
export default async function(req,res){
 const auth=await requireStaff(req,res); if(!auth)return; const s=auth.staff;
 const role=String(s.role||'').trim().toLowerCase().replace(/[-_]+/g,' ').replace(/\s+/g,' '); if(!['credit officer','co'].includes(role))return res.status(403).json({error:'Credit Officer access required.'});
 const id=req.query?.client_id||req.query?.id;if(!id)return res.status(400).json({error:'Client ID is required.'});
 const scope=[s.organization_id,s.branch_id,s.id];
 if(req.method==='GET'){
  const r=await db.query(`SELECT c.*,la.id application_id,la.amount loan_amount,la.interest_rate,la.status application_status,COALESCE((SELECT SUM(ls.amount) FROM loan_savings ls WHERE ls.organization_id=c.organization_id AND ls.loan_application_id=la.id),0)::numeric savings_paid,ROUND(COALESCE(la.amount,0)*0.10,2)::numeric required_savings,COALESCE((SELECT json_agg(json_build_object('id',g.id,'guarantor_number',g.guarantor_number,'full_name',g.full_name,'phone',g.phone,'relationship',g.relationship,'occupation',g.occupation,'address',g.address,'id_type',g.id_type,'id_number',g.id_number) ORDER BY g.guarantor_number) FROM client_guarantors g WHERE g.organization_id=c.organization_id AND g.client_id=c.id),'[]'::json) guarantors FROM clients c LEFT JOIN loan_applications la ON la.client_id=c.id AND la.organization_id=c.organization_id WHERE c.id=$1 AND c.organization_id=$2 AND c.branch_id=$3 AND (c.credit_officer_id=$4 OR la.credit_officer_staff_id=$4) ORDER BY la.created_at DESC NULLS LAST LIMIT 1`,[id,...scope]);
  if(!r.rows[0])return res.status(404).json({error:'Client not found or not assigned to this Credit Officer.'});return res.json({client:r.rows[0]});
 }
 const b=req.body||{}, val={full_name:String(b.full_name||'').trim(),phone:String(b.phone||'').trim(),address:String(b.address||'').trim(),collection_day:String(b.collection_day||'').trim().toLowerCase()};
 const days=['monday','tuesday','wednesday','thursday','friday','saturday'];if(!val.full_name||!val.phone||!val.address||!days.includes(val.collection_day))return res.status(400).json({error:'Complete the required client information.'});
 const app=await db.query(`SELECT la.id,la.amount,c.client_type FROM loan_applications la JOIN clients c ON c.id=la.client_id WHERE c.id=$1 AND c.organization_id=$2 AND c.branch_id=$3 AND (c.credit_officer_id=$4 OR la.credit_officer_staff_id=$4) ORDER BY la.created_at DESC LIMIT 1`,[id,...scope]);if(!app.rows[0])return res.status(404).json({error:'Client not found or not assigned to this Credit Officer.'});
 const dup=await db.query('SELECT id FROM clients WHERE organization_id=$1 AND phone=$2 AND id<>$3 LIMIT 1',[s.organization_id,val.phone,id]);if(dup.rows[0])return res.status(409).json({error:'Another client already uses this phone number in this organization.'});
 const cfields=['full_name','phone','address','collection_day','alternative_phone','email','date_of_birth','gender','marital_status','occupation','employer_business_name','business_address','state','lga','id_type','id_number','next_of_kin_name','next_of_kin_relationship','next_of_kin_phone','next_of_kin_address','loan_purpose','repayment_frequency','repayment_term','bank_name','account_name','account_number','declaration_accepted'];
 const vals=cfields.map(k=>b[k]===undefined?null:b[k]);
 const params=[...vals,id,s.organization_id,s.branch_id,s.id];const sets=cfields.map((k,i)=>`${k}=$${i+1}`).join(',');
 const upd=await db.query(`UPDATE clients SET ${sets} WHERE id=$${cfields.length+1} AND organization_id=$${cfields.length+2} AND branch_id=$${cfields.length+3} AND (credit_officer_id=$${cfields.length+4} OR EXISTS(SELECT 1 FROM loan_applications lx WHERE lx.client_id=id AND lx.organization_id=$${cfields.length+2} AND lx.credit_officer_staff_id=$${cfields.length+4})) AND workflow_status NOT IN ('active','audit_pending','completed') RETURNING id,full_name,workflow_status`,params);if(!upd.rows[0])return res.status(404).json({error:'Client not found or not editable.'});
 const gs=Array.isArray(b.guarantors)?b.guarantors:[];
 // Saving a draft may happen before guarantors are available. Guarantors become mandatory only at submission.
 if(gs.length){
   const required=String(app.rows[0].client_type||'').toLowerCase()==='group'?1:2;
   if(gs.length>required)return res.status(400).json({error:`Only ${required} guarantor${required===1?'':'s'} may be registered for this client.`});
   for(const g of gs){if(!g.full_name||!g.phone||!g.relationship||!g.address)return res.status(400).json({error:'Complete all provided guarantor fields.'});}
   // Preserve each guarantor's existing passport when the CO edits/saves the profile.
   // The guarantor rows are rebuilt by the existing workflow, so carry the stored passport URL forward by guarantor id.
   const existingGuarantors=await db.query('SELECT id,passport_photo_url FROM client_guarantors WHERE organization_id=$1 AND client_id=$2',[s.organization_id,id]);
   const passportById=new Map(existingGuarantors.rows.map(x=>[String(x.id),x.passport_photo_url]));
   await db.query('DELETE FROM client_guarantors WHERE organization_id=$1 AND client_id=$2',[s.organization_id,id]);
   for(let i=0;i<gs.length;i++){const g=gs[i];const passport=String(g.passport_photo_url||passportById.get(String(g.id||''))||'').trim()||null;await db.query(`INSERT INTO client_guarantors(organization_id,branch_id,client_id,guarantor_number,full_name,phone,relationship,occupation,address,id_type,id_number,passport_photo_url) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,[s.organization_id,s.branch_id,id,i+1,g.full_name,g.phone,g.relationship,g.occupation||null,g.address,g.id_type||null,g.id_number||null,passport]);}
 }
 if(String(b.action||'').toLowerCase()==='submit_for_review'){
   const savings=await db.query(`SELECT COALESCE(SUM(amount),0)::numeric total FROM loan_savings WHERE organization_id=$1 AND branch_id=$2 AND client_id=$3 AND loan_application_id=$4`,[s.organization_id,s.branch_id,id,app.rows[0].id]);
   const requiredSavings=Math.round(Number(app.rows[0].amount||0)*0.10*100)/100;
   if(Number(savings.rows[0]?.total||0)<requiredSavings)return res.status(409).json({error:`The required 10% savings must be fully paid before submission. Required: ${requiredSavings.toLocaleString('en-NG')}. Paid: ${Number(savings.rows[0]?.total||0).toLocaleString('en-NG')}.`});
   const required=String(app.rows[0].client_type||'').toLowerCase()==='group'?1:2;
   if(gs.length<required)return res.status(400).json({error:`Complete the required ${required} guarantor${required===1?'':'s'} before submitting to Supervisor.`});
   for(const g of gs.slice(0,required)){if(!g.full_name||!g.phone||!g.relationship||!g.address)return res.status(400).json({error:'Complete all required guarantor fields before submission.'});}
   await db.query(`UPDATE loan_applications SET status='awaiting_approval' WHERE id=$1 AND organization_id=$2 AND branch_id=$3 AND status IN('awaiting_savings','rejected')`,[app.rows[0].id,s.organization_id,s.branch_id]);
   await db.query(`UPDATE clients SET workflow_status='awaiting_approval' WHERE id=$1 AND organization_id=$2 AND branch_id=$3`,[id,s.organization_id,s.branch_id]);
   return res.json({ok:true,message:'Client successfully submitted to Supervisor for preview.'});
 }
 return res.json({ok:true,message:'Client profile saved successfully.'});
}
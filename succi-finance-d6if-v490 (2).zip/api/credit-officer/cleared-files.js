import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const a=await requireStaff(req,res); if(!a)return; const s=a.staff;
 if(String(s.role||'').toLowerCase().replace(/[-_]+/g,' ')!=='credit officer')return res.status(403).json({error:'Credit Officer access required.'});
 if(!s.branch_id)return res.status(403).json({error:'Credit Officer is not assigned to a branch.'});
 const {rows}=await db.query(`SELECT l.id loan_id,l.client_id,l.principal,l.total_payable,l.status,l.disbursed_at,c.full_name,c.phone,c.workflow_status FROM loans l JOIN clients c ON c.id=l.client_id WHERE l.organization_id=$1 AND l.branch_id=$2 AND l.status='completed' AND c.workflow_status='completed' AND c.credit_officer_id=$3 ORDER BY l.disbursed_at DESC`,[s.organization_id,s.branch_id,s.id]);
 res.json({loans:rows,count:rows.length});
}
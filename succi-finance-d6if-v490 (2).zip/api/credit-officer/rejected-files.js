import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public';
export const methods=['GET'];
export default async function(req,res){
  const auth=await requireStaff(req,res); if(!auth)return;
  const s=auth.staff;
  const role=String(s.role||'').trim().toLowerCase().replace(/[-_]+/g,' ');
  if(!['credit officer','co'].includes(role)) return res.status(403).json({error:'Credit Officer access required.'});
  const {rows}=await db.query(`SELECT la.id application_id,la.amount,la.status application_status,la.created_at,c.id client_id,c.full_name,c.phone,c.workflow_status,
    COALESCE((SELECT SUM(ls.amount) FROM loan_savings ls WHERE ls.organization_id=la.organization_id AND ls.loan_application_id=la.id),0)::numeric savings_paid,
    ROUND(la.amount*0.10,2)::numeric required_savings,
    r.reason rejection_reason,r.approver_staff_id rejected_by_staff_id,st.full_name rejected_by_name,st.role rejected_by_role,r.created_at rejected_at,CASE WHEN lower(replace(coalesce(st.role,''),'_',' ')) IN ('branch manager','bm') THEN 'Branch Manager' WHEN lower(replace(coalesce(st.role,''),'_',' ')) IN ('supervisor','supervisor staff') THEN 'Supervisor' ELSE COALESCE(st.role,'Staff') END rejection_source
    FROM loan_applications la JOIN clients c ON c.id=la.client_id
    LEFT JOIN LATERAL (SELECT a.reason,a.approver_staff_id,a.created_at FROM approvals a WHERE a.organization_id=la.organization_id AND a.branch_id=la.branch_id AND a.loan_application_id=la.id AND a.decision='rejected' ORDER BY a.created_at DESC LIMIT 1) r ON true
    LEFT JOIN staff st ON st.id=r.approver_staff_id
    WHERE la.organization_id=$1 AND la.branch_id=$2 AND (la.credit_officer_staff_id=$3 OR c.credit_officer_id=$3) AND la.status='rejected'
    ORDER BY COALESCE(r.created_at,la.created_at) DESC`,[s.organization_id,s.branch_id,s.id]);
  res.json({clients:rows,count:rows.length});
}
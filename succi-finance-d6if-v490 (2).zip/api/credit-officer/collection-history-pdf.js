import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';

export const access = 'public';
export const methods = ['GET'];

const esc = s => String(s ?? '').replace(/\\/g,'\\\\').replace(/\(/g,'\\(').replace(/\)/g,'\\)').replace(/[^\x20-\x7E]/g,'?');
const money = n => `NGN ${Number(n || 0).toLocaleString('en-NG',{minimumFractionDigits:2,maximumFractionDigits:2})}`;
const short = (s,n) => String(s ?? '').slice(0,n);

function buildPdf(rows, date, totalCollected) {
  const pageW=842,pageH=595, margin=24, rowH=18, headerY=550;
  const cols=[
    ['No.',24,28],['Client Name',52,105],['Type',157,70],['Amount',227,70],
    ['Daily Pay',297,65],['Today Sav.',362,65],['Total Sav.',427,65],['Monthly Chg.',492,70],['Withdrawable',562,75],
    ['Loan Amount',637,70],['Expected Repay.',707,75],['Today Repay.',782,60]
  ];
  const lines=[];
  const add=(text,x,y,size=7,bold=false)=>lines.push(`BT /${bold?'F2':'F1'} ${size} Tf ${x} ${y} Td (${esc(text)}) Tj ET`);
  const line=(x1,y1,x2,y2)=>lines.push(`${x1} ${y1} m ${x2} ${y2} l S`);
  const page=(pageNo,start,end)=>{
    add('SUCCI TECH',margin,headerY,16,true);
    add('REPAYMENT HISTORY',margin,headerY-22,11,true);
    add(`Collection Date: ${date}`,margin,headerY-39,9,true);
    add(`Page ${pageNo}`,pageW-70,headerY,7,false);
    let y=headerY-62;
    cols.forEach(([label,x,w])=>{add(label,x+2,y,6.5,true);line(x,y+5,x+w,y+5)});
    y-=rowH;
    for(let i=start;i<end;i++){
      const r=rows[i];
      const values=[
        String(i+1),short(r.client_name,20),short(r.client_type,12),money(r.collected_amount),
        money(r.daily_payment),money(r.today_savings),money(r.total_savings),money(r.monthly_charge),money(r.withdrawable_balance),
        money(r.loan_amount),money(r.expected_repayment),money(r.today_repayment)
      ];
      cols.forEach(([_,x,w],j)=>add(values[j],x+2,y,5.6,false));
      line(margin,y-4,pageW-margin,y-4);
      y-=rowH;
    }
    return y;
  };
  const rowsPerPage=24;
  const pages=Math.max(1,Math.ceil(rows.length/rowsPerPage));
  for(let p=0;p<pages;p++) page(p+1,p*rowsPerPage,Math.min(rows.length,(p+1)*rowsPerPage));
  const lastY=42;
  add('TOTAL AMOUNT COLLECTED',margin,lastY+14,9,true);
  add(money(totalCollected),margin+155,lastY+14,10,true);
  const stream=lines.join('\n');
  const objs=[
    '<< /Type /Catalog /Pages 2 0 R >>',
    `<< /Type /Pages /Kids [${Array.from({length:pages},(_,i)=>`${3+i*2} 0 R`).join(' ')}] /Count ${pages} >>`
  ];
  for(let p=0;p<pages;p++){
    const contentStart=p*2+5;
    objs.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageW} ${pageH}] /Resources << /Font << /F1 ${contentStart} 0 R /F2 ${contentStart+1} 0 R >> >> /Contents ${contentStart+2} 0 R >>`);
  }
  // Rebuild page objects with dedicated content streams so each PDF page is valid.
  const pageStreams=[];
  for(let p=0;p<pages;p++){
    const pageLines=[];
    const addP=(text,x,y,size=7,bold=false)=>pageLines.push(`BT /${bold?'F2':'F1'} ${size} Tf ${x} ${y} Td (${esc(text)}) Tj ET`);
    const lineP=(x1,y1,x2,y2)=>pageLines.push(`${x1} ${y1} m ${x2} ${y2} l S`);
    addP('SUCCI TECH',margin,headerY,16,true);addP('REPAYMENT HISTORY',margin,headerY-22,11,true);addP(`Collection Date: ${date}`,margin,headerY-39,9,true);addP(`Page ${p+1} of ${pages}`,pageW-82,headerY,7);
    let y=headerY-62;cols.forEach(([label,x,w])=>{addP(label,x+2,y,6.5,true);lineP(x,y+5,x+w,y+5)});y-=rowH;
    const start=p*rowsPerPage,end=Math.min(rows.length,(p+1)*rowsPerPage);
    for(let i=start;i<end;i++){const r=rows[i];const values=[String(i+1),short(r.client_name,20),short(r.client_type,12),money(r.collected_amount),money(r.daily_payment),money(r.today_savings),money(r.total_savings),money(r.monthly_charge),money(r.withdrawable_balance),money(r.loan_amount),money(r.expected_repayment),money(r.today_repayment)];cols.forEach(([_,x,w],j)=>addP(values[j],x+2,y,5.6));lineP(margin,y-4,pageW-margin,y-4);y-=rowH;}
    if(p===pages-1){addP('TOTAL AMOUNT COLLECTED',margin,42,9,true);addP(money(totalCollected),margin+155,42,10,true);}
    pageStreams.push(pageLines.join('\n'));
  }
  const pdfObjs=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Kids [] /Count 0 >>'];
  const pageObjIndexes=[];
  for(let p=0;p<pages;p++){
    const pageObj=pdfObjs.length+1,font1=pageObj+1,font2=pageObj+2,content=pageObj+3;
    pageObjIndexes.push(pageObj);
    pdfObjs.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageW} ${pageH}] /Resources << /Font << /F1 ${font1} 0 R /F2 ${font2} 0 R >> >> /Contents ${content} 0 R >>`);
    pdfObjs.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
    pdfObjs.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>');
    const streamP=pageStreams[p];pdfObjs.push(`<< /Length ${Buffer.byteLength(streamP,'binary')} >>\nstream\n${streamP}\nendstream`);
  }
  pdfObjs[1]=`<< /Type /Pages /Kids [${pageObjIndexes.map(i=>`${i} 0 R`).join(' ')}] /Count ${pages} >>`;
  let out='%PDF-1.4\n',offs=[0];
  for(let i=0;i<pdfObjs.length;i++){offs[i+1]=Buffer.byteLength(out,'binary');out+=`${i+1} 0 obj\n${pdfObjs[i]}\nendobj\n`;}
  const xref=Buffer.byteLength(out,'binary');out+=`xref\n0 ${pdfObjs.length+1}\n0000000000 65535 f \n`;for(let i=1;i<offs.length;i++)out+=String(offs[i]).padStart(10,'0')+' 00000 n \n';out+=`trailer\n<< /Size ${pdfObjs.length+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return Buffer.from(out,'binary');
}

export default async function(req,res){
  const auth=await requireStaff(req,res); if(!auth)return;
  const s=auth.staff;
  if(!s||s.status!=='active'||String(s.role).toLowerCase()!=='credit_officer') return res.status(403).json({error:'Credit Officer access only.'});
  const dateMatch=String(req.query?.date||'').match(/^\d{4}-\d{2}-\d{2}$/);
  if(!dateMatch) return res.status(400).json({error:'A valid collection date is required.'});
  const date=dateMatch[0];
  const {rows}=await db.query(`
    WITH actual AS (
      SELECT cr.client_id,cr.loan_id,SUM(cr.amount_paid)::numeric amount_paid,SUM(cr.savings_amount)::numeric savings_amount
      FROM collection_records cr
      JOIN clients c ON c.id=cr.client_id
      WHERE cr.organization_id=$1 AND cr.branch_id=$2 AND c.credit_officer_id=$3 AND cr.collection_date=$4
        AND (COALESCE(cr.amount_paid,0)>0 OR COALESCE(cr.savings_amount,0)>0)
      GROUP BY cr.client_id,cr.loan_id
    ), daily_totals AS (
      SELECT cr.client_id,SUM(cr.amount_paid)::numeric total_paid,SUM(cr.savings_amount)::numeric total_savings
      FROM collection_records cr WHERE cr.organization_id=$1 AND cr.branch_id=$2 AND cr.collection_date<=$4 AND cr.loan_id IS NULL GROUP BY cr.client_id
    ), loan_totals AS (
      SELECT cr.client_id,cr.loan_id,SUM(cr.amount_paid)::numeric total_paid
      FROM collection_records cr WHERE cr.organization_id=$1 AND cr.branch_id=$2 AND cr.collection_date<=$4 AND cr.loan_id IS NOT NULL GROUP BY cr.client_id,cr.loan_id
    )
    SELECT c.full_name client_name,
      CASE WHEN a.loan_id IS NULL THEN 'DAILY COLLECTION' ELSE 'LOAN' END client_type,
      (COALESCE(a.amount_paid,0)+COALESCE(a.savings_amount,0))::numeric collected_amount,
      COALESCE(a.amount_paid,0)::numeric daily_payment,
      COALESCE(a.savings_amount,0)::numeric today_savings,
      CASE WHEN a.loan_id IS NULL THEN COALESCE(dt.total_savings,0) ELSE COALESCE(ls.total_savings,0) END::numeric total_savings,
      COALESCE(sa.monthly_charge,0)::numeric monthly_charge,
      COALESCE(sa.withdrawable_balance,0)::numeric withdrawable_balance,
      COALESCE(l.principal,la.amount,0)::numeric loan_amount,
      COALESCE(l.total_payable,0)::numeric expected_repayment,
      COALESCE(a.amount_paid,0)::numeric today_repayment,
      CASE WHEN a.loan_id IS NULL THEN COALESCE(dt.total_paid,0) ELSE COALESCE(lt.total_paid,0) END::numeric total_paid,
      CASE WHEN l.status IN ('active','disbursed') THEN GREATEST(COALESCE(l.total_payable,0)-COALESCE(lt.total_paid,0),0) ELSE 0 END::numeric outstanding,
      CASE WHEN l.id IS NULL THEN 'COLLECTED' WHEN COALESCE(lt.total_paid,0)>=COALESCE(l.total_payable,0) THEN 'COMPLETED' WHEN COALESCE(lt.total_paid,0)>0 THEN 'PARTIAL' ELSE 'DEFAULT' END repayment_status,
      l.disbursed_at + (COALESCE(l.term_count,30) * CASE lower(COALESCE(l.repayment_frequency,'daily')) WHEN 'weekly' THEN interval '7 days' WHEN 'monthly' THEN interval '30 days' ELSE interval '1 day' END) due_date
    FROM actual a
    JOIN clients c ON c.id=a.client_id
    LEFT JOIN service_accounts sa ON sa.client_id=c.id AND sa.organization_id=$1 AND sa.branch_id=$2 AND sa.service_type='daily_collection' AND sa.status='active'
    LEFT JOIN daily_totals dt ON dt.client_id=c.id
    LEFT JOIN loans l ON l.id=a.loan_id AND l.organization_id=$1 AND l.branch_id=$2
    LEFT JOIN loan_applications la ON la.client_id=c.id AND la.organization_id=$1 AND la.branch_id=$2 AND la.status NOT IN ('rejected','cancelled')
    LEFT JOIN (SELECT client_id,organization_id,loan_application_id,SUM(amount)::numeric total_savings FROM loan_savings GROUP BY client_id,organization_id,loan_application_id) ls ON ls.client_id=c.id AND ls.organization_id=$1 AND ls.loan_application_id=la.id
    LEFT JOIN loan_totals lt ON lt.client_id=c.id AND lt.loan_id=a.loan_id
    ORDER BY c.full_name`,[s.organization_id,s.branch_id,s.id,date]);
  if(!rows.length) return res.status(404).json({code:'NO_COLLECTION',message:`No collection was recorded for ${date}.`});
  const totalCollected=rows.reduce((n,r)=>n+Number(r.collected_amount||0),0);
  const body=buildPdf(rows,date,totalCollected);
  res.setHeader('Content-Type','application/pdf');
  res.setHeader('Content-Disposition',`inline; filename="succi-repayment-${date}.pdf"`);
  res.send(body);
}
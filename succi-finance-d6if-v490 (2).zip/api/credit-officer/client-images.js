import { db, storage } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public';
export const methods=['GET','POST','DELETE'];
export default async function(req,res){
 const auth=await requireStaff(req,res); if(!auth)return; const s=auth.staff;
 const role=String(s.role||'').trim().toLowerCase().replace(/[-_]+/g,' ');
 const id=req.query?.client_id||req.query?.id; if(!id)return res.status(400).json({error:'Client ID is required.'});
 // Documents belong to the organisation/client profile and must remain retrievable after workflow hand-off.
 // GET is available to authenticated staff in the same organisation; uploads/deletes remain CO-only.
 if(req.method==='GET'){
  const client=await db.query('SELECT id,organization_id,branch_id FROM clients WHERE id=$1 AND organization_id=$2 LIMIT 1',[id,s.organization_id]);
  if(!client.rows[0])return res.status(404).json({error:'Client not found in this organisation.'});
  const c=await db.query('SELECT passport_photo_url FROM clients WHERE id=$1 AND organization_id=$2',[id,s.organization_id]);
  const r=await db.query('SELECT id,image_url,description,created_at FROM client_collateral_images WHERE client_id=$1 AND organization_id=$2 AND branch_id=$3 ORDER BY created_at DESC',[id,s.organization_id,s.branch_id]);
  const g=await db.query('SELECT id,guarantor_number,full_name,passport_photo_url FROM client_guarantors WHERE client_id=$1 AND organization_id=$2 AND branch_id=$3 ORDER BY guarantor_number',[id,s.organization_id,s.branch_id]);
  return res.json({passport_photo_url:c.rows[0]?.passport_photo_url||null,collateral_images:r.rows,guarantors:g.rows});
 }
 if(!['credit officer','co'].includes(role)) return res.status(403).json({error:'Only the assigned Credit Officer can upload or remove client documents.'});
 const own=await db.query(`SELECT id,organization_id,branch_id FROM clients WHERE id=$1 AND organization_id=$2 AND branch_id=$3 AND credit_officer_id=$4 LIMIT 1`,[id,s.organization_id,s.branch_id,s.id]);
 if(!own.rows[0])return res.status(404).json({error:'Client not found or not assigned to this Credit Officer.'});
 if(req.method==='DELETE'){
  const imageId=req.query?.image_id;if(!imageId)return res.status(400).json({error:'Image ID is required.'});
  const r=await db.query('SELECT image_url FROM client_collateral_images WHERE id=$1 AND client_id=$2 AND organization_id=$3 AND branch_id=$4',[imageId,id,s.organization_id,s.branch_id]);
  if(!r.rows[0])return res.status(404).json({error:'Collateral image not found.'});
  await db.query('DELETE FROM client_collateral_images WHERE id=$1 AND organization_id=$2',[imageId,s.organization_id]);
  try{await storage.del(r.rows[0].image_url)}catch{}
  return res.json({ok:true});
 }
 const files=req.files||[]; if(!files.length)return res.status(400).json({error:'Please select an image.'});
 const type=String(req.body?.type||'').toLowerCase();
 const file=files[0];
 const allowedImage=String(file.contentType||'').startsWith('image/');
 const allowedDocument=['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document'].includes(String(file.contentType||''));
 if(!allowedImage && !(type==='collateral' && allowedDocument))return res.status(400).json({error:'Please upload an image or a supported PDF/document file.'});
 if(file.buffer.length>8*1024*1024)return res.status(400).json({error:'File must be 8MB or smaller.'});
 const safe=String(file.filename||'image').replace(/[^a-zA-Z0-9._-]/g,'_');
 const key=`client-images/${s.organization_id}/${s.branch_id}/${id}/${Date.now()}-${safe}`;
 const url=await storage.put(key,file.buffer,file.contentType);
 if(type==='passport'){
  const old=await db.query('SELECT passport_photo_url FROM clients WHERE id=$1 AND organization_id=$2',[id,s.organization_id]);
  await db.query('UPDATE clients SET passport_photo_url=$1 WHERE id=$2 AND organization_id=$3',[url,id,s.organization_id]);
  if(old.rows[0]?.passport_photo_url){try{await storage.del(old.rows[0].passport_photo_url)}catch{}}
  return res.json({ok:true,url});
 }
 if(type==='guarantor_passport'){
  const guarantorId=String(req.body?.guarantor_id||'').trim();
  if(!guarantorId)return res.status(400).json({error:'Guarantor ID is required.'});
  const g=await db.query('SELECT id FROM client_guarantors WHERE id=$1 AND client_id=$2 AND organization_id=$3 AND branch_id=$4 LIMIT 1',[guarantorId,id,s.organization_id,s.branch_id]);
  if(!g.rows[0])return res.status(404).json({error:'Guarantor not found for this client.'});
  const old=await db.query('SELECT passport_photo_url FROM client_guarantors WHERE id=$1 AND organization_id=$2',[guarantorId,s.organization_id]);
  await db.query('UPDATE client_guarantors SET passport_photo_url=$1 WHERE id=$2 AND organization_id=$3',[url,guarantorId,s.organization_id]);
  if(old.rows[0]?.passport_photo_url){try{await storage.del(old.rows[0].passport_photo_url)}catch{}}
  return res.json({ok:true,url,guarantor_id:guarantorId});
 }
 if(type==='collateral'){
  const desc=String(req.body?.description||'').trim()||null;
  const app=await db.query(`SELECT id FROM loan_applications WHERE client_id=$1 AND organization_id=$2 ORDER BY created_at DESC LIMIT 1`,[id,s.organization_id]);
  const r=await db.query(`INSERT INTO client_collateral_images(organization_id,branch_id,client_id,loan_application_id,image_url,description,created_by_staff_id) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id,image_url,description,created_at`,[s.organization_id,s.branch_id,id,app.rows[0]?.id||null,url,desc,s.id]);
  return res.json({ok:true,image:r.rows[0]});
 }
 try{await storage.del(url)}catch{}; return res.status(400).json({error:'Invalid image type.'});
}
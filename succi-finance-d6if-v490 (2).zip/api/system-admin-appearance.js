import { db } from "hatchable";
import { requireStaff } from '../lib/supabase-auth.js';
export const access = "public";
async function requireSystemAdmin(req,res){
 const a=await requireStaff(req,res); if(!a)return null;
 const email=String(a.user?.email||a.staff?.email||'').trim().toLowerCase();
 const uid=String(a.user?.id||'').trim();
 const {rows}=await db.query("SELECT id FROM system_admin_identities WHERE status='active' AND (auth_user_id=$1 OR lower(email)=lower($2)) LIMIT 1",[uid,email]);
 if(!rows[0]){res.status(403).json({error:'System Admin access required.'});return null;}
 return a;
}
export const methods = ["GET","PUT"];
const paletteSets=[{id:'professional',name:'Professional Mix',colors:['#2563eb','#16a34a','#ea580c','#7c3aed','#0891b2','#be123c']},{id:'executive',name:'Executive',colors:['#111827','#334155','#1d4ed8','#047857','#7c2d12','#4c1d95']},{id:'bright',name:'Bright Business',colors:['#dc2626','#2563eb','#16a34a','#d97706','#7c3aed','#0891b2']},{id:'soft',name:'Soft Professional',colors:['#475569','#0369a1','#15803d','#a16207','#6d28d9','#be185d']},{id:'red-gold',name:'SUCCI Red & Gold',colors:['#b91c1c','#d97706','#991b1b','#f59e0b','#7f1d1d','#92400e']},{id:'ocean',name:'Ocean',colors:['#0f766e','#0369a1','#1d4ed8','#0891b2','#164e63','#155e75']}];
const defaults={app_bg_color:'#000000',body_color:'#ffffff',heading_text:'SUCCI TECH',subheading_text:'Microfinance Management',heading_color:'#ffffff',subheading_color:'#e5e7eb',card_palette_set:'professional',sidebar_color:'#111827',sidebar_text_color:'#ffffff',accent_color:'#b91c1c',card_palette_sets:paletteSets};
export default async function(req,res){await requireSystemAdmin(req,res);if(res.headersSent)return;if(req.method==='GET'){const {rows}=await db.query("SELECT key,value FROM app_settings WHERE key LIKE 'appearance_%'");const out={...defaults};for(const r of rows){const k=r.key.replace(/^appearance_/,'');try{out[k]=JSON.parse(r.value)}catch{out[k]=r.value}}out.card_palette_sets=paletteSets;res.setHeader('Cache-Control','no-store');return res.json(out)}const b=req.body||{};const allowed=['app_bg_color','body_color','heading_text','subheading_text','heading_color','subheading_color','card_palette_set','sidebar_color','sidebar_text_color','accent_color'];for(const k of allowed){if(b[k]!==undefined)await db.query("INSERT INTO app_settings(key,value) VALUES($1,$2) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value",['appearance_'+k,JSON.stringify(String(b[k]))])}res.json({ok:true})}
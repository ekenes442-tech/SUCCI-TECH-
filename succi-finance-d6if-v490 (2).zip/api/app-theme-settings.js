import { db } from "hatchable";
export const access = "member";
export const methods = ["GET","PUT"];
export default async function(req,res){
 const member=req.member;
 if(req.method==="GET"){
  const {rows}=await db.query("SELECT key,value FROM app_settings WHERE key LIKE 'ui_%'");
  const out={}; for(const r of rows){try{out[r.key]=JSON.parse(r.value)}catch{out[r.key]=r.value}} return res.json(out);
 }
 const role=String(member?.role||'').toLowerCase();
 if(!['system_admin','super_admin','admin'].includes(role)) return res.status(403).json({error:'System Admin access required'});
 const allowed=['ui_dashboard_heading','ui_dashboard_subheading','ui_clients_heading','ui_clients_subheading','ui_loans_heading','ui_loans_subheading','ui_collections_heading','ui_collections_subheading','ui_card_color_set','ui_heading_color','ui_subheading_color','ui_body_color'];
 for(const key of allowed){if(Object.prototype.hasOwnProperty.call(req.body||{},key)){await db.query("INSERT INTO app_settings (key,value) VALUES ($1,$2) ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value",[key,JSON.stringify(req.body[key])]);}}
 res.json({ok:true});
}
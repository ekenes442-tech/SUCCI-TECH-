import { db, storage } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access = 'public';
export const methods = ['GET'];

const ALLOWED_ROLES = new Set(['ceo','general overseer','operational manager','system admin']);
export default async function(req,res){
  const authResult=await requireStaff(req,res); if(!authResult)return;
  const id=String(req.query?.id||''); if(!id)return res.status(400).json({error:'Backup id is required.'});
  const me=await db.query(`SELECT s.id,s.organization_id,s.role FROM staff s WHERE (s.auth_user_id=$1 OR lower(s.email)=lower($2)) AND lower(s.status)='active' LIMIT 1`,[req.member.id,req.member.email]);
  if(!me.rows.length)return res.status(403).json({error:'Staff profile not found.'});
  const staff=me.rows[0]; if(!ALLOWED_ROLES.has(String(staff.role||'').toLowerCase()))return res.status(403).json({error:'Not authorised.'});
  const r=await db.query(`SELECT file_name,storage_key,status FROM organization_backups WHERE id=$1 AND organization_id=$2 LIMIT 1`,[id,staff.organization_id]);
  if(!r.rows.length)return res.status(404).json({error:'Backup not found.'});
  if(r.rows[0].status!=='completed')return res.status(409).json({error:'Backup is not complete.'});
  const file=await storage.get(r.rows[0].storage_key);
  res.setHeader('Content-Type','application/json');
  res.setHeader('Content-Disposition',`attachment; filename="${r.rows[0].file_name}"`);
  res.send(file.buffer);
}
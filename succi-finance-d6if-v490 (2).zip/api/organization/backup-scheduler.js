import { db, storage } from 'hatchable';
export const access = 'scheduler';
export const schedule = '0 2 * * *';

const TABLES = [
  ['organizations','id'],['organization_settings','organization_id'],['organization_loan_settings','organization_id'],['branches','organization_id'],['staff','organization_id'],['staff_profiles','organization_id'],['staff_management_audit','organization_id'],['clients','organization_id'],['client_guarantors','organization_id'],['client_collateral_images','organization_id'],['loan_products','organization_id'],['loan_applications','organization_id'],['loan_savings','organization_id'],['loans','organization_id'],['disbursements','organization_id'],['collection_records','organization_id'],['approvals','organization_id'],['audit_records','organization_id'],['auditor_branch_assignments','organization_id'],['auditor_savings_offsets','organization_id'],['cleared_files','organization_id'],['savings_guarantors_audit','organization_id'],['security_events','organization_id'],['service_accounts','organization_id'],['branch_expenses','organization_id']
];
async function make(organizationId,name){
 const snapshot={format:'SUCCI-TECH-ORGANIZATION-BACKUP',version:1,organization_id:organizationId,exported_at:new Date().toISOString(),tables:{}}; let rows=0;
 for(const [table,col] of TABLES){const q=table==='organizations'?await db.query('SELECT * FROM organizations WHERE id=$1',[organizationId]):await db.query(`SELECT * FROM ${table} WHERE ${col}=$1`,[organizationId]);snapshot.tables[table]=q.rows;rows+=q.rows.length;}
 const bytes=new TextEncoder().encode(JSON.stringify(snapshot)); const stamp=new Date().toISOString().replace(/[:.]/g,'-'); const fileName=`succi-tech-auto-${stamp}.json`; const key=`organization-backups/${organizationId}/${fileName}`;
 await storage.put(key,bytes,'application/json');
 await db.query(`INSERT INTO organization_backups (organization_id,backup_type,status,storage_key,file_name,row_count,size_bytes,completed_at) VALUES ($1,'automatic','completed',$2,$3,$4,$5,now())`,[organizationId,key,fileName,rows,bytes.byteLength]);
}
export default async function(){const orgs=await db.query(`SELECT id,name FROM organizations WHERE lower(status)='active'`);let completed=0;for(const o of orgs.rows){try{await make(o.id,o.name);completed++;}catch(e){await db.query(`INSERT INTO organization_backups (organization_id,backup_type,status,file_name,error_message) VALUES ($1,'automatic','failed',$2,$3)`,[o.id,'FAILED-AUTOMATIC-BACKUP',String(e?.message||e)]);}}return {ok:true,organizations:orgs.rows.length,completed};}
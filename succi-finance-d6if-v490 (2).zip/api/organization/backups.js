import { db, storage } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';

export const access = 'public';
export const methods = ['GET', 'POST'];

const TABLES = [
  ['organizations', 'id'], ['organization_settings', 'organization_id'], ['organization_loan_settings', 'organization_id'],
  ['branches', 'organization_id'], ['staff', 'organization_id'], ['staff_profiles', 'organization_id'],
  ['staff_management_audit', 'organization_id'], ['clients', 'organization_id'], ['client_guarantors', 'organization_id'],
  ['client_collateral_images', 'organization_id'], ['loan_products', 'organization_id'], ['loan_applications', 'organization_id'],
  ['loan_savings', 'organization_id'], ['loans', 'organization_id'], ['disbursements', 'organization_id'],
  ['collection_records', 'organization_id'], ['approvals', 'organization_id'], ['audit_records', 'organization_id'],
  ['auditor_branch_assignments', 'organization_id'], ['auditor_savings_offsets', 'organization_id'], ['cleared_files', 'organization_id'],
  ['savings_guarantors_audit', 'organization_id'], ['security_events', 'organization_id'], ['service_accounts', 'organization_id'],
  ['branch_expenses', 'organization_id']
];

const ALLOWED_ROLES = new Set(['ceo','general overseer','operational manager','system admin']);

async function getStaff(req,res) {
  const authResult = await requireStaff(req,res);
  if (!authResult) return null;
  const r = await db.query(`SELECT s.id,s.organization_id,s.full_name,s.role,o.name organization_name
    FROM staff s JOIN organizations o ON o.id=s.organization_id
    WHERE (s.auth_user_id=$1 OR lower(s.email)=lower($2)) AND lower(s.status)='active' AND lower(o.status)='active' LIMIT 1`, [req.member.id, req.member.email]);
  return r.rows[0] || null;
}

async function buildBackup(organizationId) {
  const snapshot = { format: 'SUCCI-TECH-ORGANIZATION-BACKUP', version: 1, organization_id: organizationId, exported_at: new Date().toISOString(), tables: {} };
  let rowCount = 0;
  for (const [table, scopeColumn] of TABLES) {
    const q = table === 'organizations'
      ? await db.query('SELECT * FROM organizations WHERE id=$1', [organizationId])
      : await db.query(`SELECT * FROM ${table} WHERE ${scopeColumn}=$1`, [organizationId]);
    snapshot.tables[table] = q.rows;
    rowCount += q.rows.length;
  }
  const bytes = new TextEncoder().encode(JSON.stringify(snapshot));
  return { snapshot, bytes, rowCount };
}

export default async function(req,res) {
  const staff = await getStaff(req,res);
  if (!staff) return res.status(401).json({error:'Authentication required.'});
  if (!ALLOWED_ROLES.has(String(staff.role||'').toLowerCase())) return res.status(403).json({error:'Only authorised organisation administrators can manage backups.'});

  if (req.method === 'GET') {
    const r = await db.query(`SELECT id,backup_type,status,file_name,row_count,size_bytes,created_at,completed_at,error_message
      FROM organization_backups WHERE organization_id=$1 ORDER BY created_at DESC LIMIT 30`, [staff.organization_id]);
    return res.json({organization: {id: staff.organization_id, name: staff.organization_name}, backups: r.rows});
  }

  const { snapshot, bytes, rowCount } = await buildBackup(staff.organization_id);
  const stamp = new Date().toISOString().replace(/[:.]/g,'-');
  const fileName = `succi-tech-${String(staff.organization_name||'organization').toLowerCase().replace(/[^a-z0-9]+/g,'-')}-${stamp}.json`;
  const storageKey = `organization-backups/${staff.organization_id}/${fileName}`;
  await storage.put(storageKey, bytes, 'application/json');
  const r = await db.query(`INSERT INTO organization_backups
    (organization_id,created_by_staff_id,backup_type,status,storage_key,file_name,row_count,size_bytes,completed_at)
    VALUES ($1,$2,'manual','completed',$3,$4,$5,$6,now()) RETURNING id,backup_type,status,file_name,row_count,size_bytes,created_at,completed_at`,
    [staff.organization_id, staff.id, storageKey, fileName, rowCount, bytes.byteLength]);
  return res.json({ok:true, backup:r.rows[0]});
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const auth=await requireStaff(req,res); if(!auth)return;
 const p=auth.staff;
 const {rows}=await db.query(`SELECT o.id,o.name,o.code,o.email,o.status,o.date_founded,o.registration_number,o.organization_type,o.country,o.state,o.local_government_area,o.official_address,o.history,o.mission,o.vision,o.core_values,s.role,s.id staff_id,s.branch_id FROM staff s JOIN organizations o ON o.id=s.organization_id WHERE s.id=$1 LIMIT 1`,[p.id]);
 if(!rows.length)return res.status(403).json({error:'No SUCCI TECH staff profile is linked to this account.'});
 const org=rows[0];
 const branchOnly=String(p.role).toLowerCase()==='branch_manager';
 const {rows:branches}=await db.query(branchOnly?`SELECT id,name,email,address,status,created_at FROM branches WHERE organization_id=$1 AND id=$2 ORDER BY name`:`SELECT id,name,email,address,status,created_at FROM branches WHERE organization_id=$1 ORDER BY name`,branchOnly?[org.id,p.branch_id]:[org.id]);
 return res.json({organization:org,branches});
}
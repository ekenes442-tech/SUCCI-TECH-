import { db } from "hatchable";
import { requireStaff } from '../../lib/supabase-auth.js';
export const access="public";
export const methods=["GET","POST"];
async function profile(req){
  const userId=String(req.user?.id||'');
  const email=String(req.user?.email||'').toLowerCase();
  const {rows}=await db.query(`SELECT s.id,s.organization_id,s.branch_id,s.role,s.status,s.auth_user_id,o.status organization_status
    FROM staff s JOIN organizations o ON o.id=s.organization_id
    WHERE (s.auth_user_id=$1 AND $1<>'') OR (lower(s.email)=lower($2) AND $2<>'')
    ORDER BY CASE WHEN s.auth_user_id=$1 THEN 0 ELSE 1 END LIMIT 1`,[userId,email]);
  if(!rows.length)return null;
  const p=rows[0];
  if(userId && p.auth_user_id!==userId){await db.query(`UPDATE staff SET auth_user_id=$1 WHERE id=$2 AND auth_user_id IS NULL`,[userId,p.id]);}
  return p;
}
export default async function(req,res){
 const authResult=await requireStaff(req,res); if(!authResult)return;
  const p=await profile(req);
  if(!p||p.status!=="active"||p.organization_status!=="active")return res.status(403).json({error:"Your authenticated account is not linked to an active SUCCI TECH organization staff profile."});
  if(req.method==="GET"){
    const {rows}=await db.query(`SELECT id,name,email,address,status FROM branches WHERE organization_id=$1 ORDER BY name`,[p.organization_id]);
    return res.json({branches:rows,scope:{organization_id:p.organization_id,role:p.role}});
  }
  if(p.role!=="general_overseer")return res.status(403).json({error:"Only the General Overseer / CEO can create branches."});
  const b=req.body||{};
  const name=String(b.name||"").trim(),email=String(b.email||"").trim().toLowerCase(),address=String(b.address||"").trim();
  if(!name||!email)return res.status(400).json({error:"Branch name and branch email are required."});
  if(!/^\S+@\S+\.\S+$/.test(email))return res.status(400).json({error:"Enter a valid branch email."});
  const exists=await db.query(`SELECT id FROM branches WHERE organization_id=$1 AND lower(email)=lower($2) LIMIT 1`,[p.organization_id,email]);
  if(exists.rows.length)return res.status(409).json({error:"That branch email is already in use in this organization."});
  const {rows}=await db.query(`INSERT INTO branches (organization_id,name,email,address,status,created_by_auth_user_id) VALUES ($1,$2,$3,$4,'active',$5) RETURNING id,name,email,address,status`,[p.organization_id,name,email,address||null,req.user.id]);
  return res.status(201).json({branch:rows[0]});
}
import { db } from "hatchable";
export const access = "admin";
export const methods = ["PUT"];
export default async function(req,res){
 const b=req.body||{};
 const duration=Math.max(1,Math.min(120,Number(b.duration_seconds)||10));
 const vals={background_color:b.background_color||'#e5091b',title:b.title||'SUCCI TECH',subtitle:b.subtitle||'Microfinance Management',show_title:b.show_title!==false,show_subtitle:b.show_subtitle===true,duration_seconds:duration,text_color:b.text_color||'#ffffff',font_family:b.font_family||'Inter',transition:b.transition||'fade',animation_effect:b.animation_effect||b.transition||'fade',loading_style:b.loading_style||'none',logo_position:b.logo_position||'center',title_position:b.title_position||'center',subtitle_position:b.subtitle_position||'center',secondary_launch_enabled:b.secondary_launch_enabled!==false,launch_page:b.launch_page||'primary'};
 for(const [k,v] of Object.entries(vals)) await db.query("INSERT INTO app_settings(key,value) VALUES($1,$2) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value",['launch_'+k,JSON.stringify(v)]);
 res.json({ok:true,settings:vals});
}
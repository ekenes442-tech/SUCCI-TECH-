import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const auth=await requireStaff(req,res); if(!auth)return; const s=auth.staff; const role=String(s.role).toLowerCase();
 const params=[s.organization_id]; const scope=['c.organization_id=$1'];
 if(s.branch_id && !['general_overseer','general_supervisor'].includes(role)){params.push(s.branch_id);scope.push(`c.branch_id=$${params.length}`)}
 if(role==='credit_officer'){params.push(s.id);scope.push(`c.credit_officer_id=$${params.length}`)}
 const queryParams=params;
 const scopeSql=scope.slice(1).join(' AND ')||'TRUE';
 const [daily,activeLoans,awaiting,clients,defaulting]=await Promise.all([
   db.query(`SELECT count(DISTINCT sa.client_id)::int count FROM service_accounts sa JOIN clients c ON c.id=sa.client_id WHERE sa.organization_id=$1 AND sa.service_type='daily_collection' AND sa.status='active' AND ${scopeSql}`,queryParams),
   db.query(`SELECT count(DISTINCT l.client_id)::int count FROM loans l JOIN clients c ON c.id=l.client_id WHERE l.organization_id=$1 AND l.status IN ('active','disbursed') AND ${scopeSql}`,queryParams),
   db.query(`SELECT count(DISTINCT la.client_id)::int count FROM loan_applications la JOIN clients c ON c.id=la.client_id WHERE la.organization_id=$1 AND la.status NOT IN ('rejected','cancelled','disbursed','completed') AND (la.status IN ('awaiting_preview','awaiting_approval') OR c.workflow_status='awaiting_savings') AND ${scopeSql}`,queryParams),
   db.query(`SELECT count(*)::int count FROM clients c WHERE ${scope.join(' AND ')}`,params),
   db.query(`SELECT count(DISTINCT c.id)::int count FROM clients c LEFT JOIN loans l ON l.client_id=c.id AND l.organization_id=c.organization_id AND l.status IN ('active','disbursed') LEFT JOIN collection_records cr ON cr.client_id=c.id AND cr.organization_id=c.organization_id AND cr.loan_id=l.id WHERE ${scope.join(' AND ')} AND l.id IS NOT NULL AND (cr.id IS NULL OR cr.collection_date < CURRENT_DATE)`,params)
 ]);
 return res.json({role:s.role,organization_id:s.organization_id,branch_id:s.branch_id,clients:clients.rows[0].count,daily_collection_clients:daily.rows[0].count,active_loan_clients:activeLoans.rows[0].count,awaiting_preview:awaiting.rows[0].count,defaulting_clients:defaulting.rows[0].count});
}
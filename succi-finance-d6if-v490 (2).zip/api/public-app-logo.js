import { db } from 'hatchable';
export const access='public';
export const methods=['GET'];
export default async function(req,res){
  try{
    const {rows}=await db.query('SELECT logo_url FROM app_branding WHERE id=1');
    const url=String(rows[0]?.logo_url||'').trim();
    if(!url){res.setHeader('Cache-Control','public, max-age=60');return res.redirect('/succi-tech-logo.svg');}
    // Let the CDN/storage serve the image directly. This avoids downloading the
    // logo through the API and then re-sending its bytes, which made first paint slow.
    const parsed=new URL(url);
    if(!/^https?:$/.test(parsed.protocol))throw Error('Invalid logo URL');
    res.setHeader('Cache-Control','public, max-age=60, stale-while-revalidate=300');
    return res.redirect(url);
  }catch{
    res.setHeader('Cache-Control','public, max-age=60');
    return res.redirect('/succi-tech-logo.svg');
  }
}
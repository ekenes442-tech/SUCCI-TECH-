import { db, auth } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access = 'public';
export const methods = ['GET'];
export default async function(req,res){
 const authResult=await requireStaff(req,res); if(!authResult)return;
  const user = req.user;
  const email = String(user.email || '').toLowerCase();
  const {rows} = await db.query(`SELECT s.id,s.full_name,s.email,s.role,s.status,s.organization_id,o.name organization_name FROM staff s JOIN organizations o ON o.id=s.organization_id WHERE lower(s.email)=lower($1) LIMIT 1`,[email]);
  if(!rows.length || rows[0].role!=='general_overseer') return res.status(403).json({error:'This test account is not the SUCCI TECH General Overseer demo account.'});
  return res.json({user:{id:user.id,email:user.email,name:user.name||user.email},profile:rows[0]});
}
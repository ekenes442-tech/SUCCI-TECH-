import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access = 'public';
export const methods = ['GET'];

export default async function (req, res) {
  const auth = await requireStaff(req,res); if(!auth)return;
  let staff = auth.staff;
  if (!staff && auth.user?.email?.toLowerCase()==='ekenes442@gmail.com') {
    const {rows}=await db.query('SELECT email,display_name,status FROM system_admin_identities WHERE lower(email)=lower($1) LIMIT 1',[auth.user.email]);
    const identity=rows[0];
    if(!identity || identity.status!=='active') return res.status(403).json({error:'System Admin account is not activated yet.'});
    const {rows:permissions}=await db.query('SELECT permission_key FROM role_permissions WHERE role=$1 ORDER BY permission_key',['system_admin']);
    const {rows:navigation}=await db.query('SELECT nav_key FROM role_navigation_rules WHERE role=$1 ORDER BY nav_key',['system_admin']);
    return res.json({role:'system_admin',organization_id:null,branch_id:null,permissions:permissions.map(x=>x.permission_key),navigation:navigation.map(x=>x.nav_key),profile:{email:identity.email,full_name:identity.display_name||'SUCCI TECH System Admin'}});
  }
  if (!staff) return res.status(403).json({error:'Staff profile not found.'});
  if (staff.status !== 'active') return res.status(403).json({error:'Account Deactivated'});
  const { rows: permissions } = await db.query('SELECT permission_key FROM role_permissions WHERE role=$1 ORDER BY permission_key', [staff.role]);
  const { rows: navigation } = await db.query('SELECT nav_key FROM role_navigation_rules WHERE role=$1 ORDER BY nav_key', [staff.role]);
  res.json({role:staff.role,organization_id:staff.organization_id,branch_id:staff.branch_id,permissions:permissions.map(x=>x.permission_key),navigation:navigation.map(x=>x.nav_key)});
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access = 'public';
export const methods = ['GET'];
export default async function(req,res){
  const authResult=await requireStaff(req,res); if(!authResult)return;
  if(authResult.staff===null && String(req.member?.role||'').toLowerCase()==='system_admin'){
    return res.json({profile:{email:req.member.email,full_name:req.member.display_name||'SUCCI TECH System Admin',role:'system_admin',status:'active',organization_name:'SUCCI TECH',organization_status:'active'}});
  }
  const profileRows=await db.query(`SELECT s.id,s.organization_id,s.branch_id,s.full_name,s.email,s.role,s.status,s.permission_version,o.name organization_name,o.status organization_status,b.name branch_name,b.status branch_status
    FROM staff s JOIN organizations o ON o.id=s.organization_id LEFT JOIN branches b ON b.id=s.branch_id
    WHERE s.auth_user_id=$1 OR lower(s.email)=lower($2) LIMIT 1`,[req.member.id,req.member.email]);
  if(!profileRows.rows.length)return res.status(403).json({error:'No SUCCI TECH staff profile is linked to this account.'});
  const profile=profileRows.rows[0];
  if(String(profile.status).toLowerCase()!=='active'||String(profile.organization_status).toLowerCase()!=='active'||profile.branch_status&&String(profile.branch_status).toLowerCase()!=='active')return res.status(403).json({error:'This account or its organization/branch is inactive.'});
  res.json({profile});
}
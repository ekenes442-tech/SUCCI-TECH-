import { db } from 'hatchable';
export const access='public';
export const methods=['POST'];
const SUPABASE_URL='https://pescjtcaggyyafulstkl.supabase.co';
const SUPABASE_ANON_KEY='sb_publishable_vJdmMRw1nZdAE_mucqlECQ_cFAyqn1S';
export default async function(req,res){
  const bearer=String(req.headers?.authorization||'');
  const token=bearer.startsWith('Bearer ')?bearer.slice(7).trim():'';
  if(!token)return res.status(401).json({error:'Authentication required.'});
  const vr=await fetch(SUPABASE_URL+'/auth/v1/user',{headers:{apikey:SUPABASE_ANON_KEY,Authorization:'Bearer '+token}});
  const user=await vr.json().catch(()=>null);
  if(!vr.ok||!user?.id)return res.status(401).json({error:'Supabase authentication session is invalid or expired.'});
  const email=String(user.email||'').trim().toLowerCase();
  if(email==='ekenes442@gmail.com'){
    const r=await db.query("UPDATE system_admin_identities SET auth_user_id=$1,status='active',activated_at=COALESCE(activated_at,now()),updated_at=now() WHERE lower(email)=lower($2) RETURNING email,display_name,status,auth_user_id",[String(user.id),email]);
    if(!r.rows[0])return res.status(403).json({error:'System Admin identity is not configured for this email.'});
    return res.json({ok:true,user_id:String(user.id),staff_id:null,role:'system_admin',status:'active'});
  }
  const {rows}=await db.query('SELECT id,role,status FROM staff WHERE lower(email)=lower($1) OR auth_user_id=$2 OR supabase_user_id=$2 LIMIT 1',[email,String(user.id)]);
  const staff=rows[0];
  if(!staff)return res.status(403).json({error:'This email is not registered as SUCCI TECH staff.'});
  if(staff.status && staff.status!=='active')return res.status(403).json({error:'Staff account is not active.'});
  await db.query('UPDATE staff SET auth_user_id=COALESCE(auth_user_id,$1) WHERE id=$2',[String(user.id),staff.id]);
  res.json({ok:true,user_id:String(user.id),staff_id:staff.id,role:staff.role,status:staff.status});
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access = 'public';
export const methods = ['POST'];

async function getStaff(req) {
  const byAuth=(await db.query("SELECT id,organization_id,branch_id,role FROM staff WHERE auth_user_id=$1 AND status='active' LIMIT 1",[req.member.id])).rows[0];
  if(byAuth)return byAuth;
  if(req.member?.email){const byEmail=(await db.query("SELECT id,organization_id,branch_id,role FROM staff WHERE lower(email)=lower($1) AND auth_user_id IS NULL AND status='active' LIMIT 1",[req.member.email])).rows[0];if(byEmail){await db.query("UPDATE staff SET auth_user_id=$1 WHERE id=$2 AND auth_user_id IS NULL",[req.member.id,byEmail.id]);return byEmail;}}
  return null;
}

export default async function(req,res){
  const authResult=await requireStaff(req,res); if(!authResult)return;
  const staff=await getStaff(req); if(!staff)return res.status(403).json({error:'Active staff profile not found.'});
  if(staff.role!=='credit_officer')return res.status(403).json({error:'Only a Credit Officer can register a client.'});
  const b=req.body||{};
  const fullName=String(b.full_name||'').trim(), phone=String(b.phone||'').trim();
  const clientType=b.client_type==='group'?'group':'individual';
  const serviceType=b.service_type==='loan'?'loan':'daily_collection';
  const rawDay=String(b.collection_day||'').trim().toLowerCase();
  const day=serviceType==='loan' ? (rawDay||null) : null;
  const loanAmount=Number(b.loan_amount||0);
  const guarantors=Array.isArray(b.guarantors)?b.guarantors:[];
  if(!fullName||!phone)return res.status(400).json({error:'Full name and phone number are required.'});
  if(!b.declaration_accepted)return res.status(400).json({error:'You must accept the declaration before registering this client.'});
  if(serviceType==='loan' && !['monday','tuesday','wednesday','thursday','friday'].includes(day))return res.status(400).json({error:'Collection day is required for Loan Clients. Please select Monday to Friday.'});
  if(serviceType==='daily_collection' && day) return res.status(400).json({error:'Collection day is not used for Daily Collection Clients.'});
  if(serviceType==='loan'&&loanAmount<=0)return res.status(400).json({error:'Loan amount is required for a Loan Client.'});
  if(!staff.branch_id)return res.status(400).json({error:'Your staff profile is not assigned to a branch.'});
  if(serviceType==='loan' && guarantors.length>(clientType==='individual'?2:1))return res.status(400).json({error:'Only the allowed number of guarantors may be registered.'});
  const duplicate=await db.query('SELECT id FROM clients WHERE organization_id=$1 AND phone=$2 LIMIT 1',[staff.organization_id,phone]);
  if(duplicate.rows.length)return res.status(409).json({error:'This phone number is already used by a client in this organization.'});
  for(const g of guarantors){
    const gp=String(g.phone||'').trim();
    if(!g.full_name||!gp)return res.status(400).json({error:'Each guarantor must have a name and phone number.'});
    if(gp===phone)return res.status(400).json({error:'A guarantor cannot use the client phone number.'});
    const used=await db.query('SELECT id FROM clients WHERE organization_id=$1 AND phone=$2 LIMIT 1',[staff.organization_id,gp]);
    if(used.rows.length)return res.status(409).json({error:`Guarantor phone ${gp} is already used by a client in this organization.`});
    const usedG=await db.query('SELECT id FROM client_guarantors WHERE organization_id=$1 AND phone=$2 LIMIT 1',[staff.organization_id,gp]);
    if(usedG.rows.length)return res.status(409).json({error:`Guarantor phone ${gp} is already used by another guarantor in this organization.`});
  }
  // A new loan client is NOT ready for Supervisor review at registration.
// The client must first complete the required 10% savings and then the
// Credit Officer must complete the profile/guarantors before submission.
const workflow='awaiting_savings';
  const inserted=await db.query(`INSERT INTO clients (organization_id,branch_id,credit_officer_id,client_type,full_name,phone,address,collection_day,workflow_status,date_of_birth,gender,marital_status,alternative_phone,email,occupation,employer_business_name,business_address,state,lga,id_type,id_number,next_of_kin_name,next_of_kin_relationship,next_of_kin_phone,next_of_kin_address,loan_purpose,repayment_frequency,repayment_term,bank_name,account_name,account_number,savings_required,declaration_accepted) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33) RETURNING id,full_name,phone,collection_day,workflow_status`,[staff.organization_id,staff.branch_id,staff.id,clientType,fullName,phone,b.address||null,day,workflow,b.date_of_birth||null,b.gender||null,b.marital_status||null,b.alternative_phone||null,b.email||null,b.occupation||null,b.employer_business_name||null,b.business_address||null,b.state||null,b.lga||null,b.id_type||null,b.id_number||null,b.next_of_kin_name||null,b.next_of_kin_relationship||null,b.next_of_kin_phone||null,b.next_of_kin_address||null,b.loan_purpose||null,b.repayment_frequency||null,(b.repayment_term?Number(b.repayment_term):null),b.bank_name||null,b.account_name||null,b.account_number||null,(b.savings_required?Number(b.savings_required):0),Boolean(b.declaration_accepted)]);
  const clientId=inserted.rows[0].id;
  for(let i=0;i<guarantors.length;i++){const g=guarantors[i];await db.query(`INSERT INTO client_guarantors (organization_id,branch_id,client_id,guarantor_number,full_name,phone,relationship,occupation,address,id_type,id_number) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,[staff.organization_id,staff.branch_id,clientId,i+1,String(g.full_name).trim(),String(g.phone).trim(),g.relationship||null,g.occupation||null,g.address||null,g.id_type||null,g.id_number||null]);}
  if(serviceType==='daily_collection'){
    await db.query(`INSERT INTO service_accounts (organization_id,branch_id,client_id,service_type,status,monthly_charge,withdrawable_balance) VALUES ($1,$2,$3,'daily_collection','active',0,0)`,[staff.organization_id,staff.branch_id,clientId]);
  }else{
    const setting=await db.query(`SELECT interest_rate FROM organization_loan_settings WHERE organization_id=$1 LIMIT 1`,[staff.organization_id]);
    const interestRate=Number(setting.rows[0]?.interest_rate ?? 3);
    await db.query(`INSERT INTO loan_applications (organization_id,branch_id,client_id,credit_officer_staff_id,amount,interest_rate,status) VALUES ($1,$2,$3,$4,$5,$6,'awaiting_savings')`,[staff.organization_id,staff.branch_id,clientId,staff.id,loanAmount,interestRate]);
  }
  res.status(201).json({ok:true,client:inserted.rows[0],service_type:serviceType});
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
  const auth=await requireStaff(req,res); if(!auth)return;
  const s=auth.staff; const id=String(req.query?.client_id||'').trim();
  if(!id)return res.status(400).json({error:'Client ID is required.'});
  const role=String(s.role||'').toLowerCase();
  const params=[id,s.organization_id]; let scope='c.organization_id=$2';
  if(['branch_manager','supervisor','auditor','operational_manager'].includes(role)){if(!s.branch_id)return res.status(403).json({error:'No assigned branch.'});params.push(s.branch_id);scope+=' AND c.branch_id=$3'}
  else if(role==='credit_officer'){params.push(s.branch_id,s.id);scope+=' AND c.branch_id=$3 AND c.credit_officer_id=$4'}
  else return res.status(403).json({error:'Staff access required.'});
  const {rows}=await db.query(`SELECT c.id,c.full_name,c.phone,c.address,c.gender,c.marital_status,c.date_of_birth,c.occupation,c.employer_business_name,c.business_address,c.state,c.lga,c.client_type,c.loan_purpose,c.repayment_frequency,c.repayment_term,c.collection_day,c.next_of_kin_name,c.next_of_kin_relationship,c.workflow_status,b.name branch_name,st.full_name credit_officer_name,COALESCE((SELECT SUM(ls.amount) FROM loan_savings ls WHERE ls.organization_id=c.organization_id AND ls.client_id=c.id),0)::numeric savings_paid,COALESCE((SELECT json_agg(json_build_object('id',g.id,'guarantor_number',g.guarantor_number,'full_name',g.full_name,'phone',g.phone,'relationship',g.relationship,'occupation',g.occupation,'address',g.address,'id_type',g.id_type,'id_number',g.id_number,'passport_photo_url',g.passport_photo_url) ORDER BY g.guarantor_number) FROM client_guarantors g WHERE g.organization_id=c.organization_id AND g.client_id=c.id),'[]'::json) guarantors FROM clients c JOIN branches b ON b.id=c.branch_id LEFT JOIN staff st ON st.id=c.credit_officer_id WHERE c.id=$1 AND ${scope} LIMIT 1`,params);
  if(!rows.length)return res.status(404).json({error:'Client not found in your authorized scope.'});
  const {rows:clientImages}=await db.query('SELECT passport_photo_url FROM clients WHERE id=$1 AND organization_id=$2 LIMIT 1',[id,s.organization_id]);
  const {rows:collateralImages}=await db.query('SELECT id,image_url,description,created_at FROM client_collateral_images WHERE client_id=$1 AND organization_id=$2 ORDER BY created_at DESC',[id,s.organization_id]);
  rows[0].passport_photo_url=clientImages[0]?.passport_photo_url||null;
  rows[0].collateral_images=collateralImages;
  const {rows:loans}=await db.query(`SELECT id,principal,interest_amount,total_payable,status,created_at,disbursed_at,repayment_frequency,term_count FROM loans WHERE organization_id=$1 AND client_id=$2 ORDER BY created_at DESC`,[s.organization_id,id]);
  res.json({client:rows[0],loans});
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const auth=await requireStaff(req,res); if(!auth)return;
 const me=auth.staff, role=String(me.role).toLowerCase();
 if(!['general_overseer','branch_manager'].includes(role))return res.status(403).json({error:'Only the General Overseer or Branch Manager can register organization staff.'});
 const branches=role==='branch_manager'
   ? await db.query(`SELECT id,name,email FROM branches WHERE id=$1 AND organization_id=$2 AND status='active' ORDER BY name`,[me.branch_id,me.organization_id])
   : await db.query(`SELECT id,name,email FROM branches WHERE organization_id=$1 AND status='active' ORDER BY name`,[me.organization_id]);
 const allowed=role==='branch_manager'?['supervisor','auditor','credit_officer']:['general_supervisor','operational_manager','branch_manager','supervisor','auditor','credit_officer'];
 const {rows:roles}=await db.query(`SELECT role,label FROM staff_role_catalog WHERE active=true ORDER BY label`);
 res.json({branches:branches.rows,roles:roles.filter(r=>allowed.includes(String(r.role).toLowerCase())),manager_role:role,manager_branch_id:me.branch_id});
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['POST'];
const allowed=['general_supervisor','operational_manager','branch_manager','supervisor','auditor','credit_officer'];
const bmAllowed=['supervisor','credit_officer'];
export default async function(req,res){
 const auth=await requireStaff(req,res); if(!auth)return;
 const actor=auth.staff, actorRole=String(actor.role).toLowerCase();
 if(actorRole==='branch_manager')return res.status(403).json({error:'Branch Managers cannot create staff. They can only manage staff already assigned to their branch.'});
 if(actorRole!=='general_overseer')return res.status(403).json({error:'Only the General Overseer can register staff.'});
 const body=req.body||{};
 const full=String(body.full_name||'').trim(),loginEmail=String(body.login_email||'').trim().toLowerCase(),password=String(body.password||''),confirmPassword=String(body.confirm_password||''),phone=String(body.phone||'').trim(),role=String(body.role||'').trim().toLowerCase(),newAuthUserId=String(body.auth_user_id||'').trim();
 const branchIds=Array.isArray(body.branch_ids)?body.branch_ids.map(x=>String(x||'').trim()).filter(Boolean):[];
 const branch=String(body.branch_id||'').trim() || branchIds[0] || (actorRole==='branch_manager'?String(actor.branch_id||'').trim():'');
 if(!full||!loginEmail||!password||!confirmPassword||!role||!branch)return res.status(400).json({error:'Full name, email, password, confirm password, role and branch are required.'});
 if(role==='auditor'&&actorRole==='general_overseer'&&branchIds.length===0)return res.status(400).json({error:'Select at least one branch for an Auditor.'});
 if(password.length<8)return res.status(400).json({error:'Password must be at least 8 characters.'});
 if(password!==confirmPassword)return res.status(400).json({error:'Password and confirm password do not match.'});
 if(!allowed.includes(role))return res.status(400).json({error:'Invalid staff role.'});
 if(!newAuthUserId)return res.status(400).json({error:'The staff login account was not created. Please try again.'});
 if(actorRole==='branch_manager'&&!bmAllowed.includes(role))return res.status(403).json({error:'Branch Managers may create only Supervisor and Credit Officer staff in their assigned branch.'});
 if(actorRole==='branch_manager'&&branch!==String(actor.branch_id||'').trim())return res.status(403).json({error:'Branch Managers may create staff only in their assigned branch.'});
 const {rows:b}=await db.query(`SELECT id,name,email FROM branches WHERE id=$1 AND organization_id=$2 AND status='active'`,[branch,actor.organization_id]);
 if(!b.length)return res.status(400).json({error:'Selected branch does not belong to this organization.'});
 const {rows:dupe}=await db.query(`SELECT id FROM staff WHERE organization_id=$1 AND (lower(email)=lower($2) OR ($3<>'' AND phone=$3)) AND deleted_at IS NULL LIMIT 1`,[actor.organization_id,loginEmail,phone]);
 if(dupe.length)return res.status(409).json({error:'This login email or phone number is already registered in this organization.'});
 const {rows:seq}=await db.query(`SELECT count(*)::int+1 n FROM staff WHERE organization_id=$1 AND branch_id=$2`,[actor.organization_id,branch]);
 const code=(String(b[0].name).replace(/[^A-Za-z0-9]/g,'').slice(0,4).toUpperCase()||'BRCH')+'-'+String(seq[0].n).padStart(3,'0');
 await db.query(`INSERT INTO invited_users (email) VALUES (lower($1)) ON CONFLICT DO NOTHING`,[loginEmail]);
 const {rows}=await db.query(`INSERT INTO staff(organization_id,branch_id,full_name,email,phone,role,status,role_assigned_at,role_assigned_by,staff_code,created_by_auth_user_id,created_by_role,supabase_user_id,auth_user_id) VALUES($1,$2,$3,$4,$5,$6,'active',now(),$7,$8,$9,$10,$11,$11) RETURNING id,full_name,email,phone,role,status,branch_id,staff_code`,[actor.organization_id,branch,full,loginEmail,phone||null,role,actor.id,code,auth.user.id,actorRole,newAuthUserId||null]);
 await db.query(`INSERT INTO staff_management_audit(staff_id,organization_id,branch_id,action,actor_staff_id,actor_auth_user_id,actor_role,reason) VALUES($1,$2,$3,'create',$4,$5,$6,$7)`,[rows[0].id,actor.organization_id,branch,actor.id,auth.user.id,actorRole,'Staff account created']);
 if(role==='auditor'){
   const ids=[...new Set(branchIds.length?branchIds:[branch])];
   for(const bid of ids){const {rows:ok}=await db.query(`SELECT id FROM branches WHERE id=$1 AND organization_id=$2 AND status='active'`,[bid,actor.organization_id]);if(!ok.length)continue;await db.query(`INSERT INTO auditor_branch_assignments(organization_id,auditor_staff_id,branch_id,assigned_by_staff_id) VALUES($1,$2,$3,$4) ON CONFLICT(auditor_staff_id,branch_id) DO NOTHING`,[actor.organization_id,rows[0].id,bid,actor.id]);}
 }
 res.status(201).json({staff:rows[0],login_email:loginEmail,staff_code:code,message:'Staff registered successfully.'});
}
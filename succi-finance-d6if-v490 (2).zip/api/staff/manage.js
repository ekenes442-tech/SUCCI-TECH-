import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['POST'];
const bmRoles=['supervisor','auditor','credit_officer'];
export default async function(req,res){
 const auth=await requireStaff(req,res); if(!auth)return;
 const body=req.body||{},targetId=String(body.staff_id||'').trim(),action=String(body.action||'').trim().toLowerCase(),reason=String(body.reason||'').trim()||null;
 if(!targetId||!['activate','suspend','deactivate','delete'].includes(action))return res.status(400).json({error:'Staff ID and a valid action are required.'});
 const actor=auth.staff,actorRole=String(actor.role).toLowerCase();
 if(!['general_overseer','branch_manager'].includes(actorRole))return res.status(403).json({error:'You are not authorized to manage staff.'});
 const {rows:targets}=await db.query(`SELECT id,organization_id,branch_id,full_name,email,role,status FROM staff WHERE id=$1 AND deleted_at IS NULL LIMIT 1`,[targetId]);
 if(!targets.length)return res.status(404).json({error:'Staff member not found.'});
 const target=targets[0];
 if(String(target.organization_id)!==String(actor.organization_id))return res.status(403).json({error:'Cross-organization staff management is forbidden.'});
 if(String(target.id)===String(actor.id))return res.status(400).json({error:'You cannot change your own management account.'});
 if(actorRole==='branch_manager'){
   if(String(target.branch_id||'')!==String(actor.branch_id||''))return res.status(403).json({error:'Branch Managers can manage staff only in their assigned branch.'});
   if(!bmRoles.includes(String(target.role).toLowerCase()))return res.status(403).json({error:'Branch Managers may manage only Supervisor, Auditor and Credit Officer staff in their assigned branch.'});
   if(!['activate','suspend','deactivate'].includes(action))return res.status(403).json({error:'Branch Managers may only activate, suspend, or deactivate staff in their assigned branch.'});
 }
 const nextStatus=action==='activate'?'active':action==='suspend'?'suspended':'inactive';
 await db.transaction([
  {sql:`UPDATE staff SET status=$1,status_reason=$2,permission_version=permission_version+1,deleted_at=CASE WHEN $3='delete' THEN now() ELSE deleted_at END,deleted_by_auth_user_id=CASE WHEN $3='delete' THEN $4 ELSE deleted_by_auth_user_id END WHERE id=$5 AND organization_id=$6`,params:[nextStatus,reason,action,auth.user.id,target.id,actor.organization_id]},
  {sql:`INSERT INTO staff_management_audit(staff_id,organization_id,branch_id,action,actor_staff_id,actor_auth_user_id,actor_role,reason) VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,params:[target.id,target.organization_id,target.branch_id,action,actor.id,auth.user.id,actor.role,reason]},
  {sql:`INSERT INTO security_events(organization_id,actor_auth_user_id,actor_role,event_type,target_type,target_id,reason,metadata) VALUES($1,$2,$3,$4,'staff',$5,$6,$7)`,params:[actor.organization_id,auth.user.id,actor.role,'staff_'+action,target.id,reason,JSON.stringify({branch_id:target.branch_id,target_role:target.role,email:target.email})]}
 ]);
 res.json({ok:true,action,status:nextStatus,staff_id:target.id});
}
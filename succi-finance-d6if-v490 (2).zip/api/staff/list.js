import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const auth=await requireStaff(req,res); if(!auth)return;
 const me=auth.staff; const role=String(me.role).toLowerCase();
 if(!['general_overseer','branch_manager'].includes(role))return res.status(403).json({error:'Only the General Overseer or Branch Manager can manage staff from this screen.'});
 const requestedBranch=String(req.query?.branch||'');
 const branch=role==='branch_manager'?String(me.branch_id||''):requestedBranch;
 if(role==='branch_manager'&&!branch)return res.status(403).json({error:'Branch Manager has no assigned branch.'});
 const params=[me.organization_id]; let where=`s.organization_id=$1 AND s.deleted_at IS NULL`;
 if(branch){params.push(branch);where+=` AND s.branch_id=$${params.length}`}
 if(role==='branch_manager'){
   params.push(me.id); where+=` AND s.id<>$${params.length}`;
   where+=` AND s.role IN ('supervisor','auditor','credit_officer')`;
 }
 const {rows}=await db.query(`SELECT s.id,s.full_name,s.email,s.phone,s.role,s.status,s.branch_id,b.name branch_name,s.staff_code,s.role_assigned_at,s.deleted_at FROM staff s LEFT JOIN branches b ON b.id=s.branch_id WHERE ${where} ORDER BY b.name NULLS FIRST,s.full_name`,params);
 let managerBranchEmail='',managerBranchName='';
 if(role==='branch_manager'&&me.branch_id){const br=await db.query(`SELECT name,email FROM branches WHERE id=$1 AND organization_id=$2 LIMIT 1`,[me.branch_id,me.organization_id]);managerBranchEmail=String(br.rows[0]?.email||'');managerBranchName=String(br.rows[0]?.name||'');}
 res.json({staff:rows,manager_role:role,manager_branch_id:me.branch_id,manager_branch_email:managerBranchEmail,manager_branch_name:managerBranchName});
}
import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const auth=await requireStaff(req,res); if(!auth)return;
 const p=auth.staff; const q=req.query||{};
 const params=[p.organization_id]; const where=['c.organization_id=$1'];
 const role=String(p.role).toLowerCase();
 if(['branch_manager','supervisor','auditor','operational_manager'].includes(role)){
   if(!p.branch_id)return res.status(403).json({error:'This staff member has no assigned branch.'});
   params.push(p.branch_id); where.push(`c.branch_id=$${params.length}`);
 } else if(role==='credit_officer'){
   if(!p.branch_id || !p.id)return res.status(403).json({error:'Credit Officer has no authorized client scope.'});
   params.push(p.branch_id); where.push(`c.branch_id=$${params.length}`);
   params.push(p.id); where.push(`(c.credit_officer_id=$${params.length} OR EXISTS (SELECT 1 FROM loan_applications la_scope WHERE la_scope.organization_id=c.organization_id AND la_scope.client_id=c.id AND la_scope.branch_id=$${params.length-1} AND la_scope.credit_officer_staff_id=$${params.length} AND la_scope.status NOT IN ('rejected','cancelled','disbursed','completed')))`);
 } else if(q.branch_id){params.push(q.branch_id);where.push(`c.branch_id=$${params.length}`)}
 if(role==='credit_officer'){delete q.staff_id;delete q.branch_id}
 if(q.staff_id){params.push(q.staff_id);where.push(`c.credit_officer_id=$${params.length}`)}
 if(q.search){params.push(`%${q.search}%`);where.push(`(c.full_name ILIKE $${params.length} OR c.phone ILIKE $${params.length} OR CAST(c.id AS text) ILIKE $${params.length})`)}
 if(q.status){params.push(q.status);where.push(`c.workflow_status=$${params.length}`)}
 if(q.client_id){params.push(q.client_id);where.push(`c.id=$${params.length}`)}
 const {rows}=await db.query(`SELECT c.id,c.full_name,c.phone,c.client_type,c.workflow_status,c.collection_day,c.created_at,b.id branch_id,b.name branch_name,s.id staff_id,s.full_name staff_name,s.role staff_role,COALESCE(l.loan_count,0) loan_count FROM clients c JOIN branches b ON b.id=c.branch_id LEFT JOIN staff s ON s.id=c.credit_officer_id LEFT JOIN (SELECT client_id,count(*) loan_count FROM loans WHERE organization_id=$1 GROUP BY client_id) l ON l.client_id=c.id WHERE ${where.join(' AND ')} ORDER BY c.created_at DESC`,params);
 res.json({clients:rows,count:rows.length,scope:{organization_id:p.organization_id,branch_id:['branch_manager','supervisor','auditor','operational_manager'].includes(role)?p.branch_id:null}});
}
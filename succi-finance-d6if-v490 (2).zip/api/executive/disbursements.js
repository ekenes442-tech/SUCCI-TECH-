import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const auth=await requireStaff(req,res); if(!auth)return;
 const p=auth.staff; if(String(p.role||'').toLowerCase()==='credit_officer')return res.status(403).json({error:'Credit Officers are not permitted to access Disbursement History.',code:'FORBIDDEN_ROLE'});
 const q=req.query||{}; const params=[p.organization_id]; const where=[`d.organization_id=$1`,`d.status='completed'`];
 if(String(p.role).toLowerCase()==='branch_manager'){if(!p.branch_id)return res.status(403).json({error:'Branch Manager has no assigned branch.'});params.push(p.branch_id);where.push(`d.branch_id=$${params.length}`)}
 else if(q.branch_id){params.push(q.branch_id);where.push(`d.branch_id=$${params.length}`)}
 if(q.date){params.push(q.date);where.push(`(d.disbursed_at AT TIME ZONE 'Africa/Lagos')::date=$${params.length}::date`)}
 if(q.staff_id){params.push(q.staff_id);where.push(`c.credit_officer_id=$${params.length}`)}
 if(q.client_id){params.push(q.client_id);where.push(`c.id=$${params.length}`)}
 if(q.search){params.push(`%${q.search}%`);where.push(`(c.full_name ILIKE $${params.length} OR CAST(l.id AS text) ILIKE $${params.length})`)}
 const {rows}=await db.query(`SELECT d.id disbursement_id,d.amount,d.disbursed_at,d.status,l.id loan_id,l.principal,l.total_payable,c.id client_id,c.full_name client_name,b.id branch_id,b.name branch_name,co.id co_id,co.full_name co_name,ds.full_name disbursed_by_name FROM disbursements d JOIN loans l ON l.id=d.loan_id JOIN clients c ON c.id=l.client_id JOIN branches b ON b.id=d.branch_id LEFT JOIN staff co ON co.id=c.credit_officer_id LEFT JOIN staff ds ON ds.id=d.disbursed_by_staff_id WHERE ${where.join(' AND ')} ORDER BY d.disbursed_at DESC,c.full_name`,params);
 const total=rows.reduce((n,x)=>n+Number(x.amount||0),0); res.json({disbursements:rows,total_amount:total,count:rows.length,scope:{organization_id:p.organization_id,branch_id:String(p.role).toLowerCase()==='branch_manager'?p.branch_id:null}});
}
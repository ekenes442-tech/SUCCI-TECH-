import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const auth=await requireStaff(req,res); if(!auth)return;
 const p=auth.staff,q=req.query||{}; const params=[p.organization_id]; const where=['l.organization_id=$1'];
 if(String(p.role).toLowerCase()==='branch_manager'){if(!p.branch_id)return res.status(403).json({error:'Branch Manager has no assigned branch.'});params.push(p.branch_id);where.push(`l.branch_id=$${params.length}`)}
 else if(q.branch_id){params.push(q.branch_id);where.push(`l.branch_id=$${params.length}`)}
 if(q.staff_id){params.push(q.staff_id);where.push(`l.client_id IN (SELECT id FROM clients WHERE credit_officer_id=$${params.length} AND organization_id=$1)`)}
 if(q.search){params.push(`%${q.search}%`);where.push(`(c.full_name ILIKE $${params.length} OR CAST(l.id AS text) ILIKE $${params.length} OR CAST(l.client_id AS text) ILIKE $${params.length})`)}
 const {rows}=await db.query(`SELECT l.id loan_id,l.principal,l.interest_rate,l.interest_amount,l.total_payable,l.repayment_frequency,l.term_count,l.status,l.disbursed_at,c.id client_id,c.full_name client_name,b.id branch_id,b.name branch_name,s.id staff_id,s.full_name staff_name FROM loans l JOIN clients c ON c.id=l.client_id JOIN branches b ON b.id=l.branch_id LEFT JOIN staff s ON s.id=c.credit_officer_id WHERE ${where.join(' AND ')} ORDER BY l.created_at DESC`,params);
 res.json({loans:rows,count:rows.length});
}
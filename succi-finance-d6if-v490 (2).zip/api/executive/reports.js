import { db } from 'hatchable';
import { requireStaff } from '../../lib/supabase-auth.js';
export const access='public'; export const methods=['GET'];
export default async function(req,res){
 const auth=await requireStaff(req,res); if(!auth)return;
 const p=auth.staff; const role=String(p.role||'').toLowerCase().replace(/[-_]+/g,' ').replace(/\s+/g,' ').trim();
 if(role==='credit officer')return res.status(403).json({error:'Credit Officers do not have access to reports.'});
 const params=[p.organization_id]; let branchWhere='b.organization_id=$1'; let clientExtra='',loanExtra='',disbExtra='',defaultExtra='';
 if(['branch manager','supervisor','auditor','operational manager'].includes(role)){if(!p.branch_id)return res.status(403).json({error:'This staff member has no assigned branch.'});params.push(p.branch_id);branchWhere+=` AND b.id=$${params.length}`}
 const coId=String(req.query?.credit_officer_id||'').trim();
 if(coId){
   if(role!=='supervisor')return res.status(403).json({error:'Credit Officer filtering on this report is not available for this role.'});
   const {rows:coRows}=await db.query(`SELECT id FROM staff WHERE id=$1 AND organization_id=$2 AND branch_id=$3 AND deleted_at IS NULL AND lower(replace(replace(role,'-','_'),' ','_')) IN ('credit_officer','co') AND lower(coalesce(status,'active')) NOT IN ('suspended','deactivated','inactive','deleted') LIMIT 1`,[coId,p.organization_id,p.branch_id]);
   if(!coRows.length)return res.status(400).json({error:'Selected Credit Officer is not authorized for this branch.'});
   const n=params.length+1; clientExtra=` AND c.credit_officer_id=$${n}`; loanExtra=` AND l.credit_officer_id=$${n}`; disbExtra=` AND EXISTS (SELECT 1 FROM loans lx WHERE lx.id=d.loan_id AND lx.organization_id=$1 AND lx.branch_id=b.id AND lx.credit_officer_id=$${n})`; defaultExtra=` AND l.credit_officer_id=$${n}`; params.push(coId);
 }
 const {rows}=await db.query(`SELECT b.id branch_id,b.name branch_name,b.status,
 (SELECT count(*) FROM clients c WHERE c.branch_id=b.id AND c.organization_id=$1${clientExtra}) clients,
 (SELECT count(*) FROM loans l WHERE l.branch_id=b.id AND l.organization_id=$1 AND l.status='active'${loanExtra}) active_loans,
 (SELECT count(*) FROM loans l WHERE l.branch_id=b.id AND l.organization_id=$1 AND l.status='disbursed'${loanExtra}) disbursed_loans,
 (SELECT COALESCE(sum(d.amount),0) FROM disbursements d WHERE d.branch_id=b.id AND d.organization_id=$1 AND d.status='completed'${disbExtra}) total_disbursed,
 (SELECT count(DISTINCT l.client_id) FROM loans l WHERE l.branch_id=b.id AND l.organization_id=$1 AND l.status IN ('active','disbursed') AND l.disbursed_at IS NOT NULL AND l.disbursed_at + (COALESCE(l.term_count,30) * CASE lower(COALESCE(l.repayment_frequency,'daily')) WHEN 'weekly' THEN interval '7 days' WHEN 'monthly' THEN interval '30 days' ELSE interval '1 day' END) < CURRENT_DATE AND COALESCE((SELECT SUM(cr.amount_paid) FROM collection_records cr WHERE cr.organization_id=l.organization_id AND cr.branch_id=l.branch_id AND cr.client_id=l.client_id AND cr.loan_id=l.id),0) < COALESCE(l.total_payable,l.principal+COALESCE(l.interest_amount,0),0)${defaultExtra}) defaulting_clients
 FROM branches b WHERE ${branchWhere} ORDER BY b.name`,params);
 res.json({branches:rows,scope:{organization_id:p.organization_id,branch_id:p.branch_id||null},filter:{credit_officer_id:coId||null}});
}
import { db } from "hatchable";
export const access="member";
export const methods=["GET","POST","PUT"];
async function staffFor(req){
 const byAuth=(await db.query("SELECT id,organization_id,role,status FROM staff WHERE auth_user_id=$1 LIMIT 1",[req.member.id])).rows[0];
 if(byAuth)return byAuth;
 if(req.member?.email){
  const byEmail=(await db.query("SELECT id,organization_id,role,status FROM staff WHERE lower(email)=lower($1) AND auth_user_id IS NULL LIMIT 1",[req.member.email])).rows[0];
  if(byEmail){await db.query("UPDATE staff SET auth_user_id=$1 WHERE id=$2 AND auth_user_id IS NULL",[req.member.id,byEmail.id]);return byEmail;}
 }
 return null;
}
function allowedRole(role){return ['general_overseer','general_manager','operational_manager','general_supervisor'].includes(String(role||'').toLowerCase().replaceAll(' ','_'))}
export default async function(req,res){
 const staff=await staffFor(req);
 if(!staff||staff.status!=='active') return res.status(403).json({error:'Active organization staff account not found.'});
 if(!allowedRole(staff.role)) return res.status(403).json({error:'You do not have permission to manage loan products.'});
 const org=staff.organization_id;
 if(req.method==='GET') return res.json({products:(await db.query("SELECT id,name,interest_rate,repayment_frequency,term_count,status,created_at FROM loan_products WHERE organization_id=$1 ORDER BY created_at DESC",[org])).rows});
 const b=req.body||{}; const rate=Number(b.interest_rate), term=Number(b.term_count); const frequency=b.repayment_frequency||'daily';
 if(!b.name||!Number.isFinite(rate)||rate<0||rate>100||!Number.isInteger(term)||term<1) return res.status(400).json({error:'Loan type, valid interest rate and tenure are required'});
 if(req.method==='POST'){
  const existing=(await db.query("SELECT id FROM loan_products WHERE organization_id=$1 AND lower(name)=lower($2) AND repayment_frequency=$3 AND term_count=$4 LIMIT 1",[org,b.name,frequency,term])).rows[0];
  if(existing) return res.status(409).json({error:'This loan type and tenure already exist.'});
  const r=await db.query("INSERT INTO loan_products(organization_id,name,interest_rate,repayment_frequency,term_count) VALUES($1,$2,$3,$4,$5) RETURNING *",[org,b.name,rate,frequency,term]);
  if(!r.rows[0]) return res.status(500).json({error:'Loan product could not be saved.'});
  return res.status(201).json({product:r.rows[0],message:'Loan tenure saved successfully.'});
 }
 if(!b.id)return res.status(400).json({error:'Product id required'});
 const r=await db.query("UPDATE loan_products SET name=$2,interest_rate=$3,repayment_frequency=$4,term_count=$5,status=$6 WHERE id=$1 AND organization_id=$7 RETURNING *",[b.id,b.name,rate,frequency,term,b.status||'active',org]);
 if(!r.rows[0]) return res.status(404).json({error:'Loan product not found'});
 return res.json({product:r.rows[0],message:'Loan tenure saved successfully.'});
}
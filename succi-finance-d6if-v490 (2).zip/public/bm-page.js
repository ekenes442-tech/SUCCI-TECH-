(function(){
  function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
  async function bmApi(url,opts){
    const headers=new Headers((opts&&opts.headers)||{});
    try{const s=await window.succiAuth?.auth?.getSession();const token=s?.data?.session?.access_token;if(token)headers.set('Authorization','Bearer '+token)}catch{}
    headers.set('Cache-Control','no-store');
    let requestUrl=url;
    if(url.startsWith('/api/branch-manager/')&&!url.includes('/dashboard-summary')&&!url.includes('/me')&&!url.includes('/loan-review')){
      const pageParams=new URLSearchParams(location.search); const co=pageParams.get('co_id'), search=pageParams.get('search');
      const u=new URL(url,location.origin); if(co&&!u.searchParams.has('co_id'))u.searchParams.set('co_id',co); if(search&&!u.searchParams.has('search'))u.searchParams.set('search',search); requestUrl=u.pathname+(u.search?'?'+u.searchParams.toString():'');
    }
    const r=await fetch(requestUrl,Object.assign({},opts||{},{credentials:'same-origin',cache:'no-store',headers}));
    const d=await r.json().catch(()=>({}));
    if(!r.ok) throw Error(d.error||`Request failed (${r.status})`);
    return d;
  }
  async function bmLoadBranch(){
    const d=await bmApi('/api/branch-manager/dashboard-summary');
    return {
      active_clients:Number(d.active_clients||0),
      active_loans:Number(d.active_loans||0),
      pending_disbursements:Number(d.pending_disbursements||0),
      expected_today:Number(d.expected_today||0),
      collected_today:Number(d.collected_today||0),
      collection_rate:Number(d.collection_rate||0),
      overdue_amount:Number(d.overdue_amount||0),
      defaulting_clients:Number(d.defaulting_clients||0),
      outstanding_portfolio:Number(d.outstanding_portfolio||0),
      expected_collections:Number(d.expected_today||0),
      todays_collections:Number(d.collected_today||0),
      performance:Array.isArray(d.performance)?d.performance.map(x=>({...x,rate:Number(x.expected||0)?Number(x.collected||0)/Number(x.expected||0)*100:0})):[],
      branch_name:d.branch_name||'Assigned Branch'
    };
  }
  window.bmApi=bmApi;window.bmLoadBranch=bmLoadBranch;window.esc=esc;
  window.bmPage=async function(title,subtitle,body){
    document.body.innerHTML=`
      <button class="bm-menu" id="bmMenu" aria-label="Open menu">☰</button>
      <div class="bm-overlay" id="bmOverlay"></div>
      <div class="bm-layout">
        <aside class="bm-side" id="bmSide">
          <img class="bm-logo" src="/succi-tech-logo.svg" alt="SUCCI TECH">
          <div class="bm-role">Branch Manager</div>
          <nav id="bm-nav"></nav>
        </aside>
        <main class="bm-main">
          <header class="bm-topbar"><div><div class="bm-title">SUCCI TECH</div><div class="bm-branch" data-bm-org>SUCCI TECH</div></div><div class="bm-topbar-welcome" data-bm-name>Loading…</div></header>
          <div class="bm-content"><div class="bm-page-head">${title==='Dashboard'?'<div class="bm-eyebrow">Executive workspace</div><div class="bm-welcome">Welcome, <span data-bm-name>Loading…</span></div><div class="bm-org" data-bm-org>SUCCI TECH</div>':''}<h1>${esc(title)}</h1><p>${esc(subtitle||'')}</p></div>${body||''}</div>
          <footer class="bm-footer">SUCCI TECH • Branch Manager Workspace</footer>
        </main>
      </div>`;
    if(window.BM&&typeof window.BM.init==='function')window.BM.init();
    if(title!=='Dashboard'){
      const head=document.querySelector('.bm-page-head'); if(head && !['Branch Clients','Repayment History','Disbursement History','Branch Reports'].includes(title)){const p=new URLSearchParams(location.search); const co=p.get('co_id')||''; const search=p.get('search')||''; const bar=document.createElement('div'); bar.className='bm-global-filter'; bar.innerHTML='<label>Credit Officer<select id="bmCo"><option value="">All Credit Officers</option></select></label><label>Search<input id="bmSearch" placeholder="Search this page"></label><button class="bm-btn primary" id="bmApply">Search</button><button class="bm-btn" id="bmClear">Clear</button>'; head.after(bar); const sel=bar.querySelector('#bmCo'), inp=bar.querySelector('#bmSearch'); inp.value=search; bmApi('/api/branch-manager/staff-performance').then(d=>{sel.innerHTML='<option value="">All Credit Officers</option>'+(d.credit_officers||[]).map(x=>'<option value="'+esc(x.id)+'">'+esc(x.full_name)+'</option>').join('');sel.value=co}).catch(()=>{}); bar.querySelector('#bmApply').onclick=()=>{const q=new URLSearchParams();if(sel.value)q.set('co_id',sel.value);if(inp.value.trim())q.set('search',inp.value.trim());location.href=location.pathname+(q.toString()?'?'+q.toString():'')};bar.querySelector('#bmClear').onclick=()=>location.href=location.pathname; }
    }
    Promise.all([bmApi('/api/account/profile'),bmApi('/api/branch-manager/dashboard-summary')]).then(([p,d])=>{const profile=p?.profile||{};const name=profile.full_name||d.display_name||'Branch Manager';const org=profile.organization_name||d.organization_name||'SUCCI TECH Demo Organization';const branch=profile.branch_name||d.branch_name||'Assigned Branch';document.querySelectorAll('[data-bm-name]').forEach(el=>el.textContent=name);document.querySelectorAll('[data-bm-org]').forEach(el=>el.textContent=org);document.querySelectorAll('[data-bm-branch]').forEach(el=>el.textContent=branch);}).catch(()=>{});
  };
})();
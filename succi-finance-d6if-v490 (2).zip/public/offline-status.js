(function(){
  function ensure(){
    let el=document.getElementById('succiOfflineStatus');
    if(el)return el;
    el=document.createElement('div');
    el.id='succiOfflineStatus';
    el.style.cssText='position:fixed;left:50%;top:8px;transform:translateX(-50%);z-index:100000;display:none;padding:7px 12px;border-radius:999px;font:800 11px/1.2 system-ui,sans-serif;box-shadow:0 4px 14px #0002;pointer-events:none;max-width:92vw;text-align:center';
    document.body.appendChild(el);return el;
  }
  function set(){
    const el=ensure();
    if(navigator.onLine){el.textContent='ONLINE';el.style.background='#ecfdf3';el.style.color='#067647';el.style.border='1px solid #abefc6';setTimeout(()=>{if(navigator.onLine)el.style.display='none'},1800)}
    else{el.textContent='OFFLINE • Using saved app data';el.style.display='block';el.style.background='#fff7ed';el.style.color='#9a3412';el.style.border='1px solid #fed7aa'}
  }
  window.succiOfflineStatus={show:function(text){const el=ensure();el.textContent=text;el.style.display='block';el.style.background='#eff8ff';el.style.color='#175cd3';el.style.border='1px solid #b2ddff'},hide:function(){const el=document.getElementById('succiOfflineStatus');if(el)el.style.display='none'}};
  window.addEventListener('online',set);window.addEventListener('offline',set);
  document.addEventListener('DOMContentLoaded',()=>{set();if('serviceWorker' in navigator){navigator.serviceWorker.register('/sw.js').catch(()=>{});}});
})();
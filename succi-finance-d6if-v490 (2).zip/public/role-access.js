/* Server-backed route guard: the API must enforce the same rules; this only prevents loading an obviously unauthorized page shell. */
(function(){const ACCESS={
 '/system-admin-dashboard.html':['system_admin'],
 '/general-overseer-dashboard.html':['general_overseer'],
 '/general-supervisor-dashboard.html':['general_supervisor'],
 '/operational-manager-dashboard.html':['operational_manager'],
 '/branch-manager-dashboard.html':['branch_manager'],
 '/supervisor-dashboard.html':['supervisor'],
 '/auditor-dashboard.html':['auditor'],
 '/co-dashboard.html':['credit_officer'],
 '/ceo-dashboard.html':['ceo'],
 '/collections.html':['credit_officer'],
 '/approvals.html':['general_supervisor'],
 '/audits.html':['auditor'],
 '/collection-history.html':['general_overseer','branch_manager','auditor','supervisor'],
 '/disbursements.html':['branch_manager'],
 '/organization.html':['general_overseer','general_supervisor','operational_manager','branch_manager','supervisor','auditor','credit_officer'],
 '/branches.html':['general_overseer','general_supervisor'],
 '/disbursement-history.html':['general_overseer','general_supervisor','operational_manager','branch_manager','auditor'],
 '/reports.html':['general_overseer','general_supervisor','operational_manager','branch_manager','auditor','ceo'],
 '/loan-settings.html':['general_overseer'],
 '/staff.html':['general_overseer','branch_manager']
};
 async function guard(){const allowed=ACCESS[location.pathname];if(!allowed)return;try{const r=await fetch('/api/account/permissions',{credentials:'include',cache:'no-store'});if(!r.ok){location.replace('/login.html');return}const p=await r.json();if(!allowed.includes(String(p.role||'').toLowerCase()))location.replace('/dashboard.html?access_denied=1')}catch(e){location.replace('/login.html')}}
 document.addEventListener('DOMContentLoaded',guard);
})();
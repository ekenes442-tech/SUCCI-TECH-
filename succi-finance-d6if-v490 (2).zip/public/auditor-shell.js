/* SUCCI TECH Auditor shared navigation shell. Read-only navigation; API remains authoritative. */
(function(){
const items=[
 ['⌂','Dashboard','/auditor-dashboard.html'],
 ['⏳','Pending Audit','/auditor-pending-audit.html'],
 /* Client Repayment Audit removed */,
 ['▤','Branch Report Audit','/auditor-branch-report.html'],
 ['₦','Branch Disbursement History','/auditor-disbursement-history.html'],
 ['₦','Savings Offset','/auditor-savings-offset.html']
 ['✎','Repayment Corrections','/auditor-corrections.html'],
 ['▦','Audit History','/auditor-audit-history.html']
];
const path=location.pathname;
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function getStoredToken(){
 try{
  for(const k of Object.keys(localStorage)){if(!k.startsWith('sb-')||!k.endsWith('-auth-token'))continue;const raw=JSON.parse(localStorage.getItem(k)||'null');const v=raw?.access_token||raw?.currentSession?.access_token||raw?.session?.access_token;if(v)return v}
 }catch{}
 return '';
}
async function getToken(){
 let token=getStoredToken();
 try{if(window.supabase?.createClient&&window.SUCCI_SUPABASE_URL&&window.SUCCI_SUPABASE_KEY){const client=window.succiAuth||window.supabase.createClient(window.SUCCI_SUPABASE_URL,window.SUCCI_SUPABASE_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});window.succiAuth=client;const s=await client.auth.getSession();token=s?.data?.session?.access_token||token}}catch{}
 return token;
}
window.succiAuditorHeaders=async function(extra){const token=await getToken();return {'Cache-Control':'no-store',...(extra||{}),...(token?{Authorization:'Bearer '+token}:{})};};
async function getBranches(){
 try{const headers=await window.succiAuditorHeaders();const r=await fetch('/api/auditor/branches',{credentials:'include',headers,cache:'no-store'});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Unable to load assigned branches');window.succiAuditorLastBranchError='';return d.branches||[];}catch(e){window.succiAuditorLastBranchError=e.message;return []}
}
function ensureSidebarFooter(side){
 let footer=side.querySelector('.auditor-fixed-footer');
 if(!footer){
  footer=document.createElement('div');footer.className='auditor-fixed-footer';
  footer.innerHTML='<button type="button" class="auditor-theme-toggle">☾ <span>Dark Mode</span></button><button type="button" class="auditor-signout">↪ <span>Sign Out</span></button>';
  side.appendChild(footer);
 }
 const theme=footer.querySelector('.auditor-theme-toggle');
 const applyTheme=(dark)=>{document.documentElement.classList.toggle('dark',dark);document.body.classList.toggle('dark',dark);localStorage.setItem('succi_auditor_dark',dark?'1':'0');theme.innerHTML=dark?'☀ <span>Light Mode</span>':'☾ <span>Dark Mode</span>';};
 theme.onclick=()=>applyTheme(!document.documentElement.classList.contains('dark'));
 const saved=localStorage.getItem('succi_auditor_dark');
 applyTheme(saved==='1');
 footer.querySelector('.auditor-signout').onclick=()=>{location.href='/login.html';};
 return footer;
}
async function refreshSidebarBranches(side){
 const footer=ensureSidebarFooter(side), list=footer.querySelector('.auditor-assigned-list'), count=footer.querySelector('.auditor-branch-count');
 const bs=await getBranches();
 count.textContent=String(bs.length);
 list.innerHTML=bs.length?bs.map(b=>'<button type="button" class="auditor-branch-chip" data-branch="'+esc(b.id)+'">'+esc(b.name)+'</button>').join(''):'<span>No assigned branches</span>';
 list.querySelectorAll('.auditor-branch-chip').forEach(btn=>btn.onclick=()=>{localStorage.setItem('succi_auditor_branch_id',btn.dataset.branch);document.querySelectorAll('select#branch').forEach(s=>{s.value=btn.dataset.branch;s.dispatchEvent(new Event('change',{bubbles:true}))});});
}
function ensureMobileControls(side){
 let menu=document.getElementById('menu');
 let overlay=document.getElementById('overlay');
 if(!menu){menu=document.createElement('button');menu.id='menu';menu.className='st-menu';menu.type='button';menu.setAttribute('aria-label','Open Auditor menu');menu.textContent='☰';document.body.insertBefore(menu,document.body.firstChild)}
 if(!overlay){overlay=document.createElement('div');overlay.id='overlay';overlay.className='st-overlay';document.body.insertBefore(overlay,document.body.children[1]||null)}
 const close=()=>{side.classList.remove('open');overlay.classList.remove('open');document.body.style.overflow=''};
 if(!menu.dataset.auditorBound){menu.dataset.auditorBound='1';menu.onclick=()=>{side.classList.add('open');overlay.classList.add('open');document.body.style.overflow='hidden'};overlay.addEventListener('click',close)}
 return {menu,overlay,close};
}
async function populateBranchSelects(){
 const selects=[...document.querySelectorAll('select#branch')];
 if(!selects.length)return;
 const bs=await getBranches();
 const saved=localStorage.getItem('succi_auditor_branch_id')||new URLSearchParams(location.search).get('branch_id')||'';
 if(!bs.length&&window.succiAuditorLastBranchError){document.querySelectorAll('.auditor-branch-error').forEach(x=>x.textContent=window.succiAuditorLastBranchError)}
 selects.forEach(sel=>{
  const current=sel.value||saved;
  if(bs.length){
   sel.innerHTML=bs.map(x=>'<option value="'+esc(x.id)+'">'+esc(x.name)+'</option>').join('');
   const chosen=bs.some(x=>String(x.id)===String(current))?current:bs[0].id;
   sel.value=chosen;
   localStorage.setItem('succi_auditor_branch_id',chosen);
  }else{
   sel.innerHTML='<option value="">No assigned branches</option>';
   sel.value='';
  }
  sel.title=bs.length?'Select one of your assigned branches':'No branches assigned to this Auditor';
 });
}
async function init(){
 const side=document.querySelector('.st-side,.aud-side'); if(!side)return;
 const nav=side.querySelector('nav');
 if(nav){
  nav.classList.add('auditor-shared-nav');
  nav.innerHTML=items.map(([i,l,u])=>'<a class="'+(path===u?'active':'')+'" href="'+u+'"><span class="aud-icon" aria-hidden="true">'+i+'</span><span>'+esc(l)+'</span></a>').join('');
 }
 let badge=side.querySelector('.auditor-role-badge');
 if(!badge){
  badge=document.createElement('div');
  badge.className='auditor-role-badge';
  badge.innerHTML='<span class="aud-role-icon" aria-hidden="true">◉</span><span>Auditor</span>';
  const logo=side.querySelector('img');
  if(logo)logo.insertAdjacentElement('afterend',badge); else side.insertBefore(badge,side.firstChild);
 }
 if(!document.getElementById('auditor-shell-style')){
  const s=document.createElement('style');s.id='auditor-shell-style';s.textContent=`
 .auditor-role-badge{display:flex;align-items:center;gap:8px;margin:-12px 10px 16px;padding:8px 10px;border:1px solid #ead6d4;border-radius:10px;background:#fff7f6;color:#8f1d18;font-size:11px;font-weight:900;letter-spacing:.06em;text-transform:uppercase}
 .auditor-fixed-footer{position:absolute;left:0;right:0;bottom:0;padding:8px 14px 14px;background:#fff;border-top:1px solid #e5e7eb;z-index:20;display:flex;flex-direction:column;gap:7px}.auditor-theme-toggle,.auditor-signout{width:100%;border:1px solid #e5e7eb;background:#fff;border-radius:7px;padding:8px;color:#667085;font-size:10px;font-weight:800;cursor:pointer;text-align:left}.auditor-theme-toggle{margin-bottom:2px}.auditor-theme-toggle:hover,.auditor-signout:hover{background:#fef2f2;color:#b91c1c}
 .auditor-theme-toggle span,.auditor-signout span{margin-left:6px}
 .auditor-header-spacer{padding-top:18px!important}.auditor-branch-selector{position:relative!important;z-index:5!important;margin-top:12px!important;margin-bottom:16px!important}
 @media(prefers-color-scheme:dark){.auditor-fixed-footer{background:#151a22;border-color:#303744}.auditor-assigned-title{color:#aab3c2}.auditor-branch-chip{background:#222936;color:#e6eaf0}.auditor-branch-chip:hover{background:#b91c1c;color:#fff}.auditor-signout{background:#151a22;border-color:#303744;color:#aab3c2}.auditor-signout:hover{background:#3a171a;color:#ffb4b4}.auditor-role-badge{background:#321719;border-color:#633033;color:#ffb4b4}}
 html.dark .auditor-fixed-footer,body.dark .auditor-fixed-footer{background:#151a22;border-color:#303744}html.dark .auditor-assigned-title,body.dark .auditor-assigned-title{color:#aab3c2}html.dark .auditor-branch-chip,body.dark .auditor-branch-chip{background:#222936;color:#e6eaf0}html.dark .auditor-signout,body.dark .auditor-signout{background:#151a22;border-color:#303744;color:#aab3c2}
html.dark body,body.dark{background:#111827!important;color:#e5e7eb!important}html.dark .st-main,body.dark .st-main,html.dark .aud-main,body.dark .aud-main{background:#111827!important;color:#e5e7eb!important}html.dark .st-main .wrap,body.dark .st-main .wrap,html.dark .aud-main .audit-card,body.dark .aud-main .audit-card{color:#fff}html.dark .card,html.dark .box,html.dark .list,html.dark .detail,html.dark .section,html.dark .modal-box,body.dark .card,body.dark .box,body.dark .list,body.dark .detail,body.dark .section,body.dark .modal-box{background:#18202b!important;border-color:#303744!important;color:#e5e7eb!important}html.dark input,html.dark select,html.dark textarea,body.dark input,body.dark select,body.dark textarea{background:#151a22!important;color:#e5e7eb!important;border-color:#3b4554!important}html.dark .muted,body.dark .muted{color:#aab3c2!important}html.dark .st-topbar,html.dark .top,body.dark .st-topbar,body.dark .top,html.dark .st-footer,body.dark .st-footer{background:#151a22!important;color:#e5e7eb!important;border-color:#303744!important}html.dark a,body.dark a{color:#fca5a5}
 .aud-role-icon{width:20px;height:20px;display:grid;place-items:center;border-radius:50%;background:#b91c1c;color:#fff;font-size:10px}
 .auditor-shared-nav a{display:flex!important;align-items:center!important;gap:10px!important}
 .aud-icon{width:24px;height:24px;display:inline-grid;place-items:center;border-radius:7px;background:#f1f4f8;color:#344054;font-size:14px;font-weight:900;flex:none}
 .auditor-shared-nav a.active .aud-icon,.auditor-shared-nav a:hover .aud-icon{background:#b91c1c;color:#fff}
 .auditor-shared-nav a.active{font-weight:900}
 select#branch{cursor:pointer;pointer-events:auto;position:relative;z-index:2}
 @media(max-width:900px){.st-side,.aud-side{z-index:5000!important}.st-side.open,.aud-side.open{display:block!important;z-index:5002!important}.st-side a,.aud-side a{touch-action:manipulation}.st-menu{z-index:5003!important}.st-overlay{z-index:4999!important}}
 `;document.head.appendChild(s)
 }
 side.style.position='fixed';side.style.top='0';side.style.bottom='0';side.style.overflow='hidden';side.style.paddingBottom='82px';
 document.querySelectorAll('.auditor-branch-selector,#branch').forEach(el=>el.classList.add('auditor-branch-selector'));
 document.querySelectorAll('header,.top,.page-header,.auditor-header').forEach(el=>el.classList.add('auditor-header-spacer'));
 const {close}=ensureMobileControls(side);
 nav?.addEventListener('click',e=>{if(e.target.closest('a'))close()});
 ensureSidebarFooter(side);
 await populateBranchSelects();
}
document.addEventListener('DOMContentLoaded',init);
})();
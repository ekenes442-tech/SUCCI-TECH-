(function(){
// BM pages do not load the legacy global auth.js because it also mounts the generic sidebar.
// Create the shared Supabase client here so every BM page can attach the signed-in token.
if(!window.succiAuth && window.supabase && window.SUCCI_SUPABASE_URL && window.SUCCI_SUPABASE_KEY){
  window.succiAuth=window.supabase.createClient(window.SUCCI_SUPABASE_URL,window.SUCCI_SUPABASE_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
}
const GROUPS=[{label:'',items:[['dashboard','🏠 Dashboard','/branch-manager-dashboard.html']]},{label:'PORTFOLIO',items:[['clients','👥 Clients','/bm-clients.html'],['loans','💳 Active Loans','/bm-active-loans.html'],['pending','↳ Pending Disbursements','/bm-pending-disbursements.html']]},{label:'COLLECTIONS',items:[['collections','📋 Collections','/bm-collections.html'],['defaults','🚨 Defaulting Clients','/bm-defaults.html']]},{label:'DISBURSEMENTS',items:[['disbursements','💸 Disbursement History','/bm-disbursement-history.html']]},{label:'STAFF',items:[['staff','👨‍💼 Credit Officers','/bm-staff-performance.html'],['staff_manage','👥 Staff Management','/bm-staff-management.html']]},{label:'BRANCH EXPENSES',items:[['expenses','💰 Expenses','/bm-expenses.html']]},{label:'REPORTING',items:[['reports','📊 Branch Reports','/bm-reports.html']]},{label:'',items:[['settings','⚙️ Settings','/bm-settings.html']]}];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function identity(){
  try{
    let token='';
    if(window.succiAuth?.auth){const s=await window.succiAuth.auth.getSession();token=s?.data?.session?.access_token||'';}
    const headers=token?{Authorization:'Bearer '+token,'Cache-Control':'no-store'}:{'Cache-Control':'no-store'};
    const r=await window.fetch('/api/branch-manager/me',{method:'GET',headers,credentials:'same-origin',cache:'no-store'});
    if(!r.ok)return null;
    return await r.json();
  }catch{return null}
}
function current(){let p=location.pathname;if(p==='/bm-pending-disbursements.html'||p==='/bm-loan-review.html')return'pending';if(p==='/bm-active-loans.html')return'loans';return GROUPS.flatMap(g=>g.items).find(x=>x[2]===p)?.[0]||''}
async function init(){const nav=document.getElementById('bm-nav');if(!nav)return;nav.innerHTML=GROUPS.map(g=>(g.label?`<div class="bm-nav-group">${g.label}</div>`:'')+g.items.map(x=>`<a class="bm-nav-item ${current()===x[0]?'active':''}" href="${x[2]}">${x[1]}</a>`).join('')).join('')+'<div class="bm-nav-spacer"></div><a class="bm-nav-item bm-signout" href="/login.html">↪ Sign Out</a>';
const id=await identity();
let name=id?.display_name||id?.full_name||id?.name||id?.handle||'';
let branch=id?.branch_name||'';
if(!name&&window.succiAuth?.auth){try{const s=await window.succiAuth.auth.getSession();const u=s?.data?.session?.user;name=u?.user_metadata?.full_name||u?.user_metadata?.name||u?.email?.split('@')[0]||''}catch{}}
name=name||'Branch Manager';branch=branch||'Branch';
document.querySelectorAll('[data-bm-name]').forEach(e=>e.textContent=name);document.querySelectorAll('[data-bm-branch]').forEach(e=>e.textContent=branch);document.title=`SUCCI TECH • ${name}`;
const menu=document.getElementById('bmMenu'),side=document.getElementById('bmSide'),overlay=document.getElementById('bmOverlay');const close=()=>{side?.classList.remove('open');overlay?.classList.remove('open');document.body.style.overflow=''};menu?.addEventListener('click',()=>{side?.classList.add('open');overlay?.classList.add('open');document.body.style.overflow='hidden'});overlay?.addEventListener('click',close);document.addEventListener('keydown',e=>e.key==='Escape'&&close())}
window.BM={init,identity};document.addEventListener('DOMContentLoaded',init);
})();
(function(){
  const KEY='succi_offline_collection_queue_v1';
  function read(){try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch{return[]}}
  function write(v){try{localStorage.setItem(KEY,JSON.stringify(v))}catch{}}
  async function token(){try{const s=window.succiAuth?.auth?await window.succiAuth.auth.getSession():null;return s?.data?.session?.access_token||''}catch{return''}}
  async function send(item){const t=await token();const h={'Content-Type':'application/json'};if(t)h.Authorization='Bearer '+t;const r=await fetch(item.url,{method:'POST',credentials:'include',headers:h,body:JSON.stringify(item.body)});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Sync failed');return d}
  async function sync(){if(!navigator.onLine)return;const q=read();if(!q.length)return;window.succiOfflineStatus?.show('SYNCING OFFLINE COLLECTIONS…');const remain=[];for(const item of q){try{await send(item)}catch{remain.push(item)}}write(remain);window.succiOfflineStatus?.show(remain.length?'SYNC FAILED • Some entries remain queued':'SYNC COMPLETE');setTimeout(()=>window.succiOfflineStatus?.hide(),2500)}
  window.succiOfflineQueue={add:function(url,body){const q=read();q.push({id:Date.now()+'-'+Math.random().toString(36).slice(2),url,body,created_at:new Date().toISOString()});write(q);return q.length},sync, count:()=>read().length};
  window.addEventListener('online',()=>setTimeout(sync,500));document.addEventListener('DOMContentLoaded',()=>setTimeout(sync,1000));
})();
window.SUCCI_SUPABASE_URL='https://pescjtcaggyyafulstkl.supabase.co';window.SUCCI_SUPABASE_KEY='sb_publishable_vJdmMRw1nZdAE_mucqlECQ_cFAyqn1S';
(function(){
  if(!document.querySelector('script[src="/offline-status.js"]')){const s=document.createElement('script');s.src='/offline-status.js';s.defer=true;document.head.appendChild(s)}
  if('serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js?v=5').catch(()=>{});
  // If the login screen was opened while offline, retry cleanly as soon as connectivity returns.
  window.addEventListener('online',()=>{if(location.pathname==='/login.html')location.reload()});
})();